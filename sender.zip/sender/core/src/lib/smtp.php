<?php
class smtp {

    var $handle = 0;
    
    function open($remote_host, $local_ip='', $port = 25, $tval = 30) {
        
        if(empty($remote_host)) {
mslog(LOG_FILE_NAME, "error: smtp connect's remote_host is empty.");
            return FALSE;
        }
        
        if(empty($local_ip)) {
            $local_ip = 0;
        }
        
        $socket_options = array('socket' => array('bindto' => "{$local_ip}:0"));
        $socket_context = stream_context_create($socket_options);
        $this->handle = @stream_socket_client($remote_host . ':' . $port, $errno, $errstr, $tval, STREAM_CLIENT_CONNECT, $socket_context);

        if(empty($this->handle)) {
mslog(LOG_FILE_NAME, "error: smtp connect's handle is empty.");
            return FALSE;        
        }
        
        if(substr(PHP_OS, 0, 3) != "WIN") {
            stream_set_timeout($this->handle, $tval);        
        }
        
        return TRUE;       
        
    }
    
    function close() {
        if(!empty($this->handle)) {
            fclose($this->handle);
            $this->handle = 0;
        }
    }
    
    function is_open() {
        
        if(!empty($this->handle)) {
            if(feof($this->handle)) {
                $this->close();
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
        
    }
    
    function connect() {
        
        if(!$this->is_open()) {
            $r['open'] = false;
            return $r;
        } else {
            $r['open'] = true;
        }
        
        $reply = $this->get_lines();
mslog(LOG_FILE_NAME, "S: {$reply}", 0);
        $r['code'] = substr($reply, 0, 3);
        $r['reply'] = $reply;
        
        return $r;
    
    }
    
    function helo($host) {
        
        if(!$this->is_open()) {
            $r['open'] = false;
            return $r;
        } else {
            $r['open'] = true;
        }
        
        $send = "HELO {$host}\r\n";
mslog(LOG_FILE_NAME, "C: {$send}", 0);
        fputs($this->handle, $send); 
        
        $reply = $this->get_lines();
mslog(LOG_FILE_NAME, "S: {$reply}", 0); 
        $r['code'] = substr($reply, 0, 3);
        $r['reply'] = $reply;
        
        return $r;      
    
    }
    
    function mail($from) {
        
        if(!$this->is_open()) {
            $r['open'] = false;
            return $r;
        } else {
            $r['open'] = true;
        }
        
        $send = "MAIL FROM:<{$from}>\r\n";
mslog(LOG_FILE_NAME, "C: {$send}", 0);
        fputs($this->handle, $send);
        
        $reply = $this->get_lines();
mslog(LOG_FILE_NAME, "S: {$reply}", 0);
        $r['code'] = substr($reply, 0, 3);
        $r['reply'] = $reply;
        
        return $r;
                                           
    }
    
    function rcpt($to) {
        
        if(!$this->is_open()) {
            $r['open'] = false;
            return $r;
        } else {
            $r['open'] = true;
        }
        
        $send = "RCPT TO:<{$to}>\r\n";
mslog(LOG_FILE_NAME, "C: {$send}", 0);
        fputs($this->handle, $send);
        
        $reply = $this->get_lines();
mslog(LOG_FILE_NAME, "S: {$reply}", 0);
        $r['code'] = substr($reply, 0, 3);
        $r['reply'] = $reply;
        
        return $r; 
           
    }
    
    function data() {
        
        if(!$this->is_open()) {
            $r['open'] = false;
            return $r;
        } else {
            $r['open'] = true;
        } 
        
        $send = "DATA\r\n";
mslog(LOG_FILE_NAME, "C: {$send}", 0);
        fputs($this->handle, $send);
        $reply = $this->get_lines();
mslog(LOG_FILE_NAME, "S: {$reply}", 0);
        $r['code'] = substr($reply, 0, 3);
        $r['reply'] = $reply;
        
        return $r;        
           
    }
    
    function message($msg_data) {
        
        if(!$this->is_open()) {
            $r['open'] = false;
            return $r;
        } else {
            $r['open'] = true;
        }
        
mslog(LOG_FILE_NAME, "C: Send Data to Server...");

        # the server is ready to accept data!
        # according to rfc 821 we should not send more than 1000
        # including the CRLF
        # characters on a single line so we will break the data up
        # into lines by \r and/or \n then if needed we will break
        # each of those into smaller lines to fit within the limit.
        # in addition we will be looking for lines that start with
        # a period '.' and append and additional period '.' to that
        # line. NOTE: this does not count towards are limit.

        # normalize the line breaks so we know the explode works
        $msg_data = str_replace("\r\n","\n",$msg_data);
        $msg_data = str_replace("\r","\n",$msg_data);
        $lines = explode("\n",$msg_data);

        # we need to find a good way to determine is headers are
        # in the msg_data or if it is a straight msg body
        # currently I am assuming rfc 822 definitions of msg headers
        # and if the first field of the first line (':' sperated)
        # does not contain a space then it _should_ be a header
        # and we can process all lines before a blank "" line as
        # headers.
        $field = substr($lines[0],0,strpos($lines[0],":"));
        $in_headers = false;
        if(!empty($field) && !strstr($field," ")) {
          $in_headers = true;
        }

        $max_line_length = 998; # used below; set here for ease in change

        while(list(,$line) = @each($lines)) {
          $lines_out = null;
          if($line == "" && $in_headers) {
            $in_headers = false;
          }
          # ok we need to break this line up into several
          # smaller lines
          while(strlen($line) > $max_line_length) {
            $pos = strrpos(substr($line,0,$max_line_length)," ");

            # Patch to fix DOS attack
            if(!$pos) {
              $pos = $max_line_length - 1;
            }

            $lines_out[] = substr($line,0,$pos);
            $line = substr($line,$pos + 1);
            # if we are processing headers we need to
            # add a LWSP-char to the front of the new line
            # rfc 822 on long msg headers
            if($in_headers) {
              $line = "\t" . $line;
            }
          }
          $lines_out[] = $line;

          # now send the lines to the server
          while(list(,$line_out) = @each($lines_out)) {
            if(strlen($line_out) > 0)
            {
              if(substr($line_out, 0, 1) == ".") {
                $line_out = "." . $line_out;
              }
            }
            fputs($this->handle, $line_out . "\r\n");
          }
        }

        # ok all the message data has been sent so lets get this
        # over with aleady
mslog(LOG_FILE_NAME, "C: .");
        fputs($this->handle, "\r\n" . "." . "\r\n");

        $reply = $this->get_lines();
mslog(LOG_FILE_NAME, "S: {$reply}", 0);
        $r['code'] = substr($reply, 0, 3);
        $r['reply'] = $reply;
        
        return $r;
            
    }
    
    function quit() {
        
        if(!$this->is_open()) {
            $r['open'] = false;
            return $r;
        } else {
            $r['open'] = true;
        }
        
        $send = "QUIT\r\n";
mslog(LOG_FILE_NAME, "C: {$send}", 0);
        fputs($this->handle, $send);
        $reply = $this->get_lines();
mslog(LOG_FILE_NAME, "S: {$reply}", 0);
        $r['code'] = substr($reply, 0, 3);
        $r['reply'] = $reply;
        
        return $r; 
          
    }
    
    function get_lines() {
        
        $data = '';
        while($line = @fgets($this->handle, 515)) {
            $data .= $line;
            if(substr($line, 3, 1) == ' ') {
                break;
            }        
        }
        
        return $data;
        
    }

}
?>