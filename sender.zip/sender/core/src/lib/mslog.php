<?php
function mslog($file_name, $log, $le = 1) {
    if(DEBUG) {
        $file_name = ROOT_PATH . '/logs/' . $file_name;
        $log = date('Y-m-d H:i:s') . ' ' . $log;
        if($le) {
            $log = $log . "\r\n";
        }
        @file_put_contents($file_name, $log, FILE_APPEND);
    }    
}
//define('DEBUG', 1);
//define('ROOT_PATH', '..');
//mslog('a.log', 'aaa');
?>