<?php

// system
define('MAILER_SUCCESS',                           1);

// local
define('MAILER_LOCAL_IP_ERROR',                    11);
define('MAILER_LOCAL_DOMAIN_ERROR',                12);

// sender
define('MAILER_SENDER_ERROR',                      21);
define('MAILER_SENDER_NAME_ERROR',                 22);

// from
define('MAILER_FROM_ERROR',                        31);
define('MAILER_FROM_NAME_ERROR',                   32);

// to
define('MAILER_TO_ERROR',                          41);
define('MAILER_TO_NAME_ERROR',                     42);

// mail
define('MAILER_MAIL_SUBJECT_ERROR',                51);
define('MAILER_MAIL_BODY_ERROR',                   52);

// mx
define('MAILER_MX_DNS_ERROR',                      61);
define('MAILER_MX_EMAIL_NOT_EXIST',                62);

// send
define('MAILER_SEND_SOCKET_ERROR',                 71);
define('MAILER_SEND_CONNECT_ERROR',                72);
define('MAILER_SEND_HELLO_ERROR',                  73);
define('MAILER_SEND_FROM_ERROR',                   74);
define('MAILER_SEND_TO_ERROR',                     75);
define('MAILER_SEND_DATA_ERROR',                   76);


class mailer {
    
    
    // local
    var $local_host;       
    var $local_domain;      
    var $local_ip;        

    // sender
    var $sender;           
    var $sender_user;      
    var $sender_host;      
    var $sender_name;      

    // from
    var $from;             
    var $from_user;       
    var $from_host;      
    var $from_name;        

    // to
    var $to;                
    var $to_user;       
    var $to_host;          
    var $to_name;          
    
    // mx
    var $mx_host;         

    // mail
    var $subject;
    var $body; 
    var $data;

    // misc  
    var $_error = '';  
    var $_LE = "\r\n";

    
    function start($local_ip, $local_domain, $sender, $sender_name, $from, $from_name, $to, $to_name, $subject, $body) {
        
        // set
        if(!$this->set($local_ip, $local_domain, $sender, $sender_name, $from, $from_name, $to, $to_name, $subject, $body)) {
            return $this->_error;
        }

        // content
        $this->content();
        
        // send
        return $this->send();
        
    }
    
    function set($local_ip, $local_domain, $sender, $sender_name, $from, $from_name, $to, $to_name, $subject, $body) {
        
        // ********** set **********
        
        // local
        $this->local_ip = trim($local_ip);
        $this->local_domain = strtolower(trim($local_domain));
        
        // sender
        $this->sender = strtolower(trim($sender));
        $this->sender_name = strip_tags(trim($sender_name));
        
        // from
        $this->from = strtolower(trim($from));
        $this->from_name = strip_tags(trim($from_name));
        
        // to
        $this->to = strtolower(trim($to));
        $this->to_name = strip_tags(trim($to_name));
        
        // mail
        $this->subject = strip_tags(trim($subject));
        $this->body = trim($body);        
        
        // ********** check **********
        
        // local
        if(!$this->_check_ip($this->local_ip)) {
            $this->_error = MAILER_LOCAL_IP_ERROR;
            return FALSE;
        }
        if(!$this->_check_host($this->local_domain)) {
            $this->_error = MAILER_LOCAL_DOMAIN_ERROR;
            return FALSE;
        }
        
        // sender
        if(!$this->_check_email($this->sender)) {
            $this->_error = MAILER_SENDER_ERROR;
            return FALSE;       
        }

        // from
        if(!$this->_check_email($this->from)) {
            $this->_error = MAILER_FROM_ERROR;
            return FALSE;       
        }      
        if(empty($this->from_name)) {
            $this->_error = MAILER_FROM_NAME_ERROR;
            return FALSE;
        }  
        
        // to
        if(!$this->_check_email($this->to)) {
            $this->_error = MAILER_TO_ERROR;
            return FALSE;
        }
        
        // mail
        if(empty($this->subject)) {
            $this->_error = MAILER_MAIL_SUBJECT_ERROR;
            return FALSE;
        }
        if(empty($this->body)) {
            $this->_error = MAILER_MAIL_BODY_ERROR;
            return FALSE;
        }
        
        // ********** build **********
        
        // local
        $this->local_host = $this->_get_host_name_by_ip($this->local_ip, $this->local_domain);
        
        // sender
        $this->sender_user = $this->_get_user_and_host_by_email($this->sender, 'user');
        $this->sender_host = $this->_get_user_and_host_by_email($this->sender, 'host');
        
        // from
        $this->from_user = $this->_get_user_and_host_by_email($this->from, 'user');
        $this->from_host = $this->_get_user_and_host_by_email($this->from, 'host');
        
        // to
        $this->to_user = $this->_get_user_and_host_by_email($this->to, 'user');
        $this->to_host = $this->_get_user_and_host_by_email($this->to, 'host');
        
        // mx
        if(getmxrr($this->to_host, $mx_host)) {
            $this->mx_host = strtolower(trim($mx_host[0]));
        } else {
            $this->_error = MAILER_MX_DNS_ERROR;
            return FALSE;
        }
        
        return TRUE;
        
    }
        
    function content() {
        
        $user_agent = 'PHPMailer [version 1.72]';
        $pid = substr(abs(crc32($this->local_ip . 'pid')), 0, 4);
        $uid = substr(abs(crc32($this->local_ip . 'uid')), 0, 3);
        $now = time();
        $data = '';
        
        // ********** header **********

        $header['received'] = 'Received: (qmail ' . $pid . ' invoked by uid ' . $uid . '); ' . $this->_get_rfc_date($now - 2) . $this->_LE;
        $header['date'] = 'Date: ' . $this->_get_rfc_date($now - 10) . $this->_LE;
        $header['to'] = 'To: <' . $this->to . '>' . $this->_LE;
        $header['from'] = 'From: ' . '=?UTF-8?B?' . base64_encode($this->_get_secure_header($this->from_name)) . '?= <' . $this->from . '>' . $this->_LE;
        $header['subject'] = 'Subject: ' . '=?UTF-8?B?' . base64_encode($this->_get_secure_header($this->subject)) . '?=' . $this->_LE; 
        $header['message-id'] = 'Message-ID: <' . date('YmdHis', $now - 11) . '.' . rand(10000, 30000) . '@' . $this->from_host . '>' . $this->_LE;
        $header['x-priority'] = 'X-Priority: 3' . $this->_LE;
        $header['x-mailer'] = 'X-Mailer: ' . $user_agent . $this->_LE;
        $header['mime-version'] = 'MIME-Version: 1.0' . $this->_LE; 
        $header['content-transfer-encoding'] = 'Content-Transfer-Encoding: base64' . $this->_LE; 
        $header['content-type'] = 'Content-Type: text/html; charset="UTF-8"' . $this->_LE;  
        
        // ********** message **********
        
        $message = chunk_split(base64_encode($this->body));
        
        // ********** data **********
        
        $data .= $header['received'];
        $data .= $header['date'];
        $data .= $header['to'];
        $data .= $header['from'];
        $data .= $header['subject'];
        $data .= $header['message-id'];
        $data .= $header['x-priority'];
        $data .= $header['x-mailer'];
        $data .= $header['mime-version'];
        $data .= $header['content-transfer-encoding'];
        $data .= $header['content-type'];
        
        $data .= $this->_LE;
        
        $data .= $message;
        
        $this->data = $data;
                 
    }
    
    function send() {
        
        $smtp = new smtp();
        
        // open
        $r = $smtp->open($this->mx_host, $this->local_ip);
        if(!$r) {
            $smtp->close();
            return MAILER_SEND_SOCKET_ERROR;
        }
        $r = null;
        
        // connect
        $r = $smtp->connect();
        if(!$r['open']) {
            $smtp->close();
            return MAILER_SEND_SOCKET_ERROR;            
        }
        if($r['code'] != '220') {
            $smtp->close();
            return MAILER_SEND_CONNECT_ERROR;             
        }
        $r = null;
        
        // hello
        $r = $smtp->helo($this->local_host);
        if(!$r['open']) {
            $smtp->close();
            return MAILER_SEND_SOCKET_ERROR;            
        }
        if($r['code'] != '250') {
            $smtp->quit();
            $smtp->close(); 
            return MAILER_SEND_HELLO_ERROR;             
        }
        $r = null;
        
        // mail from
        $r = $smtp->mail($this->sender);
        if(!$r['open']) {
            $smtp->close();
            return MAILER_SEND_SOCKET_ERROR;            
        }
        if($r['code'] != '250') {
            $smtp->quit();
            $smtp->close();
            return MAILER_SEND_FROM_ERROR;             
        }
        $r = null; 
        
        // rcpt to
        $r = $smtp->rcpt($this->to);
        if(!$r['open']) {
            $smtp->close();
            return MAILER_SEND_SOCKET_ERROR;            
        }
        if($r['code'] != '250') {
            if($this->_get_mail_exist($r['reply'])) {
                $bounce = MAILER_MX_EMAIL_NOT_EXIST;    
            } else {
                $bounce = MAILER_SEND_TO_ERROR;               
            }
            $smtp->quit();
            $smtp->close();
            return $bounce;             
        }
        $r = null;
        
        // data
        $r = $smtp->data();               
        if(!$r['open']) {
            $smtp->close();
            return MAILER_SEND_SOCKET_ERROR;            
        }
        if($r['code'] != '354') {
            if($this->_get_mail_exist($r['reply'])) {
                $bounce = MAILER_MX_EMAIL_NOT_EXIST;    
            } else {
                $bounce = MAILER_SEND_DATA_ERROR;               
            }
            $smtp->quit();
            $smtp->close();
            return $bounce;
        }
        $r = null;
        
        // message
        $r = $smtp->message($this->data);        
        if(!$r['open']) {
            $smtp->close();
            return MAILER_SEND_SOCKET_ERROR;            
        }
        if($r['code'] != '250') {
            if($this->_get_mail_exist($r['reply'])) {
                $bounce = MAILER_MX_EMAIL_NOT_EXIST;    
            } else {
                $bounce = MAILER_SEND_DATA_ERROR;               
            }
            $smtp->quit();
            $smtp->close();
            return $bounce;
        }
        $r = null;
        
        // quit
        $smtp->quit();
        
        // close
        $smtp->close();
        
        // success
        return MAILER_SUCCESS;
                
    }
    
    function _get_mail_exist($reply = '') {
        $p = '/(unavailable|found|exist|unknown|invalid|such user|account|find|address reject|quota|full)/i';
        return preg_match($p, $reply);    
    }
    
    function _get_host_name_by_ip($ip, $domain) {
        $a = explode('.', $ip);
        $host = 'm' . $a[2] . '-' . $a[3] . '.' . $domain;
        return $host;   
    }
    
    function _get_user_and_host_by_email($email, $r = 'user') {
        $a = explode('@', $email);
        if($r == 'user') {
            return $a[0];
        } else {
            return $a[1];
        }
    }
    
    function _get_rfc_date($time_stamp = '') {

        if(empty($time_stamp)) {
            $time_stamp = time();
        }
        return date('r', $time_stamp);
    }

    function _get_secure_header($str) {
        $str = trim($str);
        $str = str_replace("\r", "", $str);
        $str = str_replace("\n", "", $str);
        return $str;
    }
    
    function _check_ip($ip) {
        return preg_match('/^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$/i', $ip);
    }
    
    function _check_host($host) {
        return preg_match('/^[0-9a-z-_\.]+$/i', $host);
    }
    
    function _check_email($email) {
        return preg_match('/^[0-9a-z-_\.@]+$/i', $email);
    }

}
?>