<?php
// UTF-8 标识

date_default_timezone_set('Asia/Shanghai');

// EDM_JOB_ENTITY.RESULT
define('EDM_SINGLE_JOB_RESULT_SUCCESS',             0);  
define('EDM_SINGLE_JOB_RESULT_BOUNCE_FROM',         1);  
define('EDM_SINGLE_JOB_RESULT_BOUNCE_TO_SOFT',      2);  
define('EDM_SINGLE_JOB_RESULT_BOUNCE_TO_HARD',      4);  
define('EDM_SINGLE_JOB_RESULT_BOUNCE_DATA',         8);  
define('EDM_SINGLE_JOB_RESULT_BOUNCE_CONNECT',      16);  
define('EDM_SINGLE_JOB_RESULT_BOUNCE_OTHER',        32);

if(!defined('ROOT_PATH')) {
    define('ROOT_PATH', dirname(__FILE__)); 
}

require_once(ROOT_PATH . '/config.php');

if(DEBUG) {
    error_reporting(E_ALL);    
} else {
    error_reporting(E_ALL ^ E_NOTICE);     
}

ini_set('log_errors', 1);
ini_set('error_log', ROOT_PATH . '/logs/error.log');

if(WINDEBUG) {
    $request_ip = '192.168.1.101';
} else {
    $request_ip = $argv[1];
}

define('LOG_FILE_NAME', $request_ip . '.log');

$c = 0;

while(1) {
    $result = main($request_ip);
    if(!$result) {
        mslog(LOG_FILE_NAME, 'main error, sleep 5s for next request.');
        sleep(5);
    }
    ++$c;
    if($c == 20) {
        exit;
    }
}

?>