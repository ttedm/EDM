<?php

define('DEBUG', 1);

define('WINDEBUG', 1);

define('SENDER_HOST', 'seekmu.com');

define('SENDER_USER', 'edm');

define('LOCAL_DOMAIN', 'seekmu.com');

define('APP_URL', 'http://edm.abc.com/');

?>