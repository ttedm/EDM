<?php
function main($request_ip) {
    
    mslog(LOG_FILE_NAME, 'sender starting.');
    
    if(!preg_match('/^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$/i', $request_ip)) {
        mslog(LOG_FILE_NAME, 'request ip format error.');
        return false;
    }
    
    $get_url = APP_URL . '?tree=service.edm.sender_fetch_mail&ip=' . $request_ip;
    
    mslog(LOG_FILE_NAME, 'fetch mail array from ' . $request_ip . '.');
    
    $http = new http();
   
    $data = $http->get($get_url);
    
    if(!$data) {
        mslog(LOG_FILE_NAME, 'fetch mail array false.');
        return false;
    }
    
    $data_array = unserialize(base64_decode($data));
    
    if(!is_array($data_array)) {
        mslog(LOG_FILE_NAME, $data, 0);
        return false;
    } else {
        $data = $data_array;
        unset($data_array);
    }
    
    if(!is_array($data['job'])) {
        mslog(LOG_FILE_NAME, 'job is not array.');
        return false;
    }
    
    $post_url = APP_URL . '?tree=service.edm.sender_post_result';
    
    foreach($data['job'] as $job) {
        
        $edm_job_id = $job['edm_job_id'];
        $job_id = $job['job_id'];
        
        mslog(LOG_FILE_NAME, '------------------------------------------------------------');
        mslog(LOG_FILE_NAME, "edm_job_id: {$edm_job_id} | job_id: {$job_id}");

        $subject = $job['job_subject'];
        $body = $job['job_body'];
        $from_name = $job['job_from_name'];
        $from = $job['job_from'];
        $to = $job['job_to'];
        $local_ip = $job['job_ip'];
        $local_domain = LOCAL_DOMAIN;
        $sender = SENDER_USER . /*$edm_job_id .*/ '@' . SENDER_HOST;
        
        mslog(LOG_FILE_NAME, "from: {$from}");
        mslog(LOG_FILE_NAME, "to: {$to}");
        mslog(LOG_FILE_NAME, "local ip: {$local_ip}");
        mslog(LOG_FILE_NAME, '');
       
        $post_result = array();
        
        $o = new mailer();
        $result = $o->start($local_ip, $local_domain, $sender, '', $from, $from_name, $to, '', $subject, $body);
        
        if($result == MAILER_SUCCESS) {
            $post_result['job_result'] = EDM_SINGLE_JOB_RESULT_SUCCESS;    
        } elseif($result == MAILER_MX_EMAIL_NOT_EXIST || $result == MAILER_MX_DNS_ERROR) {
            $post_result['job_result'] = EDM_SINGLE_JOB_RESULT_BOUNCE_TO_HARD;
        } else {
            $post_result['job_result'] = EDM_SINGLE_JOB_RESULT_BOUNCE_TO_SOFT;
        }  
              
        $post_result['job_id'] = $job_id;
        $post_result['edm_job_id'] = $edm_job_id;
        
        mslog(LOG_FILE_NAME, '');
        mslog(LOG_FILE_NAME, "to: {$to} | result: {$post_result['job_result']}");
        mslog(LOG_FILE_NAME, 'update post result.');
        mslog(LOG_FILE_NAME, '------------------------------------------------------------');
        
        $post_result = base64_encode(serialize($post_result));
                
        $http->post($post_url, array('job' => $post_result));
        
        mslog(LOG_FILE_NAME, '');
          
    }
    
    return true;  
    
}
?>
