<?php

define('ROOT_PATH', dirname(__FILE__)); 

require_once(ROOT_PATH . '/../../core/src/lib/http.php');
require_once(ROOT_PATH . '/../../core/src/lib/mailer.php');
require_once(ROOT_PATH . '/../../core/src/lib/smtp.php');   
require_once(ROOT_PATH . '/../../core/src/lib/mslog.php');  
require_once(ROOT_PATH . '/lib/main.php');  
require_once(ROOT_PATH . '/sender.php');
 
?>
