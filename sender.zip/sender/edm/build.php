<?php

define('ROOT_PATH',             dirname(__FILE__));
define('CORE_ROOT',             ROOT_PATH . '/../core/src'); 
define('SOURCE_ROOT',           ROOT_PATH . '/src');
define('PUBLISH_ROOT',          ROOT_PATH . '/bin');
define('FILE_MAIN_NAME',        'edm');

// php file
$php_file_name = PUBLISH_ROOT . '/' . FILE_MAIN_NAME . '.php';
$php_content   = '';

// core src

foreach(glob(CORE_ROOT . '/lib/*.php') as $filename) {
    $php_content .= trim(file_get_contents($filename));
    $php_content .= "\r\n";
}

// local src

foreach(glob(SOURCE_ROOT . '/lib/*.php') as $filename) {
    $php_content .= trim(file_get_contents($filename));
    $php_content .= "\r\n";
}

foreach(glob(SOURCE_ROOT . '/sender.php') as $filename) {
    $php_content .= trim(file_get_contents($filename));
    //$php_content .= "\n";
}

file_put_contents($php_file_name, $php_content);
                                                                                                    
?>