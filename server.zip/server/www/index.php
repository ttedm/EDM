<?php
 
define('ROOT_PATH', dirname(__FILE__));
define('LOG_PATH', ROOT_PATH . '/logs'); 

error_reporting(E_ALL ^ E_NOTICE ^ E_DEPRECATED);
ini_set('log_errors', 1);
ini_set('error_log', LOG_PATH . '/error.log');

require_once(ROOT_PATH . '/modules/sys.php');

if($argv[1]) {
    define('COMMAND_LINE', TRUE);
    define('GLOBAL_TREE', $argv[1]);
} else {
    define('COMMAND_LINE', FALSE);
    define('GLOBAL_TREE', $_GET['tree']);
}

$system = new sys();
$system->init();
                                               
?>