<?php

// UNICODE
define ('UTF32_BIG_ENDIAN_BOM'   , chr(0x00) . chr(0x00) . chr(0xFE) . chr(0xFF));
define ('UTF32_LITTLE_ENDIAN_BOM', chr(0xFF) . chr(0xFE) . chr(0x00) . chr(0x00));
define ('UTF16_BIG_ENDIAN_BOM'   , chr(0xFE) . chr(0xFF));
define ('UTF16_LITTLE_ENDIAN_BOM', chr(0xFF) . chr(0xFE));
define ('UTF8_BOM'               , chr(0xEF) . chr(0xBB) . chr(0xBF));

// USER SYSTEM
// USER.USER_TYPE
define('USER_END_USER',           0);
define('USER_AGENT',              1);
define('USER_ADMINISTRATOR',      2);
define('USER_SYSTEM',             4);

define('USER_TYPE_END_USER',            '客户');
define('USER_TYPE_AGENT',               '经销商');
define('USER_TYPE_ADMINISTRATOR',       '管理员');
define('USER_TYPE_SYSTEM',              '系统');

define('USER_UNLOCK',             0);
define('USER_LOCK',               1);

define('IS_NOT_DELETE',           0);
define('IS_DELETE',               1);

// BILLING SYSTEM
// BILLING.BILLING_TYPE
define('BILLING_TYPE_INCOME',     0);
define('BILLING_TYPE_COST',       1);
define('BILLING_TYPE_RESTORE',    2);

// EDM SYSTEM
// EDM_JOB.EDM_JOB_STATUS
define('EDM_JOB_STATUS_WAIT_FOR_AUDIT',            0); 
define('EDM_JOB_STATUS_AUDIT_FAILED',              1);
define('EDM_JOB_STATUS_WAIT_FOR_JOB_CREATE',       2);
define('EDM_JOB_STATUS_JOB_CREATING',              4);
define('EDM_JOB_STATUS_WAIT_FOR_JOB_RUN',          8);
define('EDM_JOB_STATUS_JOB_RUNNING',               16);
define('EDM_JOB_STATUS_JOB_FINISHED',              32);
define('EDM_JOB_STATUS_JOB_PAUSE',                 64);  

// EDM_JOB.EDM_JOB_STATUS DETAIL
define('EDM_JOB_STATUS_DETAIL_WAIT_FOR_AUDIT',            '等待审核'); 
define('EDM_JOB_STATUS_DETAIL_AUDIT_FAILED',              '审核未通过');
define('EDM_JOB_STATUS_DETAIL_WAIT_FOR_JOB_CREATE',       '等待任务建立');
define('EDM_JOB_STATUS_DETAIL_JOB_CREATING',              '任务建立中');
define('EDM_JOB_STATUS_DETAIL_WAIT_FOR_JOB_RUN',          '等待任务开始运行');
define('EDM_JOB_STATUS_DETAIL_JOB_RUNNING',               '任务运行中');
define('EDM_JOB_STATUS_DETAIL_JOB_FINISHED',              '任务已完成');
define('EDM_JOB_STATUS_DETAIL_JOB_PAUSE',                 '任务已暂停');

// EDM_JOB_ENTITY.RESULT
define('EDM_SINGLE_JOB_RESULT_SUCCESS',             0);  
define('EDM_SINGLE_JOB_RESULT_BOUNCE_FROM',         1);  
define('EDM_SINGLE_JOB_RESULT_BOUNCE_TO_SOFT',      2);  
define('EDM_SINGLE_JOB_RESULT_BOUNCE_TO_HARD',      4);  
define('EDM_SINGLE_JOB_RESULT_BOUNCE_DATA',         8);  
define('EDM_SINGLE_JOB_RESULT_BOUNCE_CONNECT',      16);  
define('EDM_SINGLE_JOB_RESULT_BOUNCE_OTHER',        32);  

// EDM_JOB_ENTITY.RESULT DETAIL
define('EDM_SINGLE_JOB_RESULT_DETAIL_SUCCESS',             '发送成功');  
define('EDM_SINGLE_JOB_RESULT_DETAIL_BOUNCE_FROM',         '发信箱退信');  
define('EDM_SINGLE_JOB_RESULT_DETAIL_BOUNCE_TO_SOFT',      '收信箱软退信');  
define('EDM_SINGLE_JOB_RESULT_DETAIL_BOUNCE_TO_HARD',      '收信箱硬退信');  
define('EDM_SINGLE_JOB_RESULT_DETAIL_BOUNCE_DATA',         '邮件正文退信');  
define('EDM_SINGLE_JOB_RESULT_DETAIL_BOUNCE_CONNECT',      '不能连接退信');  
define('EDM_SINGLE_JOB_RESULT_DETAIL_BOUNCE_OTHER',        '其他退信'); 

// EDM_JOB_ENTITY.STATUS
define('EDM_SINGLE_JOB_STATUS_UNSENT',  0);
define('EDM_SINGLE_JOB_STATUS_SENT',    1);

// EDM LOCK
define('EDM_UNLOCK',              0);
define('EDM_LOCK',                1);

// EDM_UHOST.EDM_UHOST_TYPE
define('EDM_UHOST_TYPE_YMD',      0);
define('EDM_UHOST_TYPE_RAND',     1);

// EDM JOB_DAEMON 
define('EDM_JOB_DAEMON_CREATE_SLEEP_TIME',   1*60);
define('EDM_JOB_DAEMON_FINISH_SLEEP_TIME',   10*60);
define('EDM_JOB_DAEMON_NODE_STATUS_SLEEP_TIME', 3600);

?>
