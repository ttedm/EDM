<?php

define('SECRET_KEY', '');

define('DEBUG', 0); 

define('MYSQL_HOST',             'localhost'); 
define('MYSQL_DATABASE',         'brdms');  
define('MYSQL_USERNAME',         'root');
define('MYSQL_PASSWORD',         '123456');

define('MYSQL_SMTP_HOST',        'localhost'); 
define('MYSQL_SMTP_DATABASE',    'brdms_smtp');  
define('MYSQL_SMTP_USERNAME',    'root');
define('MYSQL_SMTP_PASSWORD',    '123456'); 

define('MYSQL_JOBS_HOST',        'localhost'); 
define('MYSQL_JOBS_DATABASE',    'brdms_jobs');  
define('MYSQL_JOBS_USERNAME',    'root');
define('MYSQL_JOBS_PASSWORD',    '123456'); 

define('MAIL_HOST',              '');  
define('MAIL_FROM',              '');
define('MAIL_FROMNAME',          'System');
define('MAIL_FROM_PASSWORD',     '');
define('MAIL_WEBMASTER',         '');

define('TEMPLATE_PATH',  '/themes/default');

define('SITE_HOST',             '');
define('SITE_HOST_FEEDBACK',    SITE_HOST);
define('SITE_HOST_API',         SITE_HOST);
define('SITE_SERVER_PORT', 80);

?>