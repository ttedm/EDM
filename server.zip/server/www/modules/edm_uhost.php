<?php

class edm_uhost {
    
    var $edm_uhost_id;
    var $edm_uhost_prefix;
    var $edm_uhost_type;

}
?>
