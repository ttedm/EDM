<?php
// 标识
class edm_content {
    
    var $edm_content_id;
    var $user_id;
    var $edm_content_subject;
    var $edm_content_altbody;
    var $edm_content_time;
    
    
    
}
?>
