<?php

class edm_ua {

    var $edm_ua_id;
    var $edm_ua_value;
    
}
?>
