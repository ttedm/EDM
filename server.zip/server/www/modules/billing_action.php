<?php
class billing_action {

    var $system;
    var $user;
    var $billing;
    
    function billing_action(&$system) {
        
        $this->system = $system;
        
        $this->billing = new billing();
        
        $action = $this->system->action;
        
        if($action == 'show') {
            $this->user = unserialize($_SESSION['user']);
            $this->show();
        }
        if($action == 'export') {
            $this->user = unserialize($_SESSION['user']);
            $this->export();
        }
        
    }
    
    function show() {
        
        $this->system->check_login();
        
        SmartyPaginate::connect('system_billing_show');       
        SmartyPaginate::setUrlVar('start', 'system_billing_show');
        SmartyPaginate::setURL('/?tree=system.billing.show', 'system_billing_show');
        SmartyPaginate::setLimit(10, 'system_billing_show');
        SmartyPaginate::setPrevText('上一页', 'system_billing_show');
        SmartyPaginate::setNextText('下一页', 'system_billing_show');
        SmartyPaginate::setFirstText('首页', 'system_billing_show');
        SmartyPaginate::setLastText('末页', 'system_billing_show');
        SmartyPaginate::setPageLimit(10, 'system_billing_show');
        
        // get counter
        $sql = "SELECT count(billing_id) AS c FROM billing WHERE user_id={$this->user->user_id}";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        SmartyPaginate::setTotal($row['c'], 'system_billing_show');
        
        // get data grid
        $sql = "SELECT billing_id, product_slug, billing_type, billing_cost, billing_subject, billing_operator, billing_time FROM billing WHERE user_id='{$this->user->user_id}' ORDER BY billing_id DESC LIMIT %d, %d";
        $sql = sprintf($sql, SmartyPaginate::getCurrentIndex('system_billing_show'), SmartyPaginate::getLimit('system_billing_show')); 
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        $billing = array();
        while($row = mysql_fetch_array($result)) {
            $billing[] = $row;
        }
        
        $this->system->smarty->assign('billing', $billing);
        SmartyPaginate::assign(&$this->system->smarty, 'paginate', 'system_billing_show');
        $this->system->smarty->display('system.billing.show.tpl');
    
    }
    
    function export() {
        
        $this->system->check_login();
        
        $sql = "SELECT billing_id, product_slug, billing_type, billing_cost, billing_subject, billing_operator, billing_time FROM billing WHERE user_id='{$this->user->user_id}' ORDER BY billing_id DESC";
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        $billing_type_array = array(BILLING_TYPE_INCOME  => '充入',
                                    BILLING_TYPE_COST    => '扣除',
                                    BILLING_TYPE_RESTORE => '返还',
                                    );
        
        $billing_data = "操作\t事由\t单位数\t产品\t操作人\t时间\r\n";
        
        while($row = mysql_fetch_array($result)) {
            
            $billing_symbol = '';
            if($row['billing_type'] == BILLING_TYPE_INCOME) {
                $billing_symbol = '+';
            } elseif($row['billing_type'] == BILLING_TYPE_COST) {
                $billing_symbol = '-';
            } elseif($row['billing_type'] == BILLING_TYPE_RESTORE) {
                $billing_symbol = '+';
            }
            
            $billing_data .= $billing_type_array[$row['billing_type']] . "\t" . $row['billing_subject'] . "\t";
            $billing_data .= $billing_symbol . $row['billing_cost'] . "\t" . $row['product_slug'] . "\t" . $row['billing_operator'] . "\t" . date('Y.m.d H:i:s', $row['billing_time']) . "\r\n";
        }
        
        $billing_data = UTF16_LITTLE_ENDIAN_BOM . iconv('UTF-8', 'UTF-16LE', $billing_data);
        $billing_file_name = urlencode('账单明细.csv');
        $this->system->common->set_download($billing_file_name, $billing_data);
        
    }
    
    // BILLING SYSTEM
        
    // 系统返还
    function billing_restore($user_id, $product_slug, $billing_cost, $edm_job_id) {
        
        $this->billing->user_id = $user_id;
        $this->billing->product_slug = strtoupper($product_slug);
        $this->billing->billing_type = BILLING_TYPE_RESTORE;
        $this->billing->billing_cost = $billing_cost;
        $this->billing->billing_subject = '系统返还 ID:' . $edm_job_id;
        $this->billing->billing_operator = '#system';
        $this->billing->billing_time = time();
        
        $this->billing_insert();
       
    }
    
    // 下级充值
    function billing_recharge($user_id, $user_cid, $product_slug, $billing_cost) {
        
        $product_slug = strtoupper($product_slug);
        
        // get my user_name
        $sql = "SELECT user_name FROM user WHERE user_id='{$user_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        $user_name_mime = $row['user_name'];        
        
        // get child user_name
        $sql = "SELECT user_name FROM user WHERE user_id='{$user_cid}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        $user_name_child = $row['user_name'];
        
        // my account billing
       
        $this->billing->user_id = $user_id;
        $this->billing->product_slug = $product_slug;
        $this->billing->billing_type = BILLING_TYPE_COST;
        $this->billing->billing_cost = $billing_cost;
        $this->billing->billing_subject = "为 {$user_name_child} 充值";
        $this->billing->billing_operator = $user_name_mime;
        $this->billing->billing_time = time();
        
        $this->billing_insert();
        
        // child account billing
        
        $this->billing->user_id = $user_cid;
        $this->billing->product_slug = $product_slug;
        $this->billing->billing_type = BILLING_TYPE_INCOME;
        $this->billing->billing_cost = $billing_cost;
        $this->billing->billing_subject = "收到 {$user_name_mime} 的充值";
        $this->billing->billing_operator = $user_name_mime;
        $this->billing->billing_time = time();
        
        $this->billing_insert();
        
    }
    
    // 消费扣款
    function billing_cost($user_id, $product_slug, $billing_cost, $edm_job_id) {
        
        // get my user_name
        $sql = "SELECT user_name FROM user WHERE user_id='{$user_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        $user_name_mime = $row['user_name'];    
        
        // my account billing
        
        $this->billing->user_id = $user_id;
        $this->billing->product_slug = strtoupper($product_slug);
        $this->billing->billing_type = BILLING_TYPE_COST;
        $this->billing->billing_cost = $billing_cost;
        $this->billing->billing_subject = "消费 {$this->billing->product_slug} ID:" . $edm_job_id;
        $this->billing->billing_operator = $user_name_mime;
        $this->billing->billing_time = time();
        
        $this->billing_insert();
    
    }
    
    // 账单插入
    function billing_insert() {
                
        $sql = "INSERT INTO billing(user_id, product_slug, billing_type, billing_cost, billing_subject, billing_operator, billing_time) VALUES('{$this->billing->user_id}', '{$this->billing->product_slug}', '{$this->billing->billing_type}', '{$this->billing->billing_cost}', '{$this->billing->billing_subject}', '{$this->billing->billing_operator}', '{$this->billing->billing_time}')";
        mysql_query($sql, $this->system->mysql->conn);
    
    }
    
    
}
?>
