<?php

class service_edm_action {

    var $system;
    var $edmmisc_action;
    
    function service_edm_action(&$system) {
        
        $this->system = $system;
        
        $this->edmmisc_action = new edmmisc_action($this->system);
        
        // brdms_jobs init
        $this->edmmisc_action->mysql_jobs_init();
        
        $action = $this->system->action;
        
        // job daemon
        if($action == 'job_create') {
            $this->job_create();
        }
        if($action == 'job_finish') {
            $this->job_finish();
        }
        
        // sender service
        if($action == 'sender_fetch_mail') {
            $this->sender_fetch_mail();
        }
        if($action == 'sender_post_result') {
            $this->sender_post_result();
        }
        
        // analysis service
        if($action == 'analysis_open') {
            $this->analysis_open();
        }        
        if($action == 'analysis_click') {
            $this->analysis_click();
        }
        if($action == 'analysis_unsubscribe') {
            $this->analysis_unsubscribe();
        }
        
        // tool service
        if($action == 'get_sender_ip') {
            $this->get_sender_ip();
        }
        if($action == 'node_status') {
            $this->node_status();
        }
        
    }
    
    // job
    
    function job_create() {
        
echo("job create starting.\n");
        
        $sql_j = "SELECT edm_job_id, edm_job_status, edm_job_count_plan, user_id, edm_to_id, edm_content_id FROM edm_job WHERE edm_job_status='" . EDM_JOB_STATUS_WAIT_FOR_JOB_CREATE . "'";
        $result_j = mysql_query($sql_j, $this->system->mysql->conn);
        
        while($row_j = mysql_fetch_array($result_j)) {
            
            $edm_job = new edm_job();
            $edm_job->edm_job_id = $row_j['edm_job_id'];
            $edm_job->edm_job_status = $row_j['edm_job_status'];
            $edm_job->edm_job_count_plan = $row_j['edm_job_count_plan'];
            $edm_job->user_id = $row_j['user_id'];
            $edm_job->edm_to_id = $row_j['edm_to_id'];
            $edm_job->edm_content_id = $row_j['edm_content_id'];

echo("edm_job_id: {$edm_job->edm_job_id}\n"); 

echo("udpate job_status JOB_CREATING.\n");           
            // update job_status
            $sql = "UPDATE edm_job SET edm_job_status='" . EDM_JOB_STATUS_JOB_CREATING . "' WHERE edm_job_id='{$edm_job->edm_job_id}'";
            mysql_query($sql, $this->system->mysql->conn);

echo("get product available counter.\n");            
            // get product available count
            $sql = "SELECT pp.product_price_id AS product_price_id, pp.product_available_count AS product_available_count FROM product_price pp LEFT JOIN product p ON pp.product_id=p.product_id WHERE p.product_slug='EDM' AND pp.user_id='{$edm_job->user_id}'";
            $result = mysql_query($sql, $this->system->mysql->conn);
            $row = mysql_fetch_array($result);
            
            $product_price = new product_price();
            $product_price->product_price_id = $row['product_price_id'];
            $product_price->product_available_count = $row['product_available_count'];

echo("get edm_to_count.\n");
            // update edm_to_count
            $sql = "SELECT count(edm_to_id) AS c FROM edm_to_list WHERE edm_to_id={$edm_job->edm_to_id} AND edm_to_value_deleted=0";
            $result = mysql_query($sql, $this->system->mysql->conn);
            $row = mysql_fetch_array($result);
            
            $sql = "UPDATE edm_to SET edm_to_count={$row['c']} WHERE edm_to_id={$edm_job->edm_to_id}";
            mysql_query($sql, $this->system->mysql->conn);
                        
            // get edm_to_count
            $sql = "SELECT edm_to_count FROM edm_to WHERE edm_to_id='{$edm_job->edm_to_id}'";
            $result = mysql_query($sql, $this->system->mysql->conn);
            $row = mysql_fetch_array($result);
            
            $edm_to = new edm_to();
            $edm_to->edm_to_count = $row['edm_to_count'];

echo("get min value.\n");            
            // min value
            $min_send_count = min($edm_job->edm_job_count_plan, $product_price->product_available_count, $edm_to->edm_to_count);
            
            if($min_send_count <= 0) {
echo("min_send_count <= 0, continue.\n");
                // unaudit job_status
                $sql = "UPDATE edm_job SET edm_job_status='" . EDM_JOB_STATUS_AUDIT_FAILED . "', edm_job_message='库存不足' WHERE edm_job_id='{$edm_job->edm_job_id}'";
                mysql_query($sql, $this->system->mysql->conn);   
                continue; 
            }

echo("get edm_to.\n");
            // get to
            $sql = "SELECT edm_to_value FROM edm_to_list WHERE edm_to_id={$edm_job->edm_to_id} AND edm_to_value_deleted=0";
            $result = mysql_query($sql, $this->system->mysql->conn);
            $to = array();
            while($row = mysql_fetch_array($result)) {
                $to[] = $row['edm_to_value'];
            }
            shuffle($to);
            
            unset($result);
            unset($row);

echo("update product_price.\n");            
            // update product_price
            $sql = "UPDATE product_price SET product_available_count=product_available_count-{$min_send_count}, product_used_count=product_used_count+{$min_send_count} WHERE product_price_id='{$product_price->product_price_id}'";
            mysql_query($sql, $this->system->mysql->conn);

echo("update edm_count_real.\n");            
            // update count_real
            $sql = "UPDATE edm_job SET edm_job_count_real='{$min_send_count}' WHERE edm_job_id='{$edm_job->edm_job_id}'";
            mysql_query($sql, $this->system->mysql->conn);

echo("update billing.\n");            
            // update billing
            $billing_action = new billing_action($this->system);
            $billing_action->billing_cost($edm_job->user_id, 'EDM', $min_send_count, $edm_job->edm_job_id);            
           
echo("create job table in BRDMS_JOBS.\n");          
            // create job table
            $sql = "CREATE TABLE edm_job_{$edm_job->edm_job_id} LIKE edm_job_entity";
            mysql_query($sql, $this->edmmisc_action->mysql_jobs->conn);
            
            // make job table
echo("make job table in BRDMS_JOBS.\n");

echo("get edm_ip.\n");            
            // get ip
            $sql = "SELECT edm_ip FROM edm_ip ORDER BY rand()";
            $result = mysql_query($sql, $this->system->mysql->conn);
            $ip = array();
            while($row = mysql_fetch_array($result)) {
                $ip[] = $row['edm_ip'];
            }
            shuffle($ip);

echo("get edm_ua.\n");            
            // get ua
            $sql = "SELECT edm_ua_value FROM edm_ua";
            $result = mysql_query($sql, $this->system->mysql->conn);
            $ua = array();
            while($row = mysql_fetch_array($result)) {
                $ua[] = $row['edm_ua_value'];
            }
            shuffle($ua);

echo("get edm_uhost.\n");            
            // get uhost
            $sql = "SELECT edm_uhost_prefix, edm_uhost_type FROM edm_uhost";
            $result = mysql_query($sql, $this->system->mysql->conn);
            $uhost = array();
            while($row = mysql_fetch_array($result)) {
                $uhost[] = array('edm_uhost_prefix' => $row['edm_uhost_prefix'],
                                 'edm_uhost_type' => $row['edm_uhost_type'],
                                 );
            }
            shuffle($uhost);

echo("get edm_uip.\n");            
            // get uip
            $sql = "SELECT edm_uip_start, edm_uip_end FROM edm_uip";
            $result = mysql_query($sql, $this->system->mysql->conn);
            $uip = array();
            while($row = mysql_fetch_array($result)) {
                $uip[] = array('edm_uip_start' => $row['edm_uip_start'],
                               'edm_uip_end' => $row['edm_uip_end'],
                               );
            }
            shuffle($uip);

echo("get edm_from.\n");            
            // get from
            $sql = "
SELECT
  `edm_from_list`.`edm_from_list_middle_end`,
  `edm_from_list`.`edm_from_list_middle_start`,
  `edm_from_list`.`edm_from_list_end`, `edm_from_list`.`edm_from_list_start`,
  `edm_from`.`edm_from_domain`
FROM
  `edm_from_list` LEFT JOIN
  `edm_from` ON `edm_from`.`edm_from_id` = `edm_from_list`.`edm_from_id`
            ";
            $result = mysql_query($sql, $this->system->mysql->conn);
            $from = array();
            while($row = mysql_fetch_array($result)) {
                $from[] = array('edm_from_list_middle_start' => $row['edm_from_list_middle_start'],
                                'edm_from_list_middle_end'   => $row['edm_from_list_middle_end'],
                                'edm_from_list_end'          => $row['edm_from_list_end'],
                                'edm_from_list_start'        => $row['edm_from_list_start'],
                                'edm_from_domain'            => $row['edm_from_domain'],
                                );
            }
            shuffle($from);

echo("insert into BRDMS_JOBS for jobs.\n");            
            // insert into created table
            $ip_counter_total = sizeof($ip);
            $ip_counter = 0;
            
            $sql = "INSERT INTO edm_job_{$edm_job->edm_job_id}(job_from, job_to, job_ip, job_ua, job_uhost, job_uip) VALUES";
            for($i=0;$i<$min_send_count;++$i) {
                $sql .= "(";
                $sql .= "'" . $this->edmmisc_action->get_single_from($from) . "',";
                $sql .= "'" . $to[$i] . "',";
                $sql .= "'" . $ip[$ip_counter] . "',";
                $sql .= "'" . $ua[array_rand($ua)] . "',";
                $sql .= "'" . $this->edmmisc_action->get_single_uhost($uhost) . "',";
                $sql .= "'" . $this->edmmisc_action->get_single_uip($uip) . "'";
                $sql .= "),";
                
                ++$ip_counter;
                if($ip_counter == $ip_counter_total) {
                    $ip_counter = 0;
                }
                
            }
            
            $sql = substr($sql, 0, -1);
            mysql_query($sql, $this->edmmisc_action->mysql_jobs->conn);

echo("update job_status WAIT_FOR_RUN.\n");            
            // update job_status
            $sql = "UPDATE edm_job SET edm_job_status='" . EDM_JOB_STATUS_WAIT_FOR_JOB_RUN . "' WHERE edm_job_id='{$edm_job->edm_job_id}'";
            mysql_query($sql, $this->system->mysql->conn);
            
        }
        
echo("sleep for sub process exit.\n");
        
        sleep(EDM_JOB_DAEMON_CREATE_SLEEP_TIME);
    
    }
    
    function job_finish() {
        
echo("get edm_ip\n");
        $edm_ip = array();
        //$edm_ip_str = '';
        $sql = "SELECT edm_ip FROM edm_ip ORDER BY rand()";
        $result = mysql_query($sql, $this->system->mysql->conn);
        while($row = mysql_fetch_array($result)) {
            $edm_ip[] = $row['edm_ip'];
            //$edm_ip_str .= "'{$row['edm_ip']}',";
        }
        unset($sql);
        unset($result);
        unset($row);
        $edm_ip_total = sizeof($edm_ip);
        //if($edm_ip_total != 0) {
        //    $edm_ip_str = substr($edm_ip_str, 0, -1);
        //}
echo("edm_ip total: {$edm_ip_total}\n");     

echo("get running edm_job.\n");        
        $sql_j = "SELECT edm_job_id, edm_to_id, edm_content_id FROM edm_job WHERE edm_job_status='" . EDM_JOB_STATUS_JOB_RUNNING . "'";
        $result_j = mysql_query($sql_j, $this->system->mysql->conn);
        
        $this->edmmisc_action->mysql_jobs_init();
        
        while($row_j = mysql_fetch_array($result_j)) {
            
            $edm_job = new edm_job();
            $edm_job->edm_job_id = $row_j['edm_job_id'];
            $edm_job->edm_to_id = $row_j['edm_to_id'];
            $edm_job->edm_content_id = $row_j['edm_content_id'];
            
            // update job_ip is not in edm_ip
echo("update job_ip that is not in edm_ip.\n");
            if($edm_ip_total != 0) {
                //$sql = "SELECT job_id FROM edm_job_{$edm_job->edm_job_id} WHERE job_status=0 AND job_ip NOT IN({$edm_ip_str})";
                $sql = "SELECT job_id FROM edm_job_{$edm_job->edm_job_id} WHERE job_status=0"; 
                $result = mysql_query($sql, $this->edmmisc_action->mysql_jobs->conn);
echo("number of updating job_ip: " . mysql_num_rows($result) . "\n");
                $edm_ip_counter = mt_rand(0, $edm_ip_total - 1);
                while($row = mysql_fetch_array($result)) {
                    $sql = "UPDATE edm_job_{$edm_job->edm_job_id} SET job_ip='{$edm_ip[$edm_ip_counter]}' WHERE job_id={$row['job_id']}";
                    mysql_query($sql, $this->edmmisc_action->mysql_jobs->conn);
                    ++$edm_ip_counter;
                    if($edm_ip_counter == $edm_ip_total) {
                        $edm_ip_counter = 0;
                    }
                }
            }
            unset($sql);
            unset($result);
            unset($row);
            unset($edm_ip_counter);
            
echo("check job finish for edm_job_id: {$edm_job->edm_job_id}\n");            
            // check table
            $sql = "SELECT count(job_id) AS count FROM edm_job_{$edm_job->edm_job_id} WHERE job_status='0'";
            $result = mysql_query($sql, $this->edmmisc_action->mysql_jobs->conn);
            if(!$result) {
                continue;
            }
            $row = mysql_fetch_array($result);
            
            if($row['count'] == 0) { // all mail sent
echo("all mail sent.\n");

echo("update edm_time edm_status finish.\n");                
                // update edm_job end_time and status
                $sql = "UPDATE edm_job SET edm_job_status='" . EDM_JOB_STATUS_JOB_FINISHED . "', edm_job_end_time='" . time() . "', edm_job_resent_counter=edm_job_resent_counter+1 WHERE edm_job_id='{$edm_job->edm_job_id}'";
                mysql_query($sql, $this->system->mysql->conn);

echo("get soft bounce resent counter.\n");
                // get soft bounce resent counter
                $sql = "SELECT edm_job_resent_counter FROM edm_job WHERE edm_job_id={$edm_job->edm_job_id}";
                $result = mysql_query($sql, $this->system->mysql->conn);
                $row = mysql_fetch_array($result);
                $edm_job_resent_counter = $row['edm_job_resent_counter'];

echo("soft bounce product price restore.\n");
                // soft bounce product price restore                
                if($edm_job_resent_counter == 2) {
                    
echo("get edm_job user_id and counter need to restore.\n");
                    $sql = "SELECT user_id, (edm_job_count_bounce_from + edm_job_count_bounce_to_soft + edm_job_count_bounce_data + edm_job_count_bounce_connect + edm_job_count_bounce_other) AS billing_restore FROM edm_job WHERE edm_job_id={$edm_job->edm_job_id}";
                    $result = mysql_query($sql, $this->system->mysql->conn);
                    $row = mysql_fetch_array($result);
                    $user_id = $row['user_id'];
                    $billing_restore = $row['billing_restore']; 
                    
echo("get product_price_id.\n");
                    // get product_price_id
                    $sql = "SELECT pp.product_price_id AS product_price_id FROM product_price pp LEFT JOIN product p ON pp.product_id=p.product_id WHERE p.product_slug='EDM' AND pp.user_id='{$user_id}'";
                    $result = mysql_query($sql, $this->system->mysql->conn);
                    $row = mysql_fetch_array($result);                    
                    $product_price_id = $row['product_price_id'];
                    
echo("update product_price.\n");            
                    // update product_price
                    $sql = "UPDATE product_price SET product_available_count=product_available_count+{$billing_restore}, product_used_count=product_used_count-{$billing_restore} WHERE product_price_id='{$product_price_id}'";
                    mysql_query($sql, $this->system->mysql->conn);
                    
echo("update billing.\n");            
                    // update billing
                    $billing_action = new billing_action($this->system);
                    $billing_action->billing_restore($user_id, 'EDM', $billing_restore, $edm_job->edm_job_id);
                    
                    unset($user_id);
                    unset($product_price_id);
                    unset($billing_restore);
                    unset($billing_action);
                    
                }

echo("update soft bounce resent.\n");                 
                // update soft bounce resent
                if($edm_job_resent_counter < 2) {
                    
                    $sql = "UPDATE edm_job_{$edm_job->edm_job_id} SET job_status='" . EDM_SINGLE_JOB_STATUS_UNSENT . "', job_time='0', job_result='0', job_open='0', job_click='0' WHERE job_result='" . EDM_SINGLE_JOB_RESULT_BOUNCE_FROM . "' OR job_result='" . EDM_SINGLE_JOB_RESULT_BOUNCE_TO_SOFT . "' OR job_result='" . EDM_SINGLE_JOB_RESULT_BOUNCE_DATA . "'";
                    mysql_query($sql, $this->edmmisc_action->mysql_jobs->conn);
        
                    // info table
                    $sql = "UPDATE edm_job SET edm_job_status='" . EDM_JOB_STATUS_JOB_RUNNING . "', edm_job_end_time='0', edm_job_count_bounce_from='0', edm_job_count_bounce_to_soft='0', edm_job_count_bounce_data='0' WHERE edm_job_id='{$edm_job->edm_job_id}'";
                    mysql_query($sql, $this->system->mysql->conn);
                
                }
                
echo("update edm to counter.\n");             
                // update edm_to counter
                
                $sql = "SELECT count(edm_to_id) AS c FROM edm_to_list WHERE edm_to_id={$edm_job->edm_to_id} AND edm_to_value_deleted=0";
                $result = mysql_query($sql, $this->system->mysql->conn);
                $row = mysql_fetch_array($result);
                $edm_to_count = $row['c'];
                
                $sql = "UPDATE edm_to SET edm_to_count={$edm_to_count} WHERE edm_to_id={$edm_job->edm_to_id}";
                mysql_query($sql, $this->system->mysql->conn);

                unset($edm_to_count);               
                
            }
            
        }

echo("sleep for sub process exit.\n");        
        sleep(EDM_JOB_DAEMON_FINISH_SLEEP_TIME);
    
    }
    
    // sender
    function sender_fetch_mail() {

        /*
        $remote_ip = $this->system->common->real_ip();
        
        // check remote ip
        if(!preg_match('/^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$/i', $remote_ip)) {
            die("remote ip format error.\n");
        }
        
        // check remote ip in database
        $sql = "SELECT edm_ip_id FROM edm_ip WHERE edm_ip='{$remote_ip}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        if(mysql_num_rows($result) < 1) {
            die("remote ip is not in db.\n");
        }
        */
       
        if(!isset($_GET['ip'])) {
            die("sender ip isset error.\n");
        }
        
        $ip = $_GET['ip'];
        
        // check ip
        if(!preg_match('/^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$/i', $ip)) {
            die("sender ip format error.\n");
        }
        
        // check ip in database
        $sql = "SELECT edm_ip_id FROM edm_ip WHERE edm_ip='{$ip}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        if(mysql_num_rows($result) < 1) {
            die("sender ip is not in db.\n");
        }

        // get edm_content_filter_value
        $sql = "SELECT edm_content_filter_value FROM edm_content_filter";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $edm_content_filter = array();
        while($row = mysql_fetch_array($result)) {
            $edm_content_filter[] = $row['edm_content_filter_value'];
        }
                
        // edm_job
        $sql_j = "SELECT * FROM (SELECT * FROM (SELECT edm_job_id, edm_job_status, edm_content_id, edm_job_reply_to, edm_job_from, edm_job_from_name, edm_job_get_click, user_id FROM edm_job WHERE edm_job_status=" . EDM_JOB_STATUS_WAIT_FOR_JOB_RUN . " OR edm_job_status=" . EDM_JOB_STATUS_JOB_RUNNING . " ORDER BY rand()) AS jobs GROUP BY user_id) AS jobs2 ORDER BY rand()";
        $result_j = mysql_query($sql_j, $this->system->mysql->conn);  

        $job = array();
        while($row_j = mysql_fetch_array($result_j)) {
            
            $edm_job = new edm_job();
            $edm_job->edm_job_id         = $row_j['edm_job_id'];
            $edm_job->edm_job_status     = $row_j['edm_job_status'];
            $edm_job->edm_content_id     = $row_j['edm_content_id'];
            $edm_job->edm_job_reply_to   = $row_j['edm_job_reply_to'];
            $edm_job->edm_job_from       = $row_j['edm_job_from'];
            $edm_job->edm_job_from_name  = $row_j['edm_job_from_name'];
            $edm_job->edm_job_get_click  = $row_j['edm_job_get_click'];
           
            // update job running
            if($edm_job->edm_job_status == EDM_JOB_STATUS_WAIT_FOR_JOB_RUN) {
                $sql = "UPDATE edm_job SET edm_job_status='" . EDM_JOB_STATUS_JOB_RUNNING . "', edm_job_start_time='" . time() . "' WHERE edm_job_id='{$edm_job->edm_job_id}'";
                mysql_query($sql, $this->system->mysql->conn);
            }

            // get job
            $sql = "SELECT job_id, job_to, job_ip FROM edm_job_{$edm_job->edm_job_id} WHERE job_status=0 AND job_ip='{$ip}' ORDER BY rand() LIMIT 0,10";
            $result = mysql_query($sql, $this->edmmisc_action->mysql_jobs->conn);
            
            if(mysql_num_rows($result) < 1) {
                continue;
            }
            
            while($row = mysql_fetch_array($result)) {
                $job[] = $row;
            }
            
            // get content
            $sql = "SELECT edm_content_subject, edm_content_altbody FROM edm_content WHERE edm_content_id='{$edm_job->edm_content_id}'";
            $result = mysql_query($sql, $this->system->mysql->conn);
            $row = mysql_fetch_array($result);
            $edm_content = new edm_content();
            $edm_content->edm_content_subject = $row['edm_content_subject'];
            $edm_content->edm_content_altbody = $row['edm_content_altbody'];
            
            // get content urls
            $sql = "SELECT edm_content_url, edm_content_url_hash FROM edm_content_url WHERE edm_content_id={$edm_job->edm_content_id}";
            $result = mysql_query($sql, $this->system->mysql->conn);
            $edm_content_urls = array();
            while($row = mysql_fetch_array($result)) {
                $edm_content_urls[] = $row;
            }
            
            // make final job
            
            for($i=0;$i<sizeof($job);++$i) {
                $job[$i]['edm_job_id']       = $edm_job->edm_job_id;
                $job[$i]['job_subject']      = $this->edmmisc_action->get_mail_subject($edm_content->edm_content_subject, $edm_content_filter);
                $job[$i]['job_body']         = $this->edmmisc_action->get_mail_data($edm_job->edm_job_id, $job[$i]['job_id'], $job[$i]['job_to'], $edm_content->edm_content_altbody, $edm_job->edm_job_get_click, $edm_content_urls, $edm_content_filter);
                $job[$i]['job_reply_to']     = $edm_job->edm_job_reply_to;
                $job[$i]['job_from_name']    = $edm_job->edm_job_from_name;
                $job[$i]['job_from']         = $edm_job->edm_job_from;
            }
            
            break;
        }
        
        if(sizeof($job) == 0) {
            die("no job.\n");
        }

        $data = array();
        $data['job']      = $job;
        
        unset($job);

        $data = base64_encode(serialize($data));
        
        die($data);
    
    }
    
    function sender_post_result() {
        /*
        // check
        $ip = $this->system->common->real_ip();
        
        // check ip
        if(!preg_match('/^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$/i', $ip)) {
            die("ip format error.\n");
        }
        
        // check ip in database
        $sql = "SELECT edm_ip_id FROM edm_ip WHERE edm_ip='{$ip}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        if(mysql_num_rows($result) < 1) {
            die("ip is not in db.\n");
        }
        */
        // post
        if(!isset($_POST['job'])) {
            die("no job post.\n");
        }
        
        $job = unserialize(base64_decode($_POST['job']));        

        if(!is_array($job)) {
            die("job is not array.\n");
        }
        
        $sql = "SELECT COUNT(job_id) AS c FROM edm_job_{$job['edm_job_id']} WHERE job_status=1 AND job_id={$job['job_id']}";
        $result = mysql_query($sql, $this->edmmisc_action->mysql_jobs->conn);
        $row = mysql_fetch_array($result);
        $c = $row['c'];
        unset($sql);
        unset($result);
        unset($row);
        
        if($c == 1) {
            
            die("had updated.\n");
            
        } else {
            
            // update brdms_jobs edm_job_id
            $job_result_array = array(EDM_SINGLE_JOB_RESULT_SUCCESS,
                                      EDM_SINGLE_JOB_RESULT_BOUNCE_FROM,
                                      EDM_SINGLE_JOB_RESULT_BOUNCE_TO_SOFT,
                                      EDM_SINGLE_JOB_RESULT_BOUNCE_TO_HARD,
                                      EDM_SINGLE_JOB_RESULT_BOUNCE_DATA,
                                      EDM_SINGLE_JOB_RESULT_BOUNCE_CONNECT,
                                      EDM_SINGLE_JOB_RESULT_BOUNCE_OTHER
                                      );
                                      
            if(!in_array($job['job_result'], $job_result_array)) {
                $job['job_result'] = EDM_SINGLE_JOB_RESULT_BOUNCE_OTHER;
            }
            
            $sql = "UPDATE edm_job_{$job['edm_job_id']} SET job_status='1', job_time='" . time() . "', job_result='{$job['job_result']}' WHERE job_id={$job['job_id']}";
            mysql_query($sql, $this->edmmisc_action->mysql_jobs->conn);
            
            // update brdms edm_job
            if($job['job_result'] == EDM_SINGLE_JOB_RESULT_SUCCESS) {
                $update_count_string = 'edm_job_count_success';
            } elseif($job['job_result'] == EDM_SINGLE_JOB_RESULT_BOUNCE_FROM) {
                $update_count_string = 'edm_job_count_bounce_from';
            } elseif($job['job_result'] == EDM_SINGLE_JOB_RESULT_BOUNCE_TO_SOFT) {
                $update_count_string = 'edm_job_count_bounce_to_soft';
            } elseif($job['job_result'] == EDM_SINGLE_JOB_RESULT_BOUNCE_TO_HARD) {
                $update_count_string = 'edm_job_count_bounce_to_hard';           
            } elseif($job['job_result'] == EDM_SINGLE_JOB_RESULT_BOUNCE_DATA) {
                $update_count_string = 'edm_job_count_bounce_data';
            } elseif($job['job_result'] == EDM_SINGLE_JOB_RESULT_BOUNCE_CONNECT) {
                $update_count_string = 'edm_job_count_bounce_connect';
            } else {
                $update_count_string = 'edm_job_count_bounce_other';
            }
            
            $sql = "UPDATE edm_job SET {$update_count_string}={$update_count_string}+1 WHERE edm_job_id={$job['edm_job_id']}";
            mysql_query($sql, $this->system->mysql->conn);
            
            // update hard bounce
            
            if($job['job_result'] == EDM_SINGLE_JOB_RESULT_BOUNCE_TO_HARD) {
                
                $sql = "SELECT job_to FROM edm_job_{$job['edm_job_id']} WHERE job_id={$job['job_id']}";
                $result = mysql_query($sql, $this->edmmisc_action->mysql_jobs->conn);
                
                if($row = mysql_fetch_array($result)) {
                    $to_bad = $row['job_to'];
                } else {
                    $to_bad = '';
                }
                
                $sql = "UPDATE edm_to_list SET edm_to_value_deleted='1' WHERE edm_to_value_hash=CRC32('{$to_bad}')";
                mysql_query($sql, $this->system->mysql->conn);
                
            }
            
            die("ok.\n");
            
        }

    
    }
    
    // analysis
    
    function analysis_open() {
        
        // get vars
        $edm_job_id           = intval($_GET['edm_job_id']);
        $job_id               = intval($_GET['job_id']);
        $chk_hash             = trim($_GET['chk_hash']);
        $edm_content_url      = 'http://' . SITE_HOST . ':' . SITE_SERVER_PORT . '/1px.gif';
        
        // check error
        $error = 0;
        
        // check edm_job_id job_id
        if(strtoupper(md5(md5($edm_job_id) . $job_id . SECRET_KEY)) != strtoupper($chk_hash)) {
            $error = 1;
        }
        
        if($error) {
            die("CHECK ERROR " . $error);
        }
        
         // check is human being
        $user_browser = $this->system->common->get_user_browser();
        $browsers = array('ie', 'firefox', 'safari', 'chrome', 'opera', 'webkit', 'lotus', 'gecko');
        if(!in_array($user_browser, $browsers)) {            
            header("Location: {$edm_content_url}");
            exit;            
        }
        
        // update jobs
        $sql = "UPDATE edm_job_{$edm_job_id} SET job_open=job_open+1 WHERE job_id='{$job_id}'";
        mysql_query($sql, $this->edmmisc_action->mysql_jobs->conn);
        
        // update edm_job
        $sql = "UPDATE edm_job SET edm_job_count_open=edm_job_count_open+1 WHERE edm_job_id='{$edm_job_id}'";
        mysql_query($sql, $this->system->mysql->conn);
        
        // redirect
        header("Location: {$edm_content_url}");
        
    }
    
    function analysis_click() {
 
        // get vars
        $edm_job_id           = intval($_GET['edm_job_id']);
        $job_id               = intval($_GET['job_id']);
        $chk_hash             = trim($_GET['chk_hash']);
        $edm_content_url_hash = trim($_GET['edm_content_url_hash']);
        
        // check error
        $error = 0;
        
        // check edm_job_id job_id
        if(strtoupper(md5(md5($edm_job_id) . $job_id . strtoupper($edm_content_url_hash) . SECRET_KEY)) != strtoupper($chk_hash)) {
            $error = 1;
        }
        
        // check edm_content_url_hash
        $edm_content_url_hash = strtolower($edm_content_url_hash);
        
        $sql = "SELECT edm_content_url FROM edm_content_url WHERE edm_content_url_hash='{$edm_content_url_hash}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        if(mysql_num_rows($result) < 1) {
            $error = 2;
        } else {
            $row = mysql_fetch_array($result);
            $edm_content_url = htmlspecialchars_decode($row['edm_content_url']);
        }
        
        if($error) {
            die("CHECK ERROR " . $error);
        }
        
         // check is human being
        $user_browser = $this->system->common->get_user_browser();
        $browsers = array('ie', 'firefox', 'safari', 'chrome', 'opera', 'webkit', 'lotus', 'gecko');
        if(!in_array($user_browser, $browsers)) {            
            header("Location: {$edm_content_url}");
            exit;            
        }
        
        // update jobs
        $sql = "UPDATE edm_job_{$edm_job_id} SET job_click=job_click+1 WHERE job_id='{$job_id}'";
        mysql_query($sql, $this->edmmisc_action->mysql_jobs->conn);
        
        // update edm_job
        $sql = "UPDATE edm_job SET edm_job_count_click=edm_job_count_click+1 WHERE edm_job_id='{$edm_job_id}'";
        mysql_query($sql, $this->system->mysql->conn);
        
        // redirect
        header("Location: {$edm_content_url}");        
          
    }
    
    function analysis_unsubscribe() {
        
        // get vars
        $edm_job_id = intval($_GET['edm_job_id']);
        $job_to = trim(strip_tags($_GET['job_to']));
        $chk_hash = trim($_GET['chk_hash']);
        
        if(strtoupper($chk_hash) == strtoupper(md5(md5($edm_job_id) . $job_to . SECRET_KEY))) {
            
            // get edm_to_id
            $sql = "SELECT edm_to_id FROM edm_job WHERE edm_job_id={$edm_job_id}";
            $result = mysql_query($sql, $this->system->mysql->conn);
            $row = mysql_fetch_array($result);
            $edm_to_id = $row['edm_to_id'];
            
            // update unsubscribed
            $sql = "UPDATE edm_to_list SET edm_to_value_deleted='1' WHERE edm_to_id=" . $edm_to_id . " AND edm_to_value_hash=CRC32('" . $job_to . "')";
            mysql_query($sql, $this->system->mysql->conn);
            unset($sql);
            
        }
        
        $this->system->smarty->display('service.edm.analysis_unsubscribe.tpl');
    
    }
    
    function get_sender_ip() { 
    
        $r = '';     
                
        $sql = "SELECT edm_ip FROM edm_ip";
        $result = mysql_query($sql, $this->system->mysql->conn);
        while($row = mysql_fetch_array($result)) {
            $r .= "{$row['edm_ip']}\r\n";
        }
        mysql_free_result($result);    
        
        $this->system->smarty->assign('result', $r);
        $this->system->smarty->display('service.edm.get_sender_ip.tpl'); 
        
    }
    
    function node_status() {
        
        if(!COMMAND_LINE && !DEBUG) {
            die('access denied!');   
        }
        
        $sql = "SELECT edm_ip FROM edm_ip";
        $result = mysql_query($sql, $this->system->mysql->conn);
        while($row = mysql_fetch_array($result)) {
echo "ping {$row['edm_ip']}\r\n";
            if(preg_match('/win/i', PHP_OS)) {
                @exec('ping -n 4 ' . $row['edm_ip'], $ping);    
            } else {
                @exec('ping -c 4 ' . $row['edm_ip'], $ping);    
            }           
            if(is_array($ping)) {
                $t = '';
                foreach($ping as $v) {
                    $t .= $v . "\n";    
                }
                $ping = $t;
                unset($v);
                unset($t);
            } else {
                $ping = '';
            }
echo $ping . "\r\n";
            if(!preg_match('/time=([0-9\. ]+)ms/i', $ping)) {
                $m['subject'] = 'can not ping ' . $row['edm_ip'];
echo $m['subject'] . "\r\n";
                $m['body'] = '<p>' . $m['subject'] . '<br>please check it.</p>';
                $m['to'] = MAIL_WEBMASTER;
                $m['result'] = $this->system->common->sendmail($m['subject'], $m['body'], $m['to']);
echo "send result: {$m['result']}\r\n";
                unset($m);    
            } else {
echo "{$row['edm_ip']} status is ok.\r\n";
            }
echo "\r\n-------------------------------------------\r\n";    
        }
        unset($row);
        mysql_free_result($result);
echo "sleep for next check.\r\n";  
        sleep(EDM_JOB_DAEMON_NODE_STATUS_SLEEP_TIME);        
            
    }
    
}
?>
