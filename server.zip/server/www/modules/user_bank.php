<?php
class user_bank {
    
    var $user_bank_id;
    var $user_id;
    var $user_bank_number;
    var $user_bank_user;
    var $user_bank_name;
    var $user_bank_address;
    
}
?>
