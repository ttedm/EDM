<?php
//标识
class agent_action {
    
    var $system;
    var $agent;
    
    function agent_action(&$system) {
        
        $this->system = $system;

        $this->system->check_login();
        
        $this->agent = unserialize($_SESSION['user']);
        
        if($this->agent->user_type < USER_AGENT || empty($this->agent->user_type)) {
            $this->system->set_403();
        }
        
        $action = $this->system->action;

        if($action == 'show') {
            $this->show();
        }
        
        if($action == 'detail') {
            $this->detail();
        }

        if($action == 'lock') {
            $this->lock();
        }
        
        if($action == 'set_agent') {
            $this->set_agent();
        }
        
        if($action == 'reset_password') {
            $this->reset_password();
        }
        
        if($action == 'charge') {
            $this->charge();        
        }
        
        if($action == 'set_price') {
            $this->set_price();        
        }
        
        if($action == 'bank') {
            $this->bank();        
        }
        
        if($action == 'add_bank') {
            $this->add_bank();        
        }
        
        if($action == 'delete_bank') {
            $this->delete_bank();        
        }
        
    }
    
    function show() {
        
        //$sql = "SELECT user_id, user_name, user_contact, user_email, user_mobile, user_type, user_lock, user_register_time FROM user WHERE user_pid='{$this->agent->user_id}'";
        $sql = "SELECT
  `user`.`user_id`, `user`.`user_name`, `user`.`user_contact`,
  `user`.`user_email`, `user`.`user_mobile`, `user`.`user_type`,
  `user`.`user_lock`, `user`.`user_register_time`,
  `product_price`.`product_available_count`,
  `product_price`.`product_used_count`
FROM
  `product_price` INNER JOIN
  `user` ON `product_price`.`user_id` = `user`.`user_id` 
  WHERE `product_price`.`product_id`='1' AND `user`.`user_pid`='{$this->agent->user_id}'";
        
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        $user = array();
        
        while($row = mysql_fetch_array($result)) {
            if($row['product_available_count'] < 200 && $row['product_used_count'] < 200) {
                $user_trial = 1;
            } else {
                $user_trial = 0;
            }
            $user[] = array('user_id' => $row['user_id'],
                            'user_name' => $row['user_name'],
                            'user_contact' => $row['user_contact'],
                            'user_email' => $row['user_email'],
                            'user_mobile' => $row['user_mobile'],
                            'user_lock' => $row['user_lock'],
                            'user_type' => $row['user_type'],
                            'user_register_time' => date('Y-m-d', $row['user_register_time']),
                            'user_trial' => $user_trial,
                            );
            unset($user_trial);
        }
        
        $this->system->smarty->assign('user_show', $user);
        $this->system->smarty->display('system.agent.show.tpl');
        
    }
    
    function detail() {
        
        // user detail
        $user = new user();
        
        $user->user_id = intval($_GET['user_id']);
       
        $sql = "SELECT user_pid, user_name, user_type, user_email, user_mobile, user_contact, user_corporation, user_telephone, user_fax, user_zipcode, user_address, user_qq, user_msn, user_domain, user_lock FROM user WHERE user_id='{$user->user_id}'";
        
//print($sql);

        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        foreach($row as $k => $v) {
            $user->$k = $v;
        }
        
        // check agent and user relationship
        if($this->agent->user_id != $user->user_pid) {
            $this->system->set_403();
        }
        
        $this->system->smarty->assign('detail_user', get_object_vars($user));
        
        $cronjob_action = new cronjob_action($this->system);
        $cronjob_action->set_user_product_init($user->user_id);
        $cronjob_action->set_user_father_product_init($user->user_id);
        
        // bill detail
        
        $sql = "SELECT p.product_name AS product_name, p.product_unit AS product_unit, pp.product_available_count AS product_available_count, pp.product_used_count AS product_used_count, pp.product_used_count + pp.product_available_count AS product_count FROM product p LEFT JOIN product_price pp ON p.product_id=pp.product_id WHERE pp.user_id='{$user->user_id}' ORDER BY p.product_order ASC";
        
//print($sql);

        $result = mysql_query($sql, $this->system->mysql->conn);
        
        $detail_price = array();
        
        while($row = mysql_fetch_array($result)) {
            $detail_price[] = $row;
        }
        
        $this->system->smarty->assign('detail_price', $detail_price);

        $this->system->smarty->display('system.agent.detail.tpl'); 
    
    }
    
    function lock() {
        
        // check user agent relationship
        
        $user = new user();
        
        $user->user_id = intval($_GET['user_id']);
        
        $sql = "SELECT user_pid, user_name, user_lock FROM user WHERE user_id='{$user->user_id}'";
        
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        foreach($row as $k => $v) {
            $user->$k = $v;
        }
        
        if($this->agent->user_id != $user->user_pid) {
            $this->system->set_403();
        }
        
        // user lock

        if($user->user_lock == USER_LOCK) {
            $user->user_lock = USER_UNLOCK;
            $message = "{$user->user_name} 的账户已经恢复正常！";    
        } else {
            $user->user_lock = USER_LOCK;
            $message = "{$user->user_name} 的账户已经锁定！";             
        }
        
        $sql = "UPDATE user SET user_lock='{$user->user_lock}' WHERE user_id='{$user->user_id}'";
        mysql_query($sql, $this->system->mysql->conn);
        
        $info_action = new info_action($this->system);
        $info_action->send($message, 'tree=system.agent.show'); 
   
    }

    
    function charge() {
        
        // check user agent ~~
        $user = new user();
        
        $user->user_id = intval($_GET['user_id']);
       
        $sql = "SELECT user_pid, user_name FROM user WHERE user_id='{$user->user_id}'";

        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        foreach($row as $k => $v) {
            $user->$k = $v;
        }
        
        // check agent and user relationship
        if($this->agent->user_id != $user->user_pid) {
            $this->system->set_403();
        }
        
        $this->system->smarty->assign('agent_user', get_object_vars($user));
        
        // charge
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            
            // get agent info
            $sql = "SELECT p.product_id AS product_id, pp.product_price_id AS product_price_id, p.product_name AS product_name, p.product_slug AS product_slug, p.product_unit AS product_unit, pp.product_available_count AS product_available_count FROM product p LEFT JOIN product_price pp ON p.product_id=pp.product_id WHERE pp.user_id='{$this->agent->user_id}' ORDER BY p.product_order ASC";
            
//print_r($sql);
            $result = mysql_query($sql, $this->system->mysql->conn);
            
            $message = '';
            
            while($row = mysql_fetch_array($result)) {
                
                $agent_product = $row;
                
                $post_string = 'p' . $agent_product['product_id'];
                $charge = intval($_POST[$post_string]);
                
                if($charge < 0) {
                    $charge = 0;
                }
                
                if($charge > intval($agent_product['product_available_count'])) {
                    
                    $message .= "为 {$user->user_name} 充值 {$agent_product['product_slug']} {$charge} 单位数量时出现错误！充值超出了库存量，请从上级经销商处进货！<br>";
                
                } else {
                    
                    if($charge > 0) {
                        
                        // agent --
                        $sql = "UPDATE product_price SET product_available_count=product_available_count-{$charge}, product_used_count=product_used_count+{$charge} WHERE product_price_id={$agent_product['product_price_id']}";
                        mysql_query($sql, $this->system->mysql->conn);
                        
                        // agent user ++
                        $sql = "UPDATE product_price SET product_available_count=product_available_count+{$charge} WHERE product_id={$agent_product['product_id']} AND user_id={$user->user_id}";
                        mysql_query($sql, $this->system->mysql->conn);
                        
                        // billing insert
                        $billing_action = new billing_action($this->system);
                        $billing_action->billing_recharge($this->agent->user_id, $user->user_id, $agent_product['product_slug'], $charge);
                        
                        $message .= "已完成为 {$user->user_name} 充值 {$agent_product['product_slug']} {$charge} {$agent_product['product_unit']}。<br>";
                    }
                
                }
                
                unset($agent_product);
                
            }
            
            $info_action = new info_action($this->system);
            $info_action->send($message, "tree=system.agent.detail&user_id={$user->user_id}");
                        
        
        } else {
            
            // set default product price
            $cronjob_action = new cronjob_action($this->system);
            $cronjob_action->set_user_product_init($user->user_id);
            $cronjob_action->set_user_father_product_init($user->user_id);
            
            // get agent product_id and product_avaiable_count
            $sql = "SELECT p.product_id AS product_id, p.product_name AS product_name, p.product_unit AS product_unit, p.product_slug AS product_slug, pp.product_available_count AS product_available_count FROM product p LEFT JOIN product_price pp ON p.product_id=pp.product_id WHERE pp.user_id='{$this->agent->user_id}' ORDER BY p.product_order ASC";
            
//print_r($sql);
            $result = mysql_query($sql, $this->system->mysql->conn);
            
            $agent_product = array();
            
            while($row = mysql_fetch_array($result)) {
                $agent_product[] = $row;
            }
            
            $this->system->smarty->assign('agent_product', $agent_product);
            
            $this->system->smarty->display('system.agent.charge.tpl');
        }
    
    }
    
    function set_agent() {
        
        // check user agent relationship
        
        $user = new user();
        
        $user->user_id = intval($_GET['user_id']);
        
        $sql = "SELECT user_pid, user_name, user_type FROM user WHERE user_id='{$user->user_id}'";
        
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        foreach($row as $k => $v) {
            $user->$k = $v;
        }
        
        if($this->agent->user_id != $user->user_pid) {
            $this->system->set_403();
        }
        
        // set agent

        if($user->user_type == USER_END_USER) {
            
            $user->user_type = USER_AGENT;
            
            $sql = "UPDATE user SET user_type='{$user->user_type}' WHERE user_id='{$user->user_id}'";
            mysql_query($sql, $this->system->mysql->conn);
        
            $message = "{$user->user_name} 成功提升级别为经销商！";
               
        } else {
            $message = "{$user->user_name} 已经是经销商，无需再次提升级别！";             
        }

        $info_action = new info_action($this->system);
        $info_action->send($message, 'tree=system.agent.show'); 
    
    }
    
    function reset_password() {
        
        // check user agent relationship
        
        $user = new user();
        
        $user->user_id = intval($_GET['user_id']);
        
        $sql = "SELECT user_pid, user_name FROM user WHERE user_id='{$user->user_id}'";
        
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        foreach($row as $k => $v) {
            $user->$k = $v;
        }
        
        if($this->agent->user_id != $user->user_pid) {
            $this->system->set_403();
        }
        
        // reset password
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            
            $user->user_password = trim($_POST['user_new_password']);
            $user_new_password_two = trim($_POST['user_new_password_two']); 
            
            // check password value
            $error = 0;
            $error_message = '';
            $valid = new valid();
            
            if(!$valid->is_password($user->user_password, 6, 16)) {
                $error = 1;
                $error_message .= '新密码必须是 6 到 16 位的英文字母，数字和下划线！<br>';   
            }
            
            if($user->user_password != $user_new_password_two) {
                $error = 1;
                $error_message .= '两次输入的新密码必须一致！<br>';              
            } 
            
            if($error == 1) {
                $info_action = new info_action($this->system);
                $info_action->send($error_message, "tree=system.agent.reset_password&user_id={$user->user_id}");              
            }
            
            // reset password
            
            $user_new_password_sha1 = sha1($user->user_password);
            $sql = "UPDATE user SET user_password='{$user_new_password_sha1}' WHERE user_id='{$user->user_id}'";
            mysql_query($sql, $this->system->mysql->conn);
            
            $info_action = new info_action($this->system);
            $info_action->send('密码已重设！', 'tree=system.agent.show'); 
 
        
        } else {
            $this->system->smarty->assign('agent_user', get_object_vars($user));
            $this->system->smarty->display('system.agent.reset_password.tpl');
        }

    
    }
    
    function set_price() {
        
       // set_price
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            
            $sql = "SELECT product_id, product_slug FROM product ORDER BY product_order ASC";
            $result = mysql_query($sql, $this->system->mysql->conn);
            
            $message = '';
            
            while($row = mysql_fetch_array($result)) {
                
                $product = $row;
                
                $du = $this->system->common->price_format($_POST["du{$product['product_id']}"], 9999999, 4);
                $dm = $this->system->common->price_format($_POST["dm{$product['product_id']}"], 9999999, 2);
                $au = $this->system->common->price_format($_POST["au{$product['product_id']}"], 9999999, 4); 
                $am = $this->system->common->price_format($_POST["am{$product['product_id']}"], 9999999, 2);
                
                $sql = "UPDATE product_price SET product_direct_unit_price='{$du}', product_direct_mini_price='{$dm}', product_agent_unit_price='{$au}', product_agent_mini_price='{$am}' WHERE product_id='{$product['product_id']}' AND user_id='{$this->agent->user_id}'";
                mysql_query($sql, $this->system->mysql->conn);
                
                $message .= "{$product['product_slug']} 产品的价格已经更新。<br>";
            
            }
            
            $info_action = new info_action($this->system);
            $info_action->send($message, 'tree=system.agent.set_price');
        
        } else {
            
            $sql = "SELECT user_pid FROM user WHERE user_id='{$this->agent->user_id}'";
            $result = mysql_query($sql, $this->system->mysql->conn);
            $row = mysql_fetch_array($result);
            
            $this->agent->user_pid = $row['user_pid'];
            
            $sql = "SELECT p.product_id AS product_id, p.product_name AS product_name, p.product_unit AS product_unit, p.product_slug AS product_slug, ppf.product_direct_unit_price AS ppf_product_direct_unit_price, ppf.product_agent_unit_price AS ppf_product_agent_unit_price, pp.product_direct_unit_price AS product_direct_unit_price, pp.product_direct_mini_price AS product_direct_mini_price, pp.product_agent_unit_price AS product_agent_unit_price, pp.product_agent_mini_price AS product_agent_mini_price FROM product p LEFT JOIN product_price ppf ON p.product_id=ppf.product_id LEFT JOIN product_price pp ON p.product_id=pp.product_id WHERE ppf.user_id={$this->agent->user_pid} AND pp.user_id={$this->agent->user_id} ORDER BY p.product_order ASC";
            
            $result = mysql_query($sql, $this->system->mysql->conn);
            
            $product_price = array();
            
            while($row = mysql_fetch_array($result)) {
                $product_price[] = $row;
            }
            
            $this->system->smarty->assign('product_price', $product_price);
            $this->system->smarty->display('system.agent.set_price.tpl');
        
        }
    
    }
    
    function bank() {
        
        $sql = "SELECT user_bank_id, user_bank_name, user_bank_number, user_bank_user, user_bank_name, user_bank_address FROM user_bank WHERE user_id='{$this->agent->user_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        $user_bank = array();
        
        while($row = mysql_fetch_array($result)) {
            $user_bank[] = $row;
        }
        
        $this->system->smarty->assign('user_bank', $user_bank);
        $this->system->smarty->display('system.agent.bank.tpl');
    
    }
    
    function add_bank() {
        
        $user_bank = new user_bank();
        
        $user_bank->user_bank_name      = trim(strip_tags($_POST['user_bank_name']));
        $user_bank->user_bank_number    = trim($_POST['user_bank_number']);
        $user_bank->user_bank_user      = trim(strip_tags($_POST['user_bank_user']));
        $user_bank->user_bank_address   = trim(strip_tags($_POST['user_bank_address']));
        
        $error = 0;
        $error_message = '';
        $valid = new valid();
        
        if(!$valid->is_valid_length($user_bank->user_bank_name, 2, 30)) {
            $error = 1;
            $error_message .= '请填写正确的银行名称。如：中国工商银行。<br>';             
        }
        if(!$valid->is_valid_length($user_bank->user_bank_user, 2, 100)) {
            $error = 1;
            $error_message .= '请填写正确的银行卡账户名。如：克林顿。<br>';             
        }
        if(!$valid->is_bank_number($user_bank->user_bank_number)) {
            $error = 1;
            $error_message .= '请填写正确的银行卡号。15-20 位数字。<br>';             
        }
        if(!$valid->is_valid_length($user_bank->user_bank_address, 2, 200)) {
            $error = 1;
            $error_message .= '请填写正确的银行卡开户行名称。如：中国工商银行上海分行。<br>';         
        }
        if($error) {
            $info_action = new info_action($this->system);
            $info_action->send($error_message, 'tree=system.agent.bank');
        }
        
        $sql = "SELECT count(user_bank_id) AS count FROM user_bank WHERE user_id='{$this->agent->user_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        $count = $row['count'];
        
        if($count > 4) {
            $info_action = new info_action($this->system);
            $info_action->send('银行卡号已经达到上限，不能继续添加银行卡了。', 'tree=system.agent.bank');        
        }
        
        $sql = "INSERT INTO user_bank(user_id, user_bank_number, user_bank_user, user_bank_name, user_bank_address) VALUES('{$this->agent->user_id}', '{$user_bank->user_bank_number}', '{$user_bank->user_bank_user}', '{$user_bank->user_bank_name}', '{$user_bank->user_bank_address}')";
        
 //print($sql);
        mysql_query($sql, $this->system->mysql->conn);

        $info_action = new info_action($this->system);
        $info_action->send('银行卡号已添加！', 'tree=system.agent.bank');
    
    }
    
    function delete_bank() {

        // check user_bank user relationship
        
        $user_bank = new user_bank();
        
        $user_bank->user_bank_id = intval($_GET['user_bank_id']);
        
        $sql = "SELECT user_id FROM user_bank WHERE user_bank_id='{$user_bank->user_bank_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        $user_bank->user_id = $row['user_id'];
        
        if($this->agent->user_id != $user_bank->user_id) {
            $this->system->set_403();
        }    
        
        // delete user_bank account
        
        $sql = "DELETE FROM user_bank WHERE user_bank_id='{$user_bank->user_bank_id}'";
        mysql_query($sql, $this->system->mysql->conn);
        
        $info_action = new info_action($this->system);
        $info_action->send('银行卡号已删除！', 'tree=system.agent.bank');
    }
    
}
?>
