<?php
class cronjob_action {
    
    var $system;
    
    function cronjob_action(&$system) {
        $this->system = $system;
    }
    
    function set_user_product_init($user_id = 0) {
        
        $user = unserialize($_SESSION['user']);
        
        if($user_id == 0) {
            $user_id = $user->user_id;    
        }
        
        $sql = "SELECT product_id FROM product";
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        while($row = mysql_fetch_array($result)) {
            
            $product_id = $row['product_id'];
            $sqlx = "SELECT product_price_id FROM product_price WHERE product_id='{$product_id}' AND user_id='{$user_id}'";
            $resultx = mysql_query($sqlx, $this->system->mysql->conn);
            $numx = mysql_num_rows($resultx);
            
            if($numx < 1) {
                $sqlx = "INSERT INTO product_price(product_id, user_id, product_available_count) VALUES('{$product_id}', '{$user_id}', 10)";
                mysql_query($sqlx, $this->system->mysql->conn);
            }           
        }
    
    }
    
    function set_user_father_product_init($user_id = 0) {
        
        $user = unserialize($_SESSION['user']);
        
        if($user_id == 0) {
            $user_id = $user->user_id;    
        }
        
        $sql = "SELECT user_pid FROM user WHERE user_id='{$user_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        $user_pid = $row['user_pid'];
        
        $sql = "SELECT product_id FROM product";
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        while($row = mysql_fetch_array($result)) {
            
            $product_id = $row['product_id'];
            $sqlx = "SELECT product_price_id FROM product_price WHERE product_id='{$product_id}' AND user_id='{$user_pid}'";
            $resultx = mysql_query($sqlx, $this->system->mysql->conn);
            $numx = mysql_num_rows($resultx);
            
            if($numx < 1) {
                $sqlx = "INSERT INTO product_price(product_id, user_id, product_available_count) VALUES('{$product_id}', '{$user_pid}', 10)";
                mysql_query($sqlx, $this->system->mysql->conn);
            }           
        }
        
    
    }
}
?>
