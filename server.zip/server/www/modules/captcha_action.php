<?php
// 标识
class captcha_action {
    
    var $system;
    
    function captcha_action($system) {
        
        $this->system = $system;
        $action = $this->system->action;
        if($action == 'show') {
            $this->show();        
        }            
        
    }
    
    function show() {
    
        $this->system->common->captcha();
        exit;
    }

} 
?>
