<?php

class edm_uip {

    var $edm_uip_id;
    var $edm_uip_group;
    var $edm_uip_start;
    var $edm_uip_end;
    
}
?>
