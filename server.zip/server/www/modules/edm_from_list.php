<?php
  //标识
class edm_from_list{
    
    var $edm_from_list_id;
    var $edm_from_id;
    var $edm_from_list_start;
    var $edm_from_list_end;
    var $edm_from_list_middle_start;
    var $edm_from_list_middle_end;
      
}
?>
