<?php
//标识
class product_action {
    
    var $system;
    var $product;
    var $product_price;  

    function product_action(&$system) {
        
        $this->system = $system;
       
        $action = $system->action;
        
        if($action == 'show_price') {
            $this->show_price();
        }
        
        if($action == 'add_category') {
            $this->add_category();
        }
        if($action == 'show_category') {
            $this->show_category();
        }
        if($action == 'delete_category') {
            $this->delete_category();
        }
  
    }
    
    function show_price() {
        
        $this->system->check_login();
        
        $user = unserialize($_SESSION['user']);
        
        $sql = "SELECT user_pid FROM user WHERE user_id='{$user->user_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        $user->user_pid = $row['user_pid'];
        unset($row);
        
        $sql = "SELECT p.product_name AS product_name, p.product_unit AS product_unit, ppf.product_direct_unit_price AS product_direct_unit_price, ppf.product_direct_mini_price AS product_direct_mini_price, ppf.product_agent_unit_price AS product_agent_unit_price, ppf.product_agent_mini_price AS product_agent_mini_price, pp.product_available_count AS product_available_count, pp.product_used_count AS product_used_count, ppf.product_available_count AS father_product_available_count FROM product p LEFT JOIN product_price ppf ON p.product_id=ppf.product_id LEFT JOIN product_price pp ON p.product_id=pp.product_id WHERE ppf.user_id='{$user->user_pid}' AND pp.user_id='{$user->user_id}' ORDER BY p.product_order ASC";
        
//print($sql);
        
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        $product_price = array();
        
        while($row = mysql_fetch_array($result)) {
            $product_price[] = $row;     
        }
        
        $this->system->smarty->assign('product_price', $product_price);
        $this->system->smarty->display('system.product.show_price.tpl');
    }
    
   
    function add_category() {
        
        $this->system->check_login();
        
        $user = unserialize($_SESSION['user']);
        
        if($user->user_type == USER_ADMINISTRATOR) {
            
            if($_SERVER['REQUEST_METHOD'] =='POST'){
                
                $this->product = new product();
                $this->product->prodcut_slug = trim($_POST['product_slug']);
                $this->product->product_name = trim($_POST['product_name']);
                $this->product->product_order = trim($_POST['product_order']);
                $this->product->product_unit = trim($_POST['product_unit']);
                
//print_r($this->product);
                
                $error = 0;
                $error_message = '';
                
                if($this->product->prodcut_slug == '') {
                    $error = 1;
                    $error_message .= '产品英文名称错误！<br>';
                }
                
                if($this->product->product_name == '') {
                    $error = 1;
                    $error_message .= '产品中文名称错误！<br>';
                }
                
                if($this->product->product_order == '') {
                    $error = 1;
                    $error_message .= '产品排序错误！<br>';
                }
                if($this->product->product_unit == '') {
                    $error = 1;
                    $error_message .= '产品单位错误！<br>';
                }
                
                if($error) {
                    $info_action = new info_action($this->system);
                    $info_action->send($error_message, 'tree=system.product.add_category');
                }
                
                // check slug
                $sql = "SELECT product_id FROM product WHERE product_slug='{$this->product->prodcut_slug}'";
                $result = mysql_query($sql, $this->system->mysql->conn);
                $num_row = mysql_num_rows($result);
                
                if($num_row > 0) {
                    $info_action = new info_action($this->system);
                    $info_action->send('产品类别已经存在！', 'tree=system.product.add_category');                    
                }
                
                // insert slug
                $sql = "INSERT INTO product(product_slug, product_name, product_unit, product_order) VALUES('{$this->product->prodcut_slug}', '{$this->product->product_name}', '{$this->product->product_unit}', '{$this->product->product_order}')";
                mysql_query($sql, $this->system->mysql->conn);
                
               
                $info_action = new info_action($this->system);
                $info_action->send('产品类别成功添加！', 'tree=system.product.show_category');     
                
            } else {
                
                $this->system->smarty->display('system.product.add_category.tpl');
                
            }
            
        } else {
            $this->system->set_403();
        }
    
    }
    
    function show_category() {
        
        $this->system->check_login();
        
        $user = unserialize($_SESSION['user']);
        
        if($user->user_type == USER_ADMINISTRATOR) {
            
            $this->product = new product();
            
            $sql = "SELECT * FROM product ORDER BY product_order ASC";
            $result = mysql_query($sql, $this->system->mysql->conn);
            
            $category = array();
            while($row = mysql_fetch_array($result)) {
                $category[] = $row;
            }
            
            $this->system->smarty->assign('category', $category);
            
            unset($category);
            
            $this->system->smarty->display('system.product.show_category.tpl');
            
            
                
       } else {
            $this->system->set_403();
       }
    
    }
    
    function delete_category() {
        
        $this->system->check_login();
        
        $user = unserialize($_SESSION['user']);
        
        if($user->user_type == USER_ADMINISTRATOR) {
            
            $this->product = new product();
            
            $this->product->product_id = trim($_GET['product_id']);
            
            if($this->product->product_id == '') {
                $info_action = new info_action($this->system);
                $info_action->send('删除操作参数错误！', 'tree=system.product.show_category');
            }
            
            $sql = "DELETE FROM product WHERE product_id='{$this->product->product_id}'";
            mysql_query($sql, $this->system->mysql->conn);
            
            $info_action = new info_action($this->system);
            $info_action->send('产品类别已删除！', 'tree=system.product.show_category');            
             
        } else {
            $this->system->set_403();
        }
    
    }
    

}

?>
