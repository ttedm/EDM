<?php
//标识
class edm_ip{

    var $edm_ip_id;
    var $edm_ip_group_id;
    var $edm_ip;
        
}

?>
