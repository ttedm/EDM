<?php
//标识
class sys{
    
    var $smarty;
    var $common;
    var $mysql;
    
    var $category;
    var $module;
    var $action;
    
    function init() {
        
        // require files
        $this->require_files();
        
        // set timezone
        date_default_timezone_set('Asia/Shanghai');
        
        $this->common = new common();
        $this->common->gpc_escape();         
        
        // set php ini
        $this->common->set_php_ini();
        
        // smarty init
        $this->smarty_init();
        
        // tree init
        $this->tree_init();
         
        // mysql init
        $this->mysql_init();
        
        // core init
        $this->core_init();
       
    }
    
    function smarty_init() {
    
        $this->smarty = new Smarty(); 
        $this->smarty->template_dir   = ROOT_PATH . TEMPLATE_PATH;
        $this->smarty->cache_dir      = ROOT_PATH . '/temp/caches';
        $this->smarty->compile_dir    = ROOT_PATH . '/temp/compiled';
        $this->smarty->left_delimiter = "{{"; //左定界符 
        $this->smarty->right_delimiter = "}}"; //右定界符 
    }
    
    function mysql_init() {
        
        $this->mysql = new mysql();
        $this->mysql->set_vars(MYSQL_HOST, MYSQL_USERNAME, MYSQL_PASSWORD);
        $this->mysql->get_connection();
        
        if(!$this->mysql->conn) {
            $info_action = new info_action($this);
            $info_action->send('数据库 DMS 连接错误，请与管理员联系。', '');       
        }
        
        $this->mysql->set_parameters();
        $this->mysql->use_db(MYSQL_DATABASE);    
    }
    
    function require_files(){
       
        // require configuration
        require_once(ROOT_PATH . '/data/config.php');
        require_once(ROOT_PATH . '/data/define.php');
        
        // require library
        require_once(ROOT_PATH . '/includes/common.php');
        require_once(ROOT_PATH . '/includes/valid.php');
        require_once(ROOT_PATH . '/includes/mysql.php'); 
        require_once(ROOT_PATH . '/includes/file_upload.php');
        require_once(ROOT_PATH . '/includes/file_log.php');
        require_once(ROOT_PATH . '/includes/gaza.php');
        require_once(ROOT_PATH . '/includes/simple_html_dom.php');   
        require_once(ROOT_PATH . '/includes/smarty/Smarty.class.php');
        require_once(ROOT_PATH . '/includes/smarty/SmartyPaginate.class.php');
        require_once(ROOT_PATH . '/includes/phpmailer/class.phpmailer.php');
        
        
        // require module
        
        require_once(ROOT_PATH . '/modules/info.php');
        
        require_once(ROOT_PATH . '/modules/user.php'); 
        require_once(ROOT_PATH . '/modules/user_login.php');
        require_once(ROOT_PATH . '/modules/user_bank.php');
        
        require_once(ROOT_PATH . '/modules/billing.php');        
        
        require_once(ROOT_PATH . '/modules/product.php');
        require_once(ROOT_PATH . '/modules/product_price.php');
         
        
        require_once(ROOT_PATH . '/modules/edm_from.php');
        require_once(ROOT_PATH . '/modules/edm_from_list.php');
        
        require_once(ROOT_PATH . '/modules/edm_ip.php');
        require_once(ROOT_PATH . '/modules/edm_ip_group.php');
        
        require_once(ROOT_PATH . '/modules/edm_to.php');
        require_once(ROOT_PATH . '/modules/edm_to_list.php');
        
        require_once(ROOT_PATH . '/modules/edm_content.php');
        
        require_once(ROOT_PATH . '/modules/edm_job.php');
                
        require_once(ROOT_PATH . '/modules/edm_ua.php');
        require_once(ROOT_PATH . '/modules/edm_uhost.php'); 
        require_once(ROOT_PATH . '/modules/edm_uip.php');

                
        // require module action
        require_once(ROOT_PATH . '/modules/captcha_action.php');
        require_once(ROOT_PATH . '/modules/cronjob_action.php');
        
        require_once(ROOT_PATH . '/modules/user_action.php');
        require_once(ROOT_PATH . '/modules/info_action.php');
        require_once(ROOT_PATH . '/modules/product_action.php');
        require_once(ROOT_PATH . '/modules/agent_action.php');
        require_once(ROOT_PATH . '/modules/billing_action.php');
        
        require_once(ROOT_PATH . '/modules/edmmisc_action.php');       
        require_once(ROOT_PATH . '/modules/edmadmin_action.php');
        require_once(ROOT_PATH . '/modules/edmuser_action.php');

        
        // daemon action 
        require_once(ROOT_PATH . '/modules/service_edm_action.php');
        
        
        require_once(ROOT_PATH . '/modules/service_api_action.php');         
        
        
    }
    
    function core_init() {
    
        
        if($this->category == 'system') {
            
            if($this->module == 'user') {
                new user_action($this);
            }
            
            if($this->module == 'captcha'){
                new captcha_action($this);
            }
            
            if($this->module == 'product') {
                new product_action($this);
            }
            
            if($this->module == 'agent') {
                new agent_action($this);
            }
            
            if($this->module == 'billing') {
                new billing_action($this);
            }
            
        }
        
        if($this->category == 'service') {
            
            if($this->module == 'edm') {
                new service_edm_action($this);
            }
            
            if($this->module == 'api') {
                new service_api_action($this);
            }
        
        }
        
        if($this->category == 'edm') {
            
            if($this->module == 'edmadmin') {
                new edmadmin_action($this);
            }
            
            if($this->module == 'edmuser') {
                new edmuser_action($this);
            }
        
        }
        
        if($this->category == 'sms') {
        
        }
    }
    
    function tree_init() {
        
        if(GLOBAL_TREE) {
            $tree = trim(strtolower(GLOBAL_TREE));
        } else {
            $tree = 'system.user.login';        
        }
 
        $tree_array = explode('.', $tree);
        
        list($this->category, $this->module, $this->action) = $tree_array;
        
        // session
        if(!COMMAND_LINE && $this->category != 'service') {
            session_start();         
        }
        
        // header no cache
        //if(!COMMAND_LINE) {
            //$this->common->set_no_cache();
        //}
       
        // info_action no need db and core init 
        if($tree == 'system.info.show') {
            new info_action($this);
        }
            
    }
    
    function check_login() {
        if(empty($_SESSION['user'])) {
            $this->common->set_location($this->common->make_url('tree=system.user.logout'));
        } else {
            $user = unserialize($_SESSION['user']);
            $this->smarty->assign('header_user', get_object_vars($user));
        }
    }
    
    function set_403() {
        $info_action = new info_action($this);
        $info_action->send('403, 您没有权限访问这些内容！', 'tree=system.user.logout');
    }
    
    
}  
?>
