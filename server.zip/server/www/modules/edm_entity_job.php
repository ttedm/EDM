<?php
//标识
class edm_entity_job{

    var $id;
    var $from;
    var $to;
    var $outboundip;
    var $status;
    var $open;
    var $click;
    var $time;
    var $bounce;
    
}
?>
