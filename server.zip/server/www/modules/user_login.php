<?php
// 标识
class user_login { 
    
    var $user_login_id;
    var $user_id;
    var $user_login_ip;
    var $user_login_time;
    
    
}
  
?>
