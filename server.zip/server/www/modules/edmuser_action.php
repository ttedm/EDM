<?php
class edmuser_action {

    var $system;
    var $user;
    var $edmmisc_action;
    
    function edmuser_action(&$system) {
        
        $this->system = $system;
        
        $this->system->check_login();
        
        $this->user = unserialize($_SESSION['user']);
        
        $this->edmmisc_action = new edmmisc_action($this->system);
        
        $action = $this->system->action;
        
        // to
        if($action == 'to') {
            $this->to();
        }
        if($action == 'to_new') {
            $this->to_new();
        }
        if($action == 'to_add') {
            $this->to_add();
        }
        if($action == 'to_mod') {
            $this->to_mod();
        }
        if($action == 'to_del') {
            $this->to_del();
        }
        if($action == 'to_export') {
            $this->to_export();
        }
        
        // content
        if($action == 'content') {
            $this->content();
        }
        if($action == 'content_new') {
            $this->content_new();
        }
        if($action == 'content_add') {
            $this->content_add();
        }
        if($action == 'content_mod') {
            $this->content_mod();
        }
        if($action == 'content_del') {
            $this->content_del();
        }
        
        // job
        if($action == 'job') {
            $this->job();
        }
        if($action == 'job_add') {
            $this->job_add();
        }
        if($action == 'job_detail') {
            $this->job_detail();
        }
        if($action == 'job_name_modify') {
            $this->job_name_modify();
        }
        if($action == 'job_soft_resent') {
            $this->job_soft_resent();
        }
        if($action == 'job_all_resent') {
            $this->job_all_resent();
        }
        if($action == 'job_pause') {
            $this->job_pause();
        }
        
        // analysis
        if($action == 'analysis') {
            $this->analysis();
        }
        
        if($action == 'analysis_export') {
            $this->analysis_export();
        }
        
        // API
        if($action == 'api') {
            $this->api();
        }

    }
    
    // to
    
    function to() {
        
        SmartyPaginate::connect('edm_edmuser_to');       
        SmartyPaginate::setUrlVar('start', 'edm_edmuser_to');
        SmartyPaginate::setURL('/?tree=edm.edmuser.to', 'edm_edmuser_to');
        SmartyPaginate::setLimit(10, 'edm_edmuser_to');
        SmartyPaginate::setPrevText('上一页', 'edm_edmuser_to');
        SmartyPaginate::setNextText('下一页', 'edm_edmuser_to');
        SmartyPaginate::setFirstText('首页', 'edm_edmuser_to');
        SmartyPaginate::setLastText('末页', 'edm_edmuser_to');
        SmartyPaginate::setPageLimit(10, 'edm_edmuser_to');
        
        // get counter
        $sql = "SELECT count(edm_to_id) AS c FROM edm_to WHERE user_id={$this->user->user_id} AND edm_to_is_delete=0";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        SmartyPaginate::setTotal($row['c'], 'edm_edmuser_to');
        
        // get data grid
        $sql = "SELECT edm_to_id, edm_to_group, edm_to_count FROM edm_to WHERE user_id='{$this->user->user_id}' AND edm_to_is_delete=0 ORDER BY edm_to_group ASC LIMIT %d,%d";
        $sql = sprintf($sql, SmartyPaginate::getCurrentIndex('edm_edmuser_to'), SmartyPaginate::getLimit('edm_edmuser_to'));
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        $edm_to_array = array();
        
        while($row = mysql_fetch_array($result)) {
            $edm_to_array[] = $row;
        }
        
        $this->system->smarty->assign('edm_to', $edm_to_array);
        SmartyPaginate::assign(&$this->system->smarty, 'paginate', 'edm_edmuser_to');
        $this->system->smarty->display('edm.edmuser.to.tpl');
    
    }
    
    function to_new() {
        
        $this->system->smarty->display('edm.edmuser.to_new.tpl');
           
    }
    
    function to_add() {
        
        $edm_to = new edm_to();
        $edm_to->edm_to_group = str_replace(' ', '-', trim(strip_tags($_POST['edm_to_group'])));
        $edm_to_file = new file_upload('edm_to_file');
        
        $error = 0;
        $error_message = '';
        $valid = new valid();
        
        if(!$valid->is_valid_length($edm_to->edm_to_group, 1, 50)) {
            $error = 1;
            $error_message .= "邮箱列表名称不能大于 50 个字符且不能是空值。请重新填写！<br>";
        }
        if($edm_to_file->error != '0') {
            $error = 1;
            $error_message .= "{$edm_to_file->message} 请重新上传!<br>";
        }
        if($error) {
            $edm_to_file->delete();
            $info_action = new info_action($this->system);
            $info_action->send($error_message, 'tree=edm.edmuser.to_new');
        }
        
        // check group exists
        $sql = "SELECT count(edm_to_id) AS count FROM edm_to WHERE user_id='{$this->user->user_id}' AND edm_to_group='{$edm_to->edm_to_group}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        if($row['count'] > 0) {
            $edm_to_file->delete();
            $info_action = new info_action($this->system);
            $info_action->send('邮箱列表名称已经存在。请重新填写！', 'tree=edm.edmuser.to_new');            
        }
        
        // check edm_to count < 2000
        $sql = "SELECT count(edm_to_id) AS count FROM edm_to WHERE user_id='{$this->user->user_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        if($row['count'] > 2000) {
            $edm_to_file->delete();
            $info_action = new info_action($this->system);
            $info_action->send('邮箱列表最多可添加 2000 个。<br>如果需要添加更多邮件列表，请联系上级经销商，申请新用户。<br>', 'tree=edm.edmuser.to_new');            
        }        
        
        // get email addr
        $edm_to_email = $this->edmmisc_action->get_email_from_file($edm_to_file->tmp_name, 50000);
        if(!$edm_to_email) {
            $edm_to_file->delete();
            $info_action = new info_action($this->system);
            $info_action->send('上传的文件中不存在邮件地址，请重新上传！', 'tree=edm.edmuser.to_new');          
        }
        
        $edm_to_email_count = sizeof($edm_to_email); 
        
        // insert into edm_to
        $sql = "INSERT INTO edm_to(user_id, edm_to_group, edm_to_count) VALUES('{$this->user->user_id}', '{$edm_to->edm_to_group}', '{$edm_to_email_count}')";
        mysql_query($sql, $this->system->mysql->conn);
        $edm_to->edm_to_id = mysql_insert_id($this->system->mysql->conn);
        
        // insert into edm_to_list
        $sql_values = '';
        foreach($edm_to_email as $v) {
            $sql_values .= "('{$edm_to->edm_to_id}', '{$v}', CRC32('{$v}')),";
        }
        $sql_values = substr($sql_values, 0, -1);
        $sql = "INSERT INTO edm_to_list(edm_to_id, edm_to_value, edm_to_value_hash) VALUES{$sql_values}";
        mysql_query($sql, $this->system->mysql->conn);
        
        // delete temp file
        $edm_to_file->delete();
        
        $info_action = new info_action($this->system);
        $info_action->send('已完成添加邮箱列表的操作！', 'tree=edm.edmuser.to');   
    
    }
    
    function to_del() {
        
        $edm_to = new edm_to();
        $edm_to->edm_to_id = intval($_GET['edm_to_id']);
        
        if($edm_to->edm_to_id < 1) {
            $info_action = new info_action($this->system);
            $info_action->send('邮箱列表标识不能是空值。', 'tree=edm.edmuser.to');
        }
        
        // check user_id edm_to_id relationship
        $sql = "SELECT count(edm_to_id) AS count FROM edm_to WHERE user_id='{$this->user->user_id}' AND edm_to_id='{$edm_to->edm_to_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        if($row['count'] == 0) {
            $this->system->set_403();            
        }
        
        $sql = "UPDATE edm_to SET edm_to_is_delete='1' WHERE edm_to_id={$edm_to->edm_to_id}";
        mysql_query($sql, $this->system->mysql->conn);
        
        $info_action = new info_action($this->system);
        $info_action->send('已完成邮箱列表的删除操作。', 'tree=edm.edmuser.to');
    
    }
    
    function to_mod() {
        
        $edm_to = new edm_to();
        $edm_to->edm_to_id = intval($_GET['edm_to_id']);
        
        if($edm_to->edm_to_id < 1) {
            $info_action = new info_action($this->system);
            $info_action->send('邮箱列表标识不能是空值。', 'tree=edm.edmuser.to');
        }
        
        // check user_id edm_to_id relationship
        $sql = "SELECT count(edm_to_id) AS count FROM edm_to WHERE user_id='{$this->user->user_id}' AND edm_to_id='{$edm_to->edm_to_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        if($row['count'] == 0) {
            $this->system->set_403();            
        }
        
        if($_SERVER['REQUEST_METHOD'] == 'POST') {
            
            $edm_to->edm_to_group = str_replace(' ', '-', trim(strip_tags($_POST['edm_to_group'])));
            
            $error = 0;
            $error_message = '';
            $valid = new valid();
            
            if(!$valid->is_valid_length($edm_to->edm_to_group, 1, 200)) {
                $error = 1;
                $error_message .= "邮箱列表名称不能大于 200 个字符且不能是空值。请重新填写！<br>";               
            }
            
            if($error) {
                $info_action = new info_action($this->system);
                $info_action->send($error_message, 'tree=edm.edmuser.to_mod&edm_to_id=' . $edm_to->edm_to_id);
            }
            
           
            // update edm_to edm_to_group
            $sql = "UPDATE edm_to SET edm_to_group='{$edm_to->edm_to_group}' WHERE user_id='{$this->user->user_id}' AND edm_to_id='{$edm_to->edm_to_id}'";
            mysql_query($sql, $this->system->mysql->conn);
            
            $info_action = new info_action($this->system);
            $info_action->send('已完成邮件列表名称的更新操作。', 'tree=edm.edmuser.to');
            
        } else {
            
            $sql = "SELECT edm_to_group FROM edm_to WHERE edm_to_id='{$edm_to->edm_to_id}'";
            $result = mysql_query($sql, $this->system->mysql->conn);
            $row = mysql_fetch_array($result);
            
            $edm_to->edm_to_group = $row['edm_to_group'];
            
            $this->system->smarty->assign('edm_to', get_object_vars($edm_to));
            $this->system->smarty->display('edm.edmuser.to_mod.tpl');
        
        }
    
    }
  
    function to_export() {
        
        $edm_to = new edm_to();
        $edm_to->edm_to_id = intval($_GET['edm_to_id']);
        
        if($edm_to->edm_to_id < 1) {
            $info_action = new info_action($this->system);
            $info_action->send('邮箱列表标识不能是空值。', 'tree=edm.edmuser.to');
        }
        
        // check user_id edm_to_id relationship
        $sql = "SELECT count(edm_to_id) AS count FROM edm_to WHERE user_id='{$this->user->user_id}' AND edm_to_id='{$edm_to->edm_to_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        if($row['count'] == 0) {
            $this->system->set_403();            
        }
        
        // get group name
        $sql = "SELECT edm_to_group, edm_to_count FROM edm_to WHERE edm_to_id='{$edm_to->edm_to_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        $edm_to->edm_to_group = $row['edm_to_group'];
        $edm_to->edm_to_count = $row['edm_to_count'];
        
        // get email data
        $sql = "SELECT edm_to_value FROM edm_to_list WHERE edm_to_id={$edm_to->edm_to_id} AND edm_to_value_deleted=0";
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        $edm_to_value = array();
        while($row = mysql_fetch_array($result)) {
            $edm_to_value[] = $row['edm_to_value'];
        }
        
        // set download
        $edm_to_data = $this->edmmisc_action->export_email_to_text($edm_to_value);
        $edm_to_file_name = urlencode(str_replace(' ', '-', $edm_to->edm_to_group) . '-' . $edm_to->edm_to_count . '个.txt');
        
        $this->system->common->set_download($edm_to_file_name, $edm_to_data);
    
    }
    
    // content
    function content() {
        
        SmartyPaginate::connect('edm_edmuser_content');       
        SmartyPaginate::setUrlVar('start', 'edm_edmuser_content');
        SmartyPaginate::setURL('/?tree=edm.edmuser.content', 'edm_edmuser_content');
        SmartyPaginate::setLimit(10, 'edm_edmuser_content');
        SmartyPaginate::setPrevText('上一页', 'edm_edmuser_content');
        SmartyPaginate::setNextText('下一页', 'edm_edmuser_content');
        SmartyPaginate::setFirstText('首页', 'edm_edmuser_content');
        SmartyPaginate::setLastText('末页', 'edm_edmuser_content');
        SmartyPaginate::setPageLimit(10, 'edm_edmuser_content');
        
        // get counter
        $sql = "SELECT count(edm_content_id) AS c FROM edm_content WHERE user_id={$this->user->user_id} AND edm_content_is_delete=" . IS_NOT_DELETE;
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        SmartyPaginate::setTotal($row['c'], 'edm_edmuser_content');
        
        // get data grid       
        $sql = "SELECT edm_content_id, edm_content_subject, edm_content_time FROM edm_content WHERE user_id='{$this->user->user_id}' AND edm_content_is_delete=" . IS_NOT_DELETE . " ORDER BY edm_content_id DESC LIMIT %d,%d";
        $sql = sprintf($sql, SmartyPaginate::getCurrentIndex('edm_edmuser_content'), SmartyPaginate::getLimit('edm_edmuser_content')); 
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        $edm_content = array();
        while($row = mysql_fetch_array($result)) {
            $edm_content[] = array('edm_content_subject' => mb_substr($row['edm_content_subject'], 0, 35, 'UTF-8') . '...',
                                   'edm_content_time'    => date('Y-m-d', $row['edm_content_time']),
                                   'edm_content_id'      => $row['edm_content_id'],
                                   );
        }
        
        $this->system->smarty->assign('edm_content', $edm_content);
        SmartyPaginate::assign(&$this->system->smarty, 'paginate', 'edm_edmuser_content');
        $this->system->smarty->display('edm.edmuser.content.tpl');
    
    }
    
    function content_new() {
        $this->system->smarty->display('edm.edmuser.content_new.tpl');
    }
    
    function content_add() {
        
        $edm_content = new edm_content();
        $edm_content->edm_content_subject = trim(strip_tags($_POST['edm_content_subject']));
        $edm_content->edm_content_altbody = trim($_POST['edm_content_altbody']); 
        
        $error = 0;
        $error_message = '';
        $valid = new valid();
        
        if(!$valid->is_valid_length($edm_content->edm_content_subject, 1, 50)) {
            $error = 1;
            $error_message .= '邮件标题必须是 1 - 50 个字符。请重新填写！<br>';
        }
        if(!$valid->is_valid_length($edm_content->edm_content_altbody, 1, 200000)) {
            $error = 1;
            $error_message .= '邮件正文必须是 1 - 200000 个字符。请重新填写！<br>';
        }
        if($error) {
            $info_action = new info_action($this->system);
            $info_action->send($error_message, 'tree=edm.edmuser.content_new');
        }
        
        // check content counter
        $sql = "SELECT count(edm_content_id) AS count FROM edm_content WHERE user_id='{$this->user->user_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        if($row['count'] > 10000) {
            $info_action = new info_action($this->system);
            $info_action->send('您的邮件内容已经超过 10000 个，达到上限。请与上级经销商联系，获取新账户。', 'tree=edm.edmuser.content_new');            
        }
        
        // insert into edm_content
        $edm_content->edm_content_time = time();
        $edm_content->edm_content_altbody = stripslashes($edm_content->edm_content_altbody);
        $edm_content->edm_content_altbody = $this->edmmisc_action->remove_html_element($edm_content->edm_content_altbody, 'script');
        $edm_content->edm_content_altbody = $this->edmmisc_action->remove_html_element($edm_content->edm_content_altbody, 'frameset');
        $edm_content->edm_content_altbody = $this->edmmisc_action->remove_html_element($edm_content->edm_content_altbody, 'frame');
        $edm_content->edm_content_altbody = $this->edmmisc_action->remove_html_element($edm_content->edm_content_altbody, 'iframe');
        $edm_content->edm_content_altbody = $this->system->common->tidy_clean($edm_content->edm_content_altbody);
     
        $sql = "INSERT INTO edm_content(user_id, edm_content_subject, edm_content_altbody, edm_content_time) VALUES('{$this->user->user_id}', '{$edm_content->edm_content_subject}', '" . addslashes($edm_content->edm_content_altbody) . "', '{$edm_content->edm_content_time}')";
        mysql_query($sql, $this->system->mysql->conn);
        
        $edm_content->edm_content_id = mysql_insert_id($this->system->mysql->conn);
        
        // insert into edm_content_url
        // delete
        $sql = "DELETE FROM edm_content_url WHERE edm_content_id={$edm_content->edm_content_id}";
        mysql_query($sql, $this->system->mysql->conn);
        
        // insert
        $edm_content_urls = $this->edmmisc_action->get_content_url($edm_content->edm_content_altbody);
        $sql = "INSERT INTO edm_content_url(edm_content_id, edm_content_url, edm_content_url_hash) VALUES";
        foreach($edm_content_urls as $edm_content_url) {
            $sql .= "('{$edm_content->edm_content_id}', '" . addslashes($edm_content_url['url']) . "', '{$edm_content_url['hash']}'),";
        }
        $sql = substr($sql, 0, -1);
        mysql_query($sql, $this->system->mysql->conn);
        
        $info_action = new info_action($this->system);
        $info_action->send('已经完成新建邮件内容的操作！', 'tree=edm.edmuser.content');
 
    }
    
    function content_del() {
        
        $edm_content = new edm_content();
        $edm_content->edm_content_id = intval($_GET['edm_content_id']);
        
        if($edm_content->edm_content_id < 1) {
            $info_action = new info_action($this->system);
            $info_action->send('邮件内容标识不能是空值！', 'tree=edm.edmuser.content');
        }
        
        // check relationship
        $sql = "SELECT count(edm_content_id) AS count FROM edm_content WHERE user_id='{$this->user->user_id}' AND edm_content_id='{$edm_content->edm_content_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        if($row['count'] == 0) {
            $this->system->set_403();
        }
               
        // delete
        $sql = "UPDATE edm_content SET edm_content_is_delete=" . IS_DELETE . " WHERE edm_content_id={$edm_content->edm_content_id} AND user_id={$this->user->user_id}";
        mysql_query($sql, $this->system->mysql->conn);
        
        $info_action = new info_action($this->system);
        $info_action->send('已经完成邮件内容的删除操作！', 'tree=edm.edmuser.content');
    
    }
    
    function content_mod() {
        
        $edm_content = new edm_content();
        $edm_content->edm_content_id = intval($_GET['edm_content_id']);
        
        if($edm_content->edm_content_id < 1) {
            $info_action = new info_action($this->system);
            $info_action->send('邮件内容标识不能是空值！', 'tree=edm.edmuser.content');
        }
        // check relationship
        $sql = "SELECT count(edm_content_id) AS count FROM edm_content WHERE user_id='{$this->user->user_id}' AND edm_content_id='{$edm_content->edm_content_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        if($row['count'] == 0) {
            $this->system->set_403();
        }
        
        if($_SERVER['REQUEST_METHOD'] == 'POST') {
            
            $edm_content->edm_content_subject = trim(strip_tags($_POST['edm_content_subject']));
            $edm_content->edm_content_altbody = trim($_POST['edm_content_altbody']);
            
            $error = 0;
            $error_message = '';
            $valid = new valid();
            
            if(!$valid->is_valid_length($edm_content->edm_content_subject, 1, 50)) {
                $error = 1;
                $error_message .= '邮件标题必须是 1 - 50 个字符。请重新填写！<br>';
            }
            if(!$valid->is_valid_length($edm_content->edm_content_altbody, 1, 200000)) {
                $error = 1;
                $error_message .= '邮件正文必须是 1 - 200000 个字符。请重新填写！<br>';
            }
            if($error) {
                $info_action = new info_action($this->system);
                $info_action->send($error_message, 'tree=edm.edmuser.content');
            }
            
            // update database
            
            $edm_content->edm_content_altbody = stripslashes($edm_content->edm_content_altbody);
            $edm_content->edm_content_altbody = $this->edmmisc_action->remove_html_element($edm_content->edm_content_altbody, 'script');
            $edm_content->edm_content_altbody = $this->edmmisc_action->remove_html_element($edm_content->edm_content_altbody, 'frameset');
            $edm_content->edm_content_altbody = $this->edmmisc_action->remove_html_element($edm_content->edm_content_altbody, 'frame');
            $edm_content->edm_content_altbody = $this->edmmisc_action->remove_html_element($edm_content->edm_content_altbody, 'iframe');
            $edm_content->edm_content_altbody = $this->system->common->tidy_clean($edm_content->edm_content_altbody);
            
            $sql = "UPDATE edm_content SET edm_content_subject='{$edm_content->edm_content_subject}', edm_content_altbody='" . addslashes($edm_content->edm_content_altbody) . "' WHERE user_id='{$this->user->user_id}' AND edm_content_id='{$edm_content->edm_content_id}'"; 
            mysql_query($sql, $this->system->mysql->conn);
            
            // insert into edm_content_url
            // delete
            $sql = "DELETE FROM edm_content_url WHERE edm_content_id={$edm_content->edm_content_id}";
            mysql_query($sql, $this->system->mysql->conn);
            
            // insert
            $edm_content_urls = $this->edmmisc_action->get_content_url($edm_content->edm_content_altbody);
            $sql = "INSERT INTO edm_content_url(edm_content_id, edm_content_url, edm_content_url_hash) VALUES";
            foreach($edm_content_urls as $edm_content_url) {
                $sql .= "('{$edm_content->edm_content_id}', '" . addslashes($edm_content_url['url']) . "', '{$edm_content_url['hash']}'),";
            }
            $sql = substr($sql, 0, -1);
            mysql_query($sql, $this->system->mysql->conn);
            
            $info_action = new info_action($this->system);
            $info_action->send('已完成更新邮件内容的操作！', 'tree=edm.edmuser.content');
                            
        } else {
            
            $sql = "SELECT edm_content_id, edm_content_subject, edm_content_altbody FROM edm_content WHERE user_id='{$this->user->user_id}' AND edm_content_id='{$edm_content->edm_content_id}'";
            $result = mysql_query($sql, $this->system->mysql->conn);
            $row = mysql_fetch_array($result);
            
            $edm_content_array['edm_content_id'] = $row['edm_content_id'];
            $edm_content_array['edm_content_subject'] = htmlspecialchars($row['edm_content_subject'], ENT_QUOTES);
            $edm_content_array['edm_content_altbody'] = $row['edm_content_altbody'];
            
            $this->system->smarty->assign('edm_content', $edm_content_array);
            $this->system->smarty->display('edm.edmuser.content_mod.tpl');
        
        }
        
    }
    
    // job
    
    function job() {
        
        SmartyPaginate::connect('edm_edmuser_job');       
        SmartyPaginate::setUrlVar('start', 'edm_edmuser_job');
        SmartyPaginate::setURL('/?tree=edm.edmuser.job', 'edm_edmuser_job');
        SmartyPaginate::setLimit(10, 'edm_edmuser_job');
        SmartyPaginate::setPrevText('上一页', 'edm_edmuser_job');
        SmartyPaginate::setNextText('下一页', 'edm_edmuser_job');
        SmartyPaginate::setFirstText('首页', 'edm_edmuser_job');
        SmartyPaginate::setLastText('末页', 'edm_edmuser_job');
        SmartyPaginate::setPageLimit(10, 'edm_edmuser_job');
        
         // get counter
        $sql = "SELECT count(edm_job_id) AS c FROM edm_job WHERE user_id={$this->user->user_id}";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        SmartyPaginate::setTotal($row['c'], 'edm_edmuser_job');
        
        // get data grid
        $sql = "SELECT edm_job_id, edm_job_name, edm_job_status, edm_job_start_time, edm_job_end_time, edm_job_count_plan FROM edm_job WHERE user_id='{$this->user->user_id}' ORDER BY edm_job_id DESC, edm_job_status ASC LIMIT %d, %d";
        $sql = sprintf($sql, SmartyPaginate::getCurrentIndex('edm_edmuser_job'), SmartyPaginate::getLimit('edm_edmuser_job')); 
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        $edm_job = array();
        while($row = mysql_fetch_array($result)) {
            $edm_job[] = $row;
        }
        
        $this->system->smarty->assign('edm_job', $edm_job);
        SmartyPaginate::assign(&$this->system->smarty, 'paginate', 'edm_edmuser_job');
        $this->system->smarty->display('edm.edmuser.job.tpl');
    
    }
    
    function job_add() {
               
        if($_SERVER['REQUEST_METHOD'] == 'POST') {
            
            $edm_job = new edm_job();
            $edm_job->edm_job_name = trim(strip_tags($_POST['edm_job_name']));
            $edm_job->edm_to_id = intval($_POST['edm_to_id']);
            $edm_job->edm_content_id = intval($_POST['edm_content_id']);
            $edm_job->edm_job_count_plan = intval($_POST['edm_job_count_plan']);
            $edm_job->edm_job_reply_to = trim(strip_tags($_POST['edm_job_reply_to']));
            $edm_job->edm_job_from = trim(strip_tags($_POST['edm_job_from']));
            $edm_job->edm_job_from_name = trim(strip_tags($_POST['edm_job_from_name']));
            $edm_job->edm_job_get_click = intval($_POST['edm_job_get_click']);
            
            // check
            $error = 0;
            $error_message = '';
            $valid = new valid();
            
            // check job name
            if(!$valid->is_valid_length($edm_job->edm_job_name, 1, 90)) {
                $error = 1;
                $error_message .= '任务名称必须小于 30 个字符，并且不能是空值！<br>';
            }
            
            // check from name
            if(!$valid->is_valid_length($edm_job->edm_job_from_name, 1, 90)) {
                $error = 1;
                $error_message .= '发送人名称必须小于 30 个字符，并且不能是空值！<br>';
            }
            
             // check from email
            if(!$valid->is_email($edm_job->edm_job_from)) {
                $error = 1;
                $error_message .= '发送邮址不是电子邮件格式！<br>';
            }
            
            // check reply_to email
            if(!$valid->is_email($edm_job->edm_job_reply_to)) {
                $error = 1;
                $error_message .= '回复邮址不是电子邮件格式！<br>';
            }
            
            // check edm_job_get_click
            if($edm_job->edm_job_get_click != 0 && $edm_job->edm_job_get_click != 1) {
                $error = 1;
                $error_message .= '没有选择是否使用点击率统计！<br>';
            }          
            
            // check edm_to_id user_id relationship
            $sql = "SELECT count(edm_to_id) as count FROM edm_to WHERE edm_to_id='{$edm_job->edm_to_id}' AND user_id='{$this->user->user_id}'";      
            $result = mysql_query($sql, $this->system->mysql->conn);
            $row = mysql_fetch_array($result);
            
            if($row['count'] < 1) {
                $error = 1;
                $error_message .= '您选择的邮箱列表和您的用户不匹配，请重新选择。<br>';
            }
            
            // check edm_content_id user_id relationship
            $sql = "SELECT count(edm_content_id) AS count FROM edm_content WHERE edm_content_id='{$edm_job->edm_content_id}' AND user_id='{$this->user->user_id}'";
            $result = mysql_query($sql, $this->system->mysql->conn);
            $row = mysql_fetch_array($result);
            
            if($row['count'] < 1) {
                $error = 1;
                $error_message .= '您选择的邮件正文内容列表和您的用户不匹配，请重新选择。<br>';
            }
            
            // check edm_job_count_plan
            if($edm_job->edm_job_count_plan < 10 || $edm_job->edm_job_count_plan > 50000) {
                $error = 1;
                $error_message .= '您选择的计划发送条数错误，请重新选择。<br>';
            }
            if($error) {
                $info_action = new info_action($this->system);
                $info_action->send($error_message, 'tree=edm.edmuser.job_add');            
            }
            
            // count check EDM
            $error = 0;
            $error_message = '';
            
            // 检查现有运行任务的个数，限制为 10 个。
            $sql = "SELECT COUNT(edm_job_id) AS c FROM edm_job WHERE user_id='{$this->user->user_id}' AND edm_job_status='" . EDM_JOB_STATUS_JOB_RUNNING . "'";
            $result = mysql_query($sql, $this->system->mysql->conn);
            $row = mysql_fetch_array($result);
            if($row['c'] >= 200) {
                $error = 1;
                $error_message .= '同一时间只允许运行 200 个任务。请等待这些任务中的一个或多个完成后，再提交新任务。<br>';                
            }
            if($error) {
                $info_action = new info_action($this->system);
                $info_action->send($error_message, 'tree=edm.edmuser.job_add');            
            }            
            
            // check EDM
            $sql = "SELECT pp.product_available_count AS product_available_count FROM product_price pp INNER JOIN product p ON pp.product_id=p.product_id WHERE pp.user_id='{$this->user->user_id}' AND p.product_slug='EDM'";
            $result = mysql_query($sql, $this->system->mysql->conn);
            $row = mysql_fetch_array($result);
            
            if($row['product_available_count'] < 10) {
                $error = 1;
                $error_message .= '您的“电子邮件营销”库存不足，少于 10 封，请从上级经销商处购买。<br>';
            }

            if($error) {
                $info_action = new info_action($this->system);
                $info_action->send($error_message, 'tree=edm.edmuser.job_add');            
            }
                        
            // insert
            // update job status
            $edm_job->edm_job_status = EDM_JOB_STATUS_WAIT_FOR_JOB_CREATE;
            $sql = "INSERT INTO edm_job(edm_job_name, edm_job_status, edm_job_count_plan, user_id, edm_to_id, edm_content_id, edm_job_reply_to, edm_job_from, edm_job_from_name, edm_job_get_click) VALUES('{$edm_job->edm_job_name}', '{$edm_job->edm_job_status}', '{$edm_job->edm_job_count_plan}', '{$this->user->user_id}', '{$edm_job->edm_to_id}', '{$edm_job->edm_content_id}', '{$edm_job->edm_job_reply_to}', '{$edm_job->edm_job_from}', '{$edm_job->edm_job_from_name}', '{$edm_job->edm_job_get_click}')";
            //print($sql);
            mysql_query($sql, $this->system->mysql->conn);
            
            $info_action = new info_action($this->system);
            $info_action->send('已经完成了新建发送任务的操作。', 'tree=edm.edmuser.job');  
            
        } else {
                       
            // get product available
            $sql = "SELECT pp.product_available_count AS product_available_count FROM product_price pp INNER JOIN product p ON p.product_id=pp.product_id WHERE p.product_slug='EDM' AND pp.user_id='{$this->user->user_id}'";
            //print $sql;
            $result = mysql_query($sql, $this->system->mysql->conn);
            $row = mysql_fetch_array($result);
            $prodcut_price = $row;
            
            $this->system->smarty->assign('prodcut_price', $prodcut_price);
            
            // get content list
            $sql = "SELECT edm_content_id, edm_content_subject FROM edm_content WHERE user_id='{$this->user->user_id}' AND edm_content_is_delete=0 ORDER BY edm_content_id DESC";
            $result = mysql_query($sql, $this->system->mysql->conn);
            
            $edm_content = array();
            while($row = mysql_fetch_array($result)) {
                $edm_content[] = $row;
            }
            
            $this->system->smarty->assign('edm_content', $edm_content);
            
            // get  edm_to list
            $sql = "SELECT edm_to_id, edm_to_group, edm_to_count FROM edm_to WHERE user_id='{$this->user->user_id}' AND edm_to_is_delete=0 ORDER BY edm_to_id DESC";
            $result = mysql_query($sql, $this->system->mysql->conn);
            
            $edm_to = array();
            while($row = mysql_fetch_array($result)) {
                $edm_to[] = $row;
            }    
            
            $this->system->smarty->assign('edm_to', $edm_to);
            
            // display
            $this->system->smarty->display('edm.edmuser.job_add.tpl');  
                  
        }
   
    }
    function job_detail() {
        
        $edm_job = new edm_job();
        $edm_job->edm_job_id = intval($_GET['edm_job_id']);
        
        if($edm_job->edm_job_id < 1) {
            $info_action = new info_action($this->system);
            $info_action->send('任务序号不能是空值！', 'tree=edm.edmuser.job');
        }
        
        // check edm_job_id user_id
        $sql = "SELECT count(edm_job_id) AS count FROM edm_job WHERE user_id='{$this->user->user_id}' AND edm_job_id='{$edm_job->edm_job_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        if($row['count'] < 1) {
            $info_action = new info_action($this->system);
            $info_action->send('任务序号和用户不匹配！', 'tree=edm.edmuser.job');
        }
        
        // get info
        $sql = "
SELECT
  `content`.`edm_content_subject`, `content`.`edm_content_altbody`,
  `to`.`edm_to_group`, `to`.`edm_to_count`, `job`.`edm_job_name`,
  `job`.`edm_job_status`, `job`.`edm_job_message`, `job`.`edm_job_start_time`,
  `job`.`edm_job_end_time`, `job`.`edm_job_count_plan`, `job`.`edm_job_reply_to`,
  `job`.`edm_job_from`, `job`.`edm_job_from_name`, `job`.`edm_job_get_click`
FROM
  `edm_job` `job` LEFT JOIN
  `edm_to` `to` ON `to`.`edm_to_id` = `job`.`edm_to_id` LEFT JOIN
  `edm_content` `content` ON `content`.`edm_content_id` = `job`.`edm_content_id`
WHERE
  `job`.`edm_job_id`='{$edm_job->edm_job_id}' AND `job`.`user_id`='{$this->user->user_id}'
        ";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        $this->system->smarty->assign('edm_job', $row);
        $this->system->smarty->display('edm.edmuser.job_detail.tpl');
       
    }
    
    function job_soft_resent() {
        
        $edm_job = new edm_job();
        $edm_job->edm_job_id = intval($_GET['edm_job_id']);
        
        if($edm_job->edm_job_id < 1) {
            $info_action = new info_action($this->system);
            $info_action->send('任务序号不能是空值！', 'tree=edm.edmuser.job');
        }
        
        // check edm_job_id user_id
        $sql = "SELECT count(edm_job_id) AS count FROM edm_job WHERE user_id='{$this->user->user_id}' AND edm_job_id='{$edm_job->edm_job_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        if($row['count'] < 1) {
            $info_action = new info_action($this->system);
            $info_action->send('任务序号和用户不匹配！', 'tree=edm.edmuser.job');
        }
        
        // reset job status and result
        // job table
        $this->edmmisc_action->mysql_jobs_init();
        $sql = "UPDATE edm_job_{$edm_job->edm_job_id} SET job_status='" . EDM_SINGLE_JOB_STATUS_UNSENT . "', job_time='0', job_result='0', job_open='0', job_click='0' WHERE job_result='" . EDM_SINGLE_JOB_RESULT_BOUNCE_FROM . "' OR job_result='" . EDM_SINGLE_JOB_RESULT_BOUNCE_TO_SOFT . "' OR job_result='" . EDM_SINGLE_JOB_RESULT_BOUNCE_DATA . "'";
        mysql_query($sql, $this->edmmisc_action->mysql_jobs->conn);
        
        // info table
        $sql = "UPDATE edm_job SET edm_job_status='" . EDM_JOB_STATUS_JOB_RUNNING . "', edm_job_end_time='0', edm_job_count_bounce_from='0', edm_job_count_bounce_to_soft='0', edm_job_count_bounce_data='0' WHERE edm_job_id='{$edm_job->edm_job_id}'";
        mysql_query($sql, $this->system->mysql->conn);
        
        $info_action = new info_action($this->system);
        $info_action->send('操作成功！', 'tree=edm.edmuser.job');
    
    }
    
    function job_all_resent() {
        
        $edm_job = new edm_job();
        $edm_job->edm_job_id = intval($_GET['edm_job_id']);
        
        if($edm_job->edm_job_id < 1) {
            $info_action = new info_action($this->system);
            $info_action->send('任务序号不能是空值！', 'tree=edm.edmuser.job');
        }
        
        // check edm_job_id user_id
        $sql = "SELECT count(edm_job_id) AS count FROM edm_job WHERE user_id='{$this->user->user_id}' AND edm_job_id='{$edm_job->edm_job_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        if($row['count'] < 1) {
            $info_action = new info_action($this->system);
            $info_action->send('任务序号和用户不匹配！', 'tree=edm.edmuser.job');
        }
        
        // reset job status and result
        // job table
        $this->edmmisc_action->mysql_jobs_init();
        $sql = "UPDATE edm_job_{$edm_job->edm_job_id} SET job_status='" . EDM_SINGLE_JOB_STATUS_UNSENT . "', job_time='0', job_result='0', job_open='0', job_click='0'";
        mysql_query($sql, $this->edmmisc_action->mysql_jobs->conn);
        
        // info table
        $sql = "UPDATE edm_job SET edm_job_status='" . EDM_JOB_STATUS_JOB_RUNNING . "', edm_job_end_time='0', edm_job_count_success='0', edm_job_count_bounce_from='0', edm_job_count_bounce_to_soft='0', edm_job_count_bounce_to_hard='0', edm_job_count_bounce_data='0', edm_job_count_bounce_connect='0', edm_job_count_bounce_other='0', edm_job_count_open='0', edm_job_count_click='0' WHERE edm_job_id='{$edm_job->edm_job_id}'";
        mysql_query($sql, $this->system->mysql->conn);
        
        $info_action = new info_action($this->system);
        $info_action->send('操作成功！', 'tree=edm.edmuser.job');
    
    }
    
    function job_pause() {
        
        $edm_job = new edm_job();
        $edm_job->edm_job_id = intval($_GET['edm_job_id']);
        
        if($edm_job->edm_job_id < 1) {
            $info_action = new info_action($this->system);
            $info_action->send('任务序号不能是空值！', 'tree=edm.edmuser.job');
        }
        
        // check edm_job_id user_id
        $sql = "SELECT count(edm_job_id) AS count FROM edm_job WHERE user_id='{$this->user->user_id}' AND edm_job_id='{$edm_job->edm_job_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        if($row['count'] < 1) {
            $info_action = new info_action($this->system);
            $info_action->send('任务序号和用户不匹配！', 'tree=edm.edmuser.job');
        }
        
        // job pause
        $sql = "SELECT edm_job_status FROM edm_job WHERE edm_job_id='{$edm_job->edm_job_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        if(mysql_num_rows($result) == 1) {
            
            $edm_job->edm_job_status = $row['edm_job_status'];
            unset($result);
            unset($row);
            
            if($edm_job->edm_job_status == EDM_JOB_STATUS_JOB_RUNNING) {
                $sql = "UPDATE edm_job SET edm_job_status='" . EDM_JOB_STATUS_JOB_PAUSE . "' WHERE edm_job_id='{$edm_job->edm_job_id}'";
                mysql_query($sql, $this->system->mysql->conn);
            } 
            if($edm_job->edm_job_status == EDM_JOB_STATUS_JOB_PAUSE) {
                $sql = "UPDATE edm_job SET edm_job_status='" . EDM_JOB_STATUS_JOB_RUNNING . "' WHERE edm_job_id='{$edm_job->edm_job_id}'";
                mysql_query($sql, $this->system->mysql->conn);
            } 
            
        }
        
        $info_action = new info_action($this->system);
        $info_action->send('操作成功！', 'tree=edm.edmuser.job');
            
    }
    
    function job_name_modify() {
        
        $edm_job = new edm_job();
        $edm_job->edm_job_id = intval($_GET['edm_job_id']);
        
        if($edm_job->edm_job_id < 1) {
            $info_action = new info_action($this->system);
            $info_action->send('任务序号不能是空值！', 'tree=edm.edmuser.job');
        }
        
        // check edm_job_id user_id
        $sql = "SELECT count(edm_job_id) AS count FROM edm_job WHERE user_id='{$this->user->user_id}' AND edm_job_id='{$edm_job->edm_job_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        if($row['count'] < 1) {
            $info_action = new info_action($this->system);
            $info_action->send('任务序号和用户不匹配！', 'tree=edm.edmuser.job');
        }
        
        if($_SERVER['REQUEST_METHOD'] == 'POST') {
            
            $edm_job->edm_job_name = trim(strip_tags($_POST['edm_job_name']));
            
            // check
            $valid = new valid();

            if(!$valid->is_valid_length($edm_job->edm_job_name, 1, 50)) {
                $info_action = new info_action($this->system);
                $info_action->send('任务名称必须小于 50 个字符，并且不能是空值！', 'tree=edm.edmuser.job_name_modify&edm_job_id=' . $edm_job->edm_job_id);
            }
            
            // update
            $sql = "UPDATE edm_job SET edm_job_name='{$edm_job->edm_job_name}' WHERE edm_job_id='{$edm_job->edm_job_id}' AND user_id='{$this->user->user_id}'";
            mysql_query($sql, $this->system->mysql->conn);
            
            $info_action = new info_action($this->system);
            $info_action->send('已完成更新任务名称的操作。', 'tree=edm.edmuser.job');

            
        } else {
            
            $sql = "SELECT edm_job_name FROM edm_job WHERE edm_job_id='{$edm_job->edm_job_id}' AND user_id='{$this->user->user_id}'";
            $result = mysql_query($sql, $this->system->mysql->conn);
            $row = mysql_fetch_array($result);
            
            $edm_job->edm_job_name = $row['edm_job_name'];
            
            $this->system->smarty->assign('edm_job', get_object_vars($edm_job));
            $this->system->smarty->display('edm.edmuser.job_name_modify.tpl');
        }
    
    }
    
    function analysis() {
        
        SmartyPaginate::connect('edm_edmuser_analysis');       
        SmartyPaginate::setUrlVar('start', 'edm_edmuser_analysis');
        SmartyPaginate::setURL('/?tree=edm.edmuser.analysis', 'edm_edmuser_analysis');
        SmartyPaginate::setLimit(10, 'edm_edmuser_analysis');
        SmartyPaginate::setPrevText('上一页', 'edm_edmuser_analysis');
        SmartyPaginate::setNextText('下一页', 'edm_edmuser_analysis');
        SmartyPaginate::setFirstText('首页', 'edm_edmuser_analysis');
        SmartyPaginate::setLastText('末页', 'edm_edmuser_analysis');
        SmartyPaginate::setPageLimit(10, 'edm_edmuser_analysis');
        
        // get counter
        $sql = "SELECT count(edm_job_id) AS c FROM edm_job WHERE user_id={$this->user->user_id} AND (edm_job_status='" . EDM_JOB_STATUS_JOB_RUNNING . "' OR edm_job_status='" . EDM_JOB_STATUS_JOB_FINISHED . "')";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        SmartyPaginate::setTotal($row['c'], 'edm_edmuser_analysis');
        
        // get data grid
        $sql = "SELECT edm_job_id, edm_job_name, edm_job_status, edm_job_count_real, edm_job_count_success, edm_job_count_bounce_from, edm_job_count_bounce_to_soft, edm_job_count_bounce_to_hard, edm_job_count_bounce_data, edm_job_count_bounce_connect, edm_job_count_bounce_other, edm_job_count_open, edm_job_count_click, edm_job_resent_counter, edm_job_get_click FROM edm_job WHERE user_id={$this->user->user_id} AND (edm_job_status='" . EDM_JOB_STATUS_JOB_RUNNING . "' OR edm_job_status='" . EDM_JOB_STATUS_JOB_FINISHED . "') ORDER BY edm_job_id DESC LIMIT %d, %d";
        $sql = sprintf($sql, SmartyPaginate::getCurrentIndex('edm_edmuser_analysis'), SmartyPaginate::getLimit('edm_edmuser_analysis'));
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        $edm_job_array = array();
        while($row = mysql_fetch_array($result)) {
            $edm_job_array[] = array('edm_job_id'                        => $row['edm_job_id'],
                                     'edm_job_name'                      => $row['edm_job_name'],
                                     'edm_job_status'                    => $row['edm_job_status'],
                                     'edm_job_count_plan'                => $row['edm_job_count_real'],
                                     'edm_job_count_real'                => $row['edm_job_count_success'] + $row['edm_job_count_bounce_from'] + $row['edm_job_count_bounce_to_soft'] + $row['edm_job_count_bounce_to_hard'] + $row['edm_job_count_bounce_data'] + $row['edm_job_count_bounce_connect'] + $row['edm_job_count_bounce_other'],
                                     'edm_job_count_success'             => $row['edm_job_count_success'],
                                     'edm_job_count_success_pc'          => round($row['edm_job_count_success'] / $row['edm_job_count_real'] * 100, 2),
                                     'edm_job_count_bounce_from'         => $row['edm_job_count_bounce_from'],
                                     'edm_job_count_bounce_from_pc'      => round($row['edm_job_count_bounce_from'] / $row['edm_job_count_real'] * 100, 2),
                                     'edm_job_count_bounce_to_soft'      => $row['edm_job_count_bounce_to_soft'] + $row['edm_job_count_bounce_data'],
                                     'edm_job_count_bounce_to_soft_pc'   => round(($row['edm_job_count_bounce_to_soft'] + $row['edm_job_count_bounce_data']) / $row['edm_job_count_real'] * 100, 2),
                                     'edm_job_count_bounce_to_hard'      => $row['edm_job_count_bounce_to_hard'],
                                     'edm_job_count_bounce_to_hard_pc'   => round($row['edm_job_count_bounce_to_hard'] / $row['edm_job_count_real'] * 100, 2),
                                     //'edm_job_count_bounce_data'         => $row['edm_job_count_bounce_data'],
                                     //'edm_job_count_bounce_data_pc'      => round($row['edm_job_count_bounce_data'] / $row['edm_job_count_real'] * 100, 2),
                                     'edm_job_count_bounce_connect'      => $row['edm_job_count_bounce_connect'],
                                     'edm_job_count_bounce_connect_pc'   => round($row['edm_job_count_bounce_connect'] / $row['edm_job_count_real'] * 100, 2),
                                     'edm_job_count_bounce_other'        => $row['edm_job_count_bounce_other'],
                                     'edm_job_count_bounce_other_pc'     => round($row['edm_job_count_bounce_other'] / $row['edm_job_count_real'] * 100, 2),
                                     'edm_job_count_open'                => $row['edm_job_count_open'],
                                     'edm_job_count_open_pc'             => round($row['edm_job_count_open'] / $row['edm_job_count_real'] * 100, 2),
                                     'edm_job_count_click'               => $row['edm_job_count_click'],
                                     'edm_job_count_click_pc'            => round($row['edm_job_count_click'] / $row['edm_job_count_real'] * 100, 2),
                                     'edm_job_resent_counter'            => $row['edm_job_resent_counter'],
                                     'edm_job_get_click'                 => $row['edm_job_get_click']
                                     );
        }
        
        $this->system->smarty->assign('edm_job', $edm_job_array);
        SmartyPaginate::assign(&$this->system->smarty, 'paginate', 'edm_edmuser_analysis');
        $this->system->smarty->display('edm.edmuser.analysis.tpl');
    
    }
    
    function analysis_export() {
        
        $edm_job = new edm_job();
        $edm_job->edm_job_id = intval($_GET['edm_job_id']);
        
        if($edm_job->edm_job_id < 1) {
            $info_action = new info_action($this->system);
            $info_action->send('任务序号不能是空值！', 'tree=edm.edmuser.analysis');
        }
        
        // check edm_job_id user_id
        $sql = "SELECT count(edm_job_id) AS count FROM edm_job WHERE user_id='{$this->user->user_id}' AND edm_job_id='{$edm_job->edm_job_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        if($row['count'] < 1) {
            $info_action = new info_action($this->system);
            $info_action->send('任务序号和用户不匹配！', 'tree=edm.edmuser.analysis');
        }
        
        // check system or user edm_to
        $sql = "SELECT edm_to_id, edm_job_name FROM edm_job WHERE edm_job_id='{$edm_job->edm_job_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        $edm_job->edm_to_id = $row['edm_job_id'];
        $edm_job->edm_job_name = $row['edm_job_name'];
        
        $sql = "SELECT count(edm_to_id) AS count FROM edm_to WHERE edm_to_id='{$edm_job->edm_to_id}' AND user_id='0'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        if($row['count'] != 0) {
            $info_action = new info_action($this->system);
            $info_action->send('使用系统提供的邮箱发送的邮件不能导出统计分析。', 'tree=edm.edmuser.analysis');
        } 
        
        // mysql_jobs init
        $this->edmmisc_action->mysql_jobs_init();
        // is not system user
        // get data from single job table
        $sql = "SELECT job_to, job_time, job_result, job_open, job_click FROM edm_job_{$edm_job->edm_job_id} WHERE job_status='1'";
        $result = mysql_query($sql, $this->edmmisc_action->mysql_jobs->conn);
        
        $jobs = "收信箱\t发送时间\t发送结果\t打开数\t点击数\r\n";
        while($row = mysql_fetch_array($result)) {
            
            // get result string
            $job_result_string = '';
            
            if($row['job_result'] ==       EDM_SINGLE_JOB_RESULT_SUCCESS) {
                $job_result_string =       EDM_SINGLE_JOB_RESULT_DETAIL_SUCCESS;    
            } elseif($row['job_result'] == EDM_SINGLE_JOB_RESULT_BOUNCE_FROM) {
                $job_result_string =       EDM_SINGLE_JOB_RESULT_DETAIL_BOUNCE_FROM;
            } elseif($row['job_result'] == EDM_SINGLE_JOB_RESULT_BOUNCE_TO_SOFT) {
                $job_result_string =       EDM_SINGLE_JOB_RESULT_DETAIL_BOUNCE_TO_SOFT;
            } elseif($row['job_result'] == EDM_SINGLE_JOB_RESULT_BOUNCE_TO_HARD) {
                $job_result_string =       EDM_SINGLE_JOB_RESULT_DETAIL_BOUNCE_TO_HARD;
            } elseif($row['job_result'] == EDM_SINGLE_JOB_RESULT_BOUNCE_DATA) {
                $job_result_string =       EDM_SINGLE_JOB_RESULT_DETAIL_BOUNCE_DATA;
            } elseif($row['job_result'] == EDM_SINGLE_JOB_RESULT_BOUNCE_CONNECT) {
                $job_result_string =       EDM_SINGLE_JOB_RESULT_DETAIL_BOUNCE_CONNECT;
            } else {
                $job_result_string =       EDM_SINGLE_JOB_RESULT_DETAIL_BOUNCE_OTHER;
            }
            /*
            if($row['job_result'] == EDM_SINGLE_JOB_RESULT_SUCCESS) {
                $job_result_string = '发送成功！';
            } else {
                $job_result_string = '发送失败！';
            }
            */
            $jobs .= $row['job_to'] . "\t" . date('Y.m.d H:i:s', $row['job_time']) . "\t" . $job_result_string . "\t" . $row['job_open'] . "\t" . $row['job_click'] . "\r\n";
            
        }
        
        $jobs = UTF16_LITTLE_ENDIAN_BOM . iconv('UTF-8', 'UTF-16LE', $jobs);
        $jobs_file_name = "任务[{$edm_job->edm_job_name}]的统计分析报告.csv";
        $jobs_file_name = urlencode($jobs_file_name);
        $this->system->common->set_download($jobs_file_name, $jobs);
           
    }
    
    // api
    
    function api() {
    
        $this->system->smarty->display('edm.edmuser.api.tpl');
        
    }
}
?>
