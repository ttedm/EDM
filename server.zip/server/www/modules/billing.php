<?php
class billing {

    var $billing_id;
    var $user_id;
    var $product_slug;
    var $billing_type;
    var $billing_cost;
    var $billing_subject;
    var $billing_operator;
    var $billing_time;
    
}
?>
