<?php
class edm_ip_group {

    var $edm_ip_group_id;
    var $edm_ip_group_ip;
    var $edm_ip_group_cname;
    var $edm_ip_group_provider;
    
}  
?>
