<?php
class info_action {
    
    var $info;
	var $system;
	    
    function info_action(&$system) {
	
		$this->system = $system;
        
        $action = $system->action;
        
        if($action == 'show') {
            $this->show();
        }
    }   

    function send($info_message, $info_return){
        
        $this->info = new info();
		
		$this->info->info_message = $info_message;
		$this->info->info_return  = $this->system->common->make_url($info_return);
        
        $_SESSION['info'] = serialize($this->info);
        
        if(!DEBUG) {
            $this->system->common->set_location($this->system->common->make_url("tree=system.info.show"));        
        } else {
            print("<pre>");
            print_r($this->info);
            print("</pre>");
            $url = $this->system->common->make_url("tree=system.info.show");
            print("<p><a href='{$url}'>Return</a></p>");
        }
       
        exit;
    
    }
    
    function show(){                                                                            
        
        if(empty($_SESSION['info'])) {
            $this->info = new info();
            $this->info->info_message = '系统错误，信息不存在！';
            $this->info->info_return  = $this->system->common->make_url('');           
        } else {
            $this->info = unserialize($_SESSION['info']);
        }

        if(!empty($_SESSION['user'])) {
            $user = unserialize($_SESSION['user']);
            $this->system->smarty->assign('check_login', get_object_vars($user));
        }
        
        $this->system->smarty->assign('info', get_object_vars($this->info));
        
        $_SESSION['info'] = NULL;
        
        $this->system->smarty->display('system.info.show.tpl');
        
        exit;
    
    }
}
   
?>
