<?php
//标识
class info {

    var $info_message;
    var $info_return;
    
}

?>
