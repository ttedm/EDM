<?php
// 标识
class edm_to {
    
    var $edm_to_id;
    var $user_id;
    var $edm_to_group;
    var $edm_to_count;
      
}
  
?>
