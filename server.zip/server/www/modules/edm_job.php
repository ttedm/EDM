<?php
//标识
class edm_job {

    var $edm_job_id;
    var $edm_job_name;
    var $edm_job_status;
    var $edm_job_message;
    var $edm_job_start_time;
    var $edm_job_end_time;
    var $edm_job_count_plan;
    var $edm_job_count_real;
    var $edm_job_count_success;
    var $edm_job_count_bounce_from;
    var $edm_job_count_bounce_to_soft;
    var $edm_job_count_bounce_to_hard;
    var $edm_job_count_bounce_data;
    var $edm_job_count_bounce_connect;
    var $edm_job_count_bounce_other;
    var $edm_job_count_open;
    var $edm_job_count_click;
    var $user_id;
    var $edm_to_id;
    var $edm_content_id;
    var $edm_job_reply_to;
    var $edm_job_from_name;
    var $edm_job_from;
    var $edm_job_resent_counter;
    var $edm_job_get_click;
       
}
?>
