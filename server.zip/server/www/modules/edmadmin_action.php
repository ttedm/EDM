<?php

class edmadmin_action {

    var $system;
    var $user;
    var $edmmisc_action;
    
    function edmadmin_action(&$system) {
        
        $this->system = $system;
        
        $this->system->check_login();
        
        $this->user = unserialize($_SESSION['user']);
        
        if($this->user->user_type != USER_ADMINISTRATOR || empty($this->user->user_type)) {
            $this->system->set_403();
        }
        
        $this->edmmisc_action = new edmmisc_action($this->system);
        
        $action = $this->system->action;
        
        // uhost
        if($action == 'uhost') {
            $this->uhost();
        }
        if($action == 'uhost_add') {
            $this->uhost_add();
        }
        if($action == 'uhost_delete') {
            $this->uhost_delete();
        }
        
        // ua
        if($action == 'ua') {
            $this->ua();
        }
        if($action == 'ua_add') {
            $this->ua_add();
        }
        if($action == 'ua_delete') {
            $this->ua_delete();
        }
        
        // uip
        if($action == 'uip') {
            $this->uip();
        }
        if($action == 'uip_add') {
            $this->uip_add();
        }
        if($action == 'uip_delete') {
            $this->uip_delete();
        }
        
        // ip group
        if($action == 'ip_group') {
            $this->ip_group();
        }
        if($action == 'ip_group_add') {
            $this->ip_group_add();
        }
        if($action == 'ip_group_modify') {
            $this->ip_group_modify();
        }
        if($action == 'ip_group_delete') {
            $this->ip_group_delete();
        }
        
        // ip
        if($action == 'ip') {
            $this->ip();
        }
        if($action == 'ip_add') {
            $this->ip_add();
        }
        if($action == 'ip_delete') {
            $this->ip_delete();
        }
        
        // from
        
        if($action == 'from') {
            $this->from();
        }
        if($action == 'from_add') {
            $this->from_add();
        }
        if($action == 'from_del') {
            $this->from_del();
        }
        
        // from list
        
        if($action == 'from_list') {
            $this->from_list();
        }
        if($action == 'from_list_add') {
            $this->from_list_add();
        }
        if($action == 'from_list_del') {
            $this->from_list_del();
        }
        
        // to
        if($action == 'to_user') {
            $this->to_user();
        }
        if($action == 'to') {
            $this->to();
        }
        if($action == 'to_add') {
            $this->to_add();
        }
        if($action == 'to_del') {
            $this->to_del();
        }
        if($action == 'to_export') {
            $this->to_export();
        }  
        
        // audit
        if($action == 'audit') {
            $this->audit();
        } 
        if($action == 'audit_this') {
            $this->audit_this();
        }
        
    }
    
    // ua
    function ua() {
        
        $sql = "SELECT edm_ua_id, edm_ua_value FROM edm_ua ORDER BY edm_ua_value ASC";
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        $edm_ua = array();
        
        while($row = mysql_fetch_array($result)) {
            $edm_ua[] = $row;
        }
        
        $this->system->smarty->assign('edm_ua', $edm_ua);
        $this->system->smarty->display('edm.edmadmin.ua.tpl');
        
    }
    
    function ua_add() {
        
        $edm_ua = new edm_ua();
        
        $edm_ua->edm_ua_value = htmlspecialchars(trim($_POST['edm_ua_value']));
        
        if($edm_ua->edm_ua_value == '') {
            $info_action = new info_action($this->system);
            $info_action->send('用户代理不能为空。', 'tree=edm.edmadmin.ua');
        }
        
        $sql = "INSERT INTO edm_ua(edm_ua_value) VALUES('{$edm_ua->edm_ua_value}')";
        mysql_query($sql, $this->system->mysql->conn);
        
        $info_action = new info_action($this->system);
        $info_action->send('用户代理添加成功！', 'tree=edm.edmadmin.ua');
        
    }
    
    function ua_delete() {
        
        $edm_ua = new edm_ua();
        
        $edm_ua->edm_ua_id = intval($_GET['edm_ua_id']);
        
        if($edm_ua->edm_ua_id < 1) {
            $info_action = new info_action($this->system);
            $info_action->send('用户代理标识不能为空。', 'tree=edm.edmadmin.ua');
        }
        
        $sql = "DELETE FROM edm_ua WHERE edm_ua_id='{$edm_ua->edm_ua_id}'";
        mysql_query($sql, $this->system->mysql->conn);
        
        $info_action = new info_action($this->system);
        $info_action->send('用户代理已经删除！', 'tree=edm.edmadmin.ua');        

    }
    
    // uhost
    function uhost() {
        
        $sql = "SELECT edm_uhost_id, edm_uhost_prefix, edm_uhost_type FROM edm_uhost ORDER BY edm_uhost_type ASC";
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        $edm_uhost = array();
        
        while($row = mysql_fetch_array($result)) {
            $edm_uhost[] = $row;        
        }
        
        $this->system->smarty->assign('edm_uhost', $edm_uhost);
        $this->system->smarty->display('edm.edmadmin.uhost.tpl');
        
    }
    
    function uhost_add() {
        
        $edm_uhost = new edm_uhost();
        $edm_uhost->edm_uhost_prefix = trim($_POST['edm_uhost_prefix']);
        $edm_uhost->edm_uhost_type = intval($_POST['edm_uhost_type']);
        
        $error = 0;
        $error_message = '';
        
        if($edm_uhost->edm_uhost_prefix == '') {
            $error = 1;
            $error_message .= '用户计算机名称前缀不能是空值！<br>';
        }
        if($error) {
            $info_action = new info_action($this->system);
            $info_action->send($error_message, 'tree=edm.edmadmin.uhost');
        }
        
        $sql = "INSERT INTO edm_uhost(edm_uhost_prefix, edm_uhost_type) VALUES('{$edm_uhost->edm_uhost_prefix}', '{$edm_uhost->edm_uhost_type}')";
        mysql_query($sql, $this->system->mysql->conn);
        
        $info_action = new info_action($this->system);
        $info_action->send('已经完成添加用户计算机名称！', 'tree=edm.edmadmin.uhost');        
    
    }
    
    function uhost_delete() {
        
        $edm_uhost = new edm_uhost();
        $edm_uhost->edm_uhost_id = intval($_GET['edm_uhost_id']);
        
        if($edm_uhost->edm_uhost_id < 1) {
            $info_action = new info_action($this->system);
            $info_action->send('用户计算机名称 id 不能是空值！', 'tree=edm.edmadmin.uhost');              
        }
        
        $sql = "DELETE FROM edm_uhost WHERE edm_uhost_id='{$edm_uhost->edm_uhost_id}'";
        mysql_query($sql, $this->system->mysql->conn);
        
        $info_action = new info_action($this->system);
        $info_action->send('已经完成用户计算机名称的删除操作！', 'tree=edm.edmadmin.uhost');        
    
    }
    
    // uip
    function uip() {
        
        $sql = "SELECT edm_uip_id, edm_uip_group, edm_uip_start, edm_uip_end FROM edm_uip ORDER BY edm_uip_group ASC";
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        $edm_uip = array();
        
        while($row = mysql_fetch_array($result)) {
            $edm_uip[] = $row;
        }
        
        $this->system->smarty->assign('edm_uip', $edm_uip);
        $this->system->smarty->display('edm.edmadmin.uip.tpl');
    
    }
    
    function uip_add() {
        
        $edm_uip = new edm_uip();
        $edm_uip->edm_uip_group = trim($_POST['edm_uip_group']);
        $edm_uip->edm_uip_start = trim($_POST['edm_uip_start']);
        $edm_uip->edm_uip_end   = trim($_POST['edm_uip_end']);
        
        $error = 0;
        $error_message = '';
        
        if($edm_uip->edm_uip_group == '') {
            $error = 1;
            $error_message .= '网络运营商不能是空！<br>';
        }    
        if($edm_uip->edm_uip_start == '') {
            $error = 1;
            $error_message .= '初始 IP 段不能为空！<br>';
        }
        if($edm_uip->edm_uip_end == '') {
            $error = 1;
            $error_message .= '结束 IP 段不能为空！<br>';
        }
        if($error) {
            $info_action = new info_action($this->system);
            $info_action->send($error_message, 'tree=edm.edmadmin.uip');
        }
        
        $sql = "INSERT INTO edm_uip(edm_uip_group, edm_uip_start, edm_uip_end) VALUES('{$edm_uip->edm_uip_group}', '{$edm_uip->edm_uip_start}', '{$edm_uip->edm_uip_end}')";
        mysql_query($sql, $this->system->mysql->conn);
        
        $info_action = new info_action($this->system);
        $info_action->send('用户 IP 已经完成添加！', 'tree=edm.edmadmin.uip');
        
    }
    
    function uip_delete() {
        
        $edm_uip = new edm_uip();
        $edm_uip->edm_uip_id = intval($_GET['edm_uip_id']);
        
        if($edm_uip->edm_uip_id < 1) {
            $info_action = new info_action($this->system);
            $info_action->send('用户 IP 标识不能为空！', 'tree=edm.edmadmin.uip');               
        }
        
        $sql = "DELETE FROM edm_uip WHERE edm_uip_id='{$edm_uip->edm_uip_id}'";
        mysql_query($sql, $this->system->mysql->conn);
        
        $info_action = new info_action($this->system);
        $info_action->send('已经完成用户 IP 的删除操作！', 'tree=edm.edmadmin.uip');
    
    }
    
    // ip group
    function ip_group() {
        
        $sql = "SELECT eig.edm_ip_group_id AS edm_ip_group_id, eig.edm_ip_group_ip AS edm_ip_group_ip, eig.edm_ip_group_cname AS edm_ip_group_cname, eig.edm_ip_group_provider AS edm_ip_group_provider, count(ei.edm_ip_id) AS edm_ip_group_counter FROM edm_ip_group eig LEFT JOIN edm_ip ei ON eig.edm_ip_group_id=ei.edm_ip_group_id GROUP BY eig.edm_ip_group_id ORDER BY eig.edm_ip_group_provider ASC";
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        $edm_ip_group = array();
        while($row = mysql_fetch_array($result)) {
            $edm_ip_group[] = $row;
        }
        
        //var_dump($edm_ip_group);
        
        $this->system->smarty->assign('edm_ip_group', $edm_ip_group);
        $this->system->smarty->display('edm.edmadmin.ip_group.tpl');
        
    }
    
    function ip_group_add() {
        
        $edm_ip_group = new edm_ip_group();
        $edm_ip_group->edm_ip_group_cname = trim($_POST['edm_ip_group_cname']);
        $edm_ip_group->edm_ip_group_ip    = trim($_POST['edm_ip_group_ip']);
        $edm_ip_group->edm_ip_group_provider = trim($_POST['edm_ip_group_provider']);
        
        $error = 0;
        $error_message = '';
        
        if($edm_ip_group->edm_ip_group_cname == '') {
            $error = 1;
            $error_message .= '母服务器别名不能是空！<br>';
        }    
        if($edm_ip_group->edm_ip_group_ip == '') {
            $error = 1;
            $error_message .= '母服务器 IP 不能为空！<br>';
        }
        if($edm_ip_group->edm_ip_group_provider == '') {
            $error = 1;
            $error_message .= '母服务器网络运营商不能为空！<br>';
        }
        if($error) {
            $info_action = new info_action($this->system);
            $info_action->send($error_message, 'tree=edm.edmadmin.ip_group');
        }
        
        $sql = "INSERT INTO edm_ip_group(edm_ip_group_cname, edm_ip_group_ip, edm_ip_group_provider) VALUES('{$edm_ip_group->edm_ip_group_cname}', '{$edm_ip_group->edm_ip_group_ip}', '{$edm_ip_group->edm_ip_group_provider}')";
        
        mysql_query($sql, $this->system->mysql->conn);
        
        $info_action = new info_action($this->system);
        $info_action->send('已经完成 IP 组的添加！', 'tree=edm.edmadmin.ip_group');        
   
    }
    
    function ip_group_delete() {
        
        $edm_ip_group = new edm_ip_group();
        $edm_ip_group->edm_ip_group_id = intval($_GET['edm_ip_group_id']);
        
        if($edm_ip_group->edm_ip_group_id < 1) {
            $info_action = new info_action($this->system);
            $info_action->send('发送 IP 组标识不能为空！', 'tree=edm.edmadmin.ip_group');              
        }
        
        $sql = "DELETE FROM edm_ip WHERE edm_ip_group_id='{$edm_ip_group->edm_ip_group_id}'";
        mysql_query($sql, $this->system->mysql->conn);
        
        $sql = "DELETE FROM edm_ip_group WHERE edm_ip_group_id='{$edm_ip_group->edm_ip_group_id}'";
        mysql_query($sql, $this->system->mysql->conn);
        
        $info_action = new info_action($this->system);
        $info_action->send('已完成发送 IP 组的删除操作！', 'tree=edm.edmadmin.ip_group');         
    
    }
    
    function ip_group_modify() {
        
        if($_SERVER['REQUEST_METHOD'] == 'POST') {
            
            $edm_ip_group = new edm_ip_group();
            
            $edm_ip_group->edm_ip_group_id = intval($_GET['edm_ip_group_id']);
            $edm_ip_group->edm_ip_group_cname = trim($_POST['edm_ip_group_cname']);
            $edm_ip_group->edm_ip_group_ip    = trim($_POST['edm_ip_group_ip']);
            $edm_ip_group->edm_ip_group_provider = trim($_POST['edm_ip_group_provider']);
            
            $error = 0;
            $error_message = '';
            
            if($edm_ip_group->edm_ip_group_id == 0) {
                $error = 1;
                $error_message .= '母服务器标识不能是空！<br>';                
            }
            if($edm_ip_group->edm_ip_group_cname == '') {
                $error = 1;
                $error_message .= '母服务器别名不能是空！<br>';
            }    
            if($edm_ip_group->edm_ip_group_ip == '') {
                $error = 1;
                $error_message .= '母服务器 IP 不能为空！<br>';
            }
            if($edm_ip_group->edm_ip_group_provider == '') {
                $error = 1;
                $error_message .= '母服务器网络运营商不能为空！<br>';
            }
            if($error) {
                
                $_SESSION['edm_ip_group'] = serialize($edm_ip_group);
                
                $info_action = new info_action($this->system);
                $info_action->send($error_message, "tree=edm.edmadmin.ip_group_modify&edm_ip_group_id={$edm_ip_group->edm_ip_group_id}");
                
            }
            
            $sql = "UPDATE edm_ip_group SET edm_ip_group_ip='{$edm_ip_group->edm_ip_group_ip}', edm_ip_group_cname='{$edm_ip_group->edm_ip_group_cname}', edm_ip_group_provider='{$edm_ip_group->edm_ip_group_provider}' WHERE edm_ip_group_id='{$edm_ip_group->edm_ip_group_id}'";
            mysql_query($sql, $this->system->mysql->conn);
            
            $_SESSION['edm_ip_group'] = NULL;
            
            $info_action = new info_action($this->system);
            $info_action->send('已经完成修改 IP 组的操作！', 'tree=edm.edmadmin.ip_group');            
            
        } else {
            
            $new_show = 0;
            
            if(!empty($_SESSION['edm_ip_group'])) {
                
                $edm_ip_group = unserialize($_SESSION['edm_ip_group']);
                $edm_ip_group_id = intval($_GET['edm_ip_group_id']);
                
                $edm_ip_group_modify = get_object_vars($edm_ip_group);
                
                if($edm_ip_group_id != $edm_ip_group->edm_ip_group_id) {
                    $_SESSION['edm_ip_group'] = NULL;
                    $new_show = 1;
                }
                
            } else {
                
                $new_show = 1;
            }
            
            if($new_show) {
                
                $edm_ip_group = new edm_ip_group();
                
                $edm_ip_group->edm_ip_group_id = intval($_GET['edm_ip_group_id']);
                
                $sql = "SELECT edm_ip_group_id, edm_ip_group_ip, edm_ip_group_cname, edm_ip_group_provider FROM edm_ip_group WHERE edm_ip_group_id='{$edm_ip_group->edm_ip_group_id}'";
                $result = mysql_query($sql, $this->system->mysql->conn);
                $row = mysql_fetch_array($result);
                
                $edm_ip_group_modify = $row;
                
            }
            
            $this->system->smarty->assign('edm_ip_group_modify', $edm_ip_group_modify);
            $this->system->smarty->display('edm.edmadmin.ip_group_modify.tpl');
       
        }       

    }
    
    // ip
    
    function ip() {
        
        $edm_ip = new edm_ip();
        
        $edm_ip->edm_ip_group_id = intval($_GET['edm_ip_group_id']);
               
        $error = 0;
        $error_message = '';
        
        if($edm_ip->edm_ip_group_id < 1) {
            $error = 1;
            $error_message .= '外发 IP 组标识不能是空！<br>';                
        }
        if($error) {
            $info_action = new info_action($this->system);
            $info_action->send($error_message, 'tree=edm.edmadmin.ip_group');        
        }
        
        // get edm_ip
        $sql = "SELECT edm_ip_id, edm_ip FROM edm_ip WHERE edm_ip_group_id='{$edm_ip->edm_ip_group_id}' ORDER BY edm_ip ASC";

        $result = mysql_query($sql, $this->system->mysql->conn);
        
        $edm_ip_show = array();
        
        while($row = mysql_fetch_array($result)) {
            $edm_ip_show[] = $row;
        }
        
        $this->system->smarty->assign('edm_ip', $edm_ip_show);
        
        // get edm_group_ip
        $sql = "SELECT edm_ip_group_id, edm_ip_group_cname FROM edm_ip_group WHERE edm_ip_group_id='{$edm_ip->edm_ip_group_id}'";

        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        $edm_ip_group = $row;
        
        $this->system->smarty->assign('edm_ip_group', $edm_ip_group);
        
        $this->system->smarty->display('edm.edmadmin.ip.tpl');        
    
    }
    
    function ip_add() {
        
        $edm_ip = new edm_ip();
        
        $edm_ip->edm_ip_group_id = intval($_GET['edm_ip_group_id']);
        $edm_ip->edm_ip = trim($_POST['edm_ip']);
        
        $error = 0;
        $error_message = '';
        
        if($edm_ip->edm_ip_group_id < 1) {
            $error = 1;
            $error_message .= '外发 IP 组标识不能是空！<br>';                
        }
        if($edm_ip->edm_ip == '') {
            $error = 1;
            $error_message .= 'IP 地址不能是空值!<br>';
        }
        if($error) {
            $info_action = new info_action($this->system);
            $info_action->send($error_message, "tree=edm.edmadmin.ip&edm_ip_group_id={$edm_ip->edm_ip_group_id}");        
        }
        
        $sql = "INSERT INTO edm_ip(edm_ip_group_id, edm_ip) VALUES('{$edm_ip->edm_ip_group_id}', '{$edm_ip->edm_ip}')";
        mysql_query($sql, $this->system->mysql->conn);
        
        $info_action = new info_action($this->system);
        $info_action->send('已完成添加 IP 的操作！', "tree=edm.edmadmin.ip&edm_ip_group_id={$edm_ip->edm_ip_group_id}");            
  
    
    }
    
    function ip_delete() {
        
        $edm_ip = new edm_ip();
        $edm_ip->edm_ip_id = intval($_GET['edm_ip_id']);
        $edm_ip->edm_ip_group_id = intval($_GET['edm_ip_group_id']);
        
        $error = 0;
        $error_message = '';
        if($edm_ip->edm_ip_id < 1) {
            $error = 1;
            $error_message = 'IP 标识不能是空值！';
        }
        if($edm_ip->edm_ip_group_id < 1) {
            $error = 1;
            $error_message = 'IP 组标识不能是空值！';
        }
        if($error) {
            $info_action = new info_action($this->system);
            $info_action->send($error_message, "tree=edm.edmadmin.ip&edm_ip_group_id={$edm_ip->edm_ip_group_id}"); 
        }
        
        $sql = "DELETE FROM edm_ip WHERE edm_ip_id='{$edm_ip->edm_ip_id}'";
        mysql_query($sql, $this->system->mysql->conn);
        
        $info_action = new info_action($this->system);
        $info_action->send('已经完成删除 IP 的操作！', "tree=edm.edmadmin.ip&edm_ip_group_id={$edm_ip->edm_ip_group_id}");
    
    }
    
    // from
    
    function from() {
        
        $sql = "SELECT edm_from_id, edm_from_domain, edm_from_password FROM edm_from ORDER BY edm_from_domain ASC";
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        $edm_from = array();
        while($row = mysql_fetch_array($result)) {
            $edm_from[] = $row;
        }
        
        $this->system->smarty->assign('edm_from', $edm_from);
        $this->system->smarty->display('edm.edmadmin.from.tpl');
        
    }
    
    function from_add() {
        
        $edm_from = new edm_from();
        $edm_from->edm_from_domain = trim($_POST['edm_from_domain']);
        $edm_from->edm_from_password = trim($_POST['edm_from_password']);
        
        $error = 0;
        $error_message = '';
        if($edm_from->edm_from_domain == '') {
            $error = 1;
            $error_message .= '发信箱域不能是空！<br>';
        }
        if(strlen($edm_from->edm_from_password) < 7 || strlen($edm_from->edm_from_password) > 20) {
            $error = 1;
            $error_message .= '发信箱密码不能小于 7 位且不能大于 20 位！<br>';
        }
        if($error) {
            $info_action = new info_action($this->system);
            $info_action->send($error_message, 'tree=edm.edmadmin.from');
        }
        
        // check from domain
        $sql = "SELECT edm_from_id FROM edm_from WHERE edm_from_domain='{$edm_from->edm_from_domain}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        if(mysql_num_rows($result) > 0) {
            $info_action = new info_action($this->system);
            $info_action->send('添加的发信域已经存在。', 'tree=edm.edmadmin.from');            
        }
        
        // insert from domain
        $sql = "INSERT INTO edm_from(edm_from_domain, edm_from_password) VALUES('{$edm_from->edm_from_domain}', '{$edm_from->edm_from_password}')";
        mysql_query($sql, $this->system->mysql->conn);
        
        // get imail connection
        $this->edmmisc_action->mysql_imail_init();
        
        // create imail table
        $from_domain_remix = str_replace('.', '_', $edm_from->edm_from_domain);
        $sql = "CREATE TABLE IF NOT EXISTS {$from_domain_remix} LIKE edm_from_entity";
        mysql_query($sql, $this->edmmisc_action->mysql_imail->conn);
        
        // insert root account
        $sql = "INSERT INTO {$from_domain_remix}(USERID, PASSWORD, FULLNAME, USERDIR, MAILADDR) VALUES('root', '{$edm_from->edm_from_password}', 'Administrator', 'D:\\\\IMail\\\\Data\\\\{$from_domain_remix}\\\\users\\\\root', 'root@{$edm_from->edm_from_domain}')";
        mysql_query($sql, $this->edmmisc_action->mysql_imail->conn);
        
        $info_action = new info_action($this->system);
        $info_action->send('已经完成发信箱域的添加操作！', 'tree=edm.edmadmin.from');
         
    }
    
    function from_del() {
    
        $edm_from = new edm_from();
        $edm_from->edm_from_id = intval($_GET['edm_from_id']);
        
        if($edm_from->edm_from_id < 1) {
            $info_action = new info_action($this->system);
            $info_action->send('发信箱域的标识不能是空值！', 'tree=edm.edmadmin.from');
        }
        
        // delete from edm_from_list
        $sql = "DELETE FROM edm_from_list WHERE edm_from_id='{$edm_from->edm_from_id}'";
        mysql_query($sql, $this->system->mysql->conn);
        
        // delete from imail database
        $sql = "SELECT edm_from_domain FROM edm_from WHERE edm_from_id='{$edm_from->edm_from_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        $edm_from->edm_from_domain = $row['edm_from_domain'];
        
            // get imail link
            $this->edmmisc_action->mysql_imail_init();
        
        $edm_from_domain_remix = str_replace('.', '_', $edm_from->edm_from_domain);
        $sql = "DROP TABLE IF EXISTS {$edm_from_domain_remix}";
        mysql_query($sql, $this->edmmisc_action->mysql_imail->conn);
        
        // delete from edm_from
        $sql = "DELETE FROM edm_from WHERE edm_from_id='{$edm_from->edm_from_id}'";
        mysql_query($sql, $this->system->mysql->conn);
        
        $info_action = new info_action($this->system);
        $info_action->send('已完成发信箱域的删除操作！', 'tree=edm.edmadmin.from');
        
    }
    
    // from list
    
    function from_list() {
        
        $edm_from_list = new edm_from_list();
        $edm_from_list->edm_from_id = intval($_GET['edm_from_id']);
        
        if($edm_from_list->edm_from_id < 1) {
            $info_action = new info_action($this->system);
            $info_action->send('发信箱域标识不能是空值！', 'tree=edm.edmadmin.from');
        }
        
        // get edm from list
        $sql = "SELECT edm_from_list_id, edm_from_list_start, edm_from_list_end, edm_from_list_middle_start, edm_from_list_middle_end FROM edm_from_list WHERE edm_from_id='{$edm_from_list->edm_from_id}' ORDER BY edm_from_list_start ASC";
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        $edm_from_list_array = array();
        while($row = mysql_fetch_array($result)) {
            $edm_from_list_array[] = $row;
        }
        
        $this->system->smarty->assign('edm_from_list', $edm_from_list_array);
        
        // get edm from
        $sql = "SELECT edm_from_id, edm_from_domain FROM edm_from WHERE edm_from_id='{$edm_from_list->edm_from_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        $edm_from_array = $row;
        
        $this->system->smarty->assign('edm_from', $edm_from_array);
        $this->system->smarty->display('edm.edmadmin.from_list.tpl');
   
    }
    
    function from_list_add() {
        
        $edm_from_list = new edm_from_list();
        $edm_from_list->edm_from_id = intval($_GET['edm_from_id']);
        $edm_from_list->edm_from_list_start = strtolower(trim($_POST['edm_from_list_start']));
        $edm_from_list->edm_from_list_end = strtolower(trim($_POST['edm_from_list_end']));
        $edm_from_list->edm_from_list_middle_start = abs(intval($_POST['edm_from_list_middle_start']));
        $edm_from_list->edm_from_list_middle_end = abs(intval($_POST['edm_from_list_middle_end']));
        
        $error = 0;
        $error_message = '';
        
        if($edm_from_list->edm_from_id < 1) {
            $error = 1;
            $error_message .= '发信箱域标识不能是空值！<br>';
        }
        if($edm_from_list->edm_from_list_start != '' && !preg_match('/[a-z]+/i', $edm_from_list->edm_from_list_start)) {
            $error = 1;
            $error_message .= '前缀必须是小写字母<br>';
        }
        if($edm_from_list->edm_from_list_end != '' && !preg_match('/[a-z]+/i', $edm_from_list->edm_from_list_end)) {
            $error = 1;
            $error_message .= '后缀必须是小写字母<br>';
        }
        if($edm_from_list->edm_from_list_middle_start == '0' || $edm_from_list->edm_from_list_middle_end == '0') {
            $error = 1;
            $error_message .= '中间字符串不能为 0.<br>';
        }
        if($edm_from_list->edm_from_list_middle_start >= $edm_from_list->edm_from_list_middle_end) {
            $error = 1;
            $error_message .= '中间字符串起始数字不能大于等于结尾数字。<br>';
        }
        if($error) {
            $info_action = new info_action($this->system);
            $info_action->send($error_message, "tree=edm.edmadmin.from_list&edm_from_id={$edm_from_list->edm_from_id}");        
        }
        
        // check mixed
        $sql = "SELECT edm_from_list_id FROM edm_from_list WHERE edm_from_list_start='{$edm_from_list->edm_from_list_start}' AND edm_from_list_end='{$edm_from_list->edm_from_list_end}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        if(mysql_num_rows($result) > 0) {
            $info_action = new info_action($this->system);
            $info_action->send('前缀和后缀已经在数据库中存在！', "tree=edm.edmadmin.from_list&edm_from_id={$edm_from_list->edm_from_id}");
        }
        
        // insert into edm_from_list
        $sql = "INSERT INTO edm_from_list(edm_from_id, edm_from_list_start, edm_from_list_end, edm_from_list_middle_start, edm_from_list_middle_end) VALUES('{$edm_from_list->edm_from_id}', '{$edm_from_list->edm_from_list_start}', '{$edm_from_list->edm_from_list_end}', '{$edm_from_list->edm_from_list_middle_start}', '{$edm_from_list->edm_from_list_middle_end}')";
        mysql_query($sql, $this->system->mysql->conn);
        
        $edm_from_list->edm_from_list_id = mysql_insert_id($this->system->mysql->conn);
        
        // insert into imail
        
        $sql = "SELECT edm_from_id, edm_from_domain, edm_from_password FROM edm_from WHERE edm_from_id='{$edm_from_list->edm_from_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        $edm_from = new edm_from();
        $edm_from->edm_from_id = $row['edm_from_id'];
        $edm_from->edm_from_domain = $row['edm_from_domain'];
        $edm_from->edm_from_password = $row['edm_from_password'];
        
        $edm_from_domain_remix = str_replace('.', '_', $edm_from->edm_from_domain);
        
        $v = '';
        for($i = intval($edm_from_list->edm_from_list_middle_start);$i <= intval($edm_from_list->edm_from_list_middle_end);++$i) {
            // userid, password, fullname, userdir, mailaddr, edm_from_list_id
            $v .= "('{$edm_from_list->edm_from_list_start}{$i}{$edm_from_list->edm_from_list_end}', '{$edm_from->edm_from_password}', '{$edm_from_list->edm_from_list_start}{$i}{$edm_from_list->edm_from_list_end}', 'D:\\\\IMail\\\\Data\\\\{$edm_from_domain_remix}\\\\users\\\\{$edm_from_list->edm_from_list_start}{$i}{$edm_from_list->edm_from_list_end}', '{$edm_from_list->edm_from_list_start}{$i}{$edm_from_list->edm_from_list_end}@{$edm_from->edm_from_domain}', '{$edm_from_list->edm_from_list_id}'),";
        }
        $v = substr($v, 0, -1);
        
            // get imail db connection
            $this->edmmisc_action->mysql_imail_init();
        
        $sql = "INSERT INTO {$edm_from_domain_remix}(USERID, PASSWORD, FULLNAME, USERDIR, MAILADDR, edm_from_list_id) VALUES{$v}";
//print $sql;
        mysql_query($sql, $this->edmmisc_action->mysql_imail->conn);
        
        $info_action = new info_action($this->system);
        $info_action->send('已经完成发信箱的添加！', "tree=edm.edmadmin.from_list&edm_from_id={$edm_from_list->edm_from_id}");

    }
    
    function from_list_del() {
        
        $edm_from_list = new edm_from_list();
        $edm_from_list->edm_from_id = intval($_GET['edm_from_id']);
        $edm_from_list->edm_from_list_id = intval($_GET['edm_from_list_id']);
        
        $error = 0;
        $error_message = '';
        if($edm_from_list->edm_from_id < 1) {
            $error = 1;
            $error_message .= '发信箱域标识不能是空值！<br>';
        }
        if($edm_from_list->edm_from_list_id < 1) {
            $error = 1;
            $error_message .= '发信箱标识不能是空值！<br>';
        }
        if($error) {
            $info_action = new info_action($this->system);
            $info_action->send($error_message, "tree=edm.edmadmin.from_list&edm_from_id={$edm_from_list->edm_from_id}");        
        }
        
        // delete from imail table
        $sql = "SELECT edm_from_id, edm_from_domain FROM edm_from WHERE edm_from_id='{$edm_from_list->edm_from_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        $edm_from = new edm_from();
        $edm_from->edm_from_id = $row['edm_from_id'];
        $edm_from->edm_from_domain = $row['edm_from_domain'];
        
        $edm_from_domain_remix = str_replace('.', '_', $edm_from->edm_from_domain);
        
            // get imail connectinon
            $this->edmmisc_action->mysql_imail_init();
            
        $sql = "DELETE FROM {$edm_from_domain_remix} WHERE edm_from_list_id='{$edm_from_list->edm_from_list_id}'";
        mysql_query($sql, $this->edmmisc_action->mysql_imail->conn);
        
        // delete form edm_from_list
        $sql = "DELETE FROM edm_from_list WHERE edm_from_list_id='{$edm_from_list->edm_from_list_id}'";
        mysql_query($sql, $this->system->mysql->conn);
        
        $info_action = new info_action($this->system);
        $info_action->send('已完成删除发信箱的操作！', "tree=edm.edmadmin.from_list&edm_from_id={$edm_from_list->edm_from_id}");
    
    }
    
    // to
    
    function to_user() {
        
        $sql = "SELECT user_id, user_type, user_name, user_contact, user_email, user_mobile FROM user ORDER BY user_id ASC";
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        $to_user_array = array();
        $to_user_array[] = array('user_id' => '0',
                                  'user_type' => USER_SYSTEM,
                                  'user_name' => '#system',
                                  'user_contact' => 'system',
                                  'user_email' => 'system',
                                  'user_mobile' => 'system',
                                  );
        
        while($row = mysql_fetch_array($result)) {
            $to_user_array[] = $row;
        }
        
        $this->system->smarty->assign('to_user', $to_user_array);
        $this->system->smarty->display('edm.edmadmin.to_user.tpl');
    
    }
    
    function to() {
        
        $edm_to = new edm_to();
        $edm_to->user_id = intval($_GET['user_id']);
        
        if($edm_to->user_id < 0) {
            $info_action = new info_action($this->system);
            $info_action->send('用户标识不能是空值！', 'tree=edm.edmadmin.to_user');
        }
        
        $sql = "SELECT user_id, user_name FROM user WHERE user_id='{$edm_to->user_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        $user = new user();
        $user->user_id = $row['user_id'];
        $user->user_name = $row['user_name'];
        
        if($edm_to->user_id == '0') {
            $user->user_id = 0;
            $user->user_name = '#system';
        }
        
        $this->system->smarty->assign('user', get_object_vars($user));        
        
        $sql = "SELECT edm_to_id, user_id, edm_to_group, edm_to_count, edm_to_is_delete FROM edm_to WHERE user_id='{$edm_to->user_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        $edm_to_array = array();
        
        while($row = mysql_fetch_array($result)) {
            $edm_to_array[] = $row;
        }
        
        $this->system->smarty->assign('edm_to', $edm_to_array);
        $this->system->smarty->display('edm.edmadmin.to.tpl');
    }
    
    function to_add() {
        
        $edm_to = new edm_to();
        $edm_to->user_id = intval($_GET['user_id']);
        $edm_to->edm_to_group = str_replace(' ', '-', trim($_POST['edm_to_group']));
        $edm_to_file = new file_upload('edm_to_file');
        
        $error = 0;
        $error_message = '';
        if($edm_to->user_id < 0) {
            $error = 1;
            $error_message .= "用户标识不能是空值。<br>";
        }
        if($edm_to->edm_to_group == '') {
            $error = 1;
            $error_message .= "收信箱类别名称不能是空值。<br>";
        }
        if($edm_to_file->error != '0') {
            $error = 1;
            $error_message .= "{$edm_to_file->message} 请重新上传。<br>";
        }
        if($error) {
            $edm_to_file->delete();
            $info_action = new info_action($this->system);
            $info_action->send($error_message, 'tree=edm.edmadmin.to&user_id=' . $edm_to->user_id);
        }
        
        // check group exists
        $sql = "SELECT count(edm_to_id) AS count FROM edm_to WHERE user_id='{$edm_to->user_id}' AND edm_to_group='{$edm_to->edm_to_group}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        if($row['count'] > 0) {
            $edm_to_file->delete();
            $info_action = new info_action($this->system);
            $info_action->send('收信箱类别已经存在！', 'tree=edm.edmadmin.to&user_id=' . $edm_to->user_id);            
        }
        
       
        // get email addr
        $edm_to_email = $this->edmmisc_action->get_email_from_file($edm_to_file->tmp_name, 50000);
        if(!$edm_to_email) {
            $edm_to_file->delete();
            $info_action = new info_action($this->system);
            $info_action->send('上传的文件中不存在邮件地址，请重新上传。', 'tree=edm.edmadmin.to&user_id=' . $edm_to->user_id);          
        }
        
        $edm_to_email_count = sizeof($edm_to_email); 
        
        // insert into edm_to
        $sql = "INSERT INTO edm_to(user_id, edm_to_group, edm_to_count) VALUES('{$edm_to->user_id}', '{$edm_to->edm_to_group}', '{$edm_to_email_count}')";
        mysql_query($sql, $this->system->mysql->conn);
        $edm_to->edm_to_id = mysql_insert_id($this->system->mysql->conn);
        
        // insert into edm_to_list
        $sql_values = '';
        foreach($edm_to_email as $v) {
            $sql_values .= "('{$edm_to->edm_to_id}', '{$v}', CRC32('{$v}')),";
        }
        $sql_values = substr($sql_values, 0, -1);
        $sql = "INSERT INTO edm_to_list(edm_to_id, edm_to_value, edm_to_value_hash) VALUES{$sql_values}";
        mysql_query($sql, $this->system->mysql->conn);
        
        // delete temp file
        $edm_to_file->delete();
        
        $info_action = new info_action($this->system);
        $info_action->send('已完成添加收信箱电子邮件地址的操作！', 'tree=edm.edmadmin.to&user_id=' . $edm_to->user_id);        
  
    }
    
    function to_del() {
    
        $edm_to = new edm_to();
        $edm_to->edm_to_id = intval($_GET['edm_to_id']);
        $edm_to->user_id = intval($_GET['user_id']);
        
        if($edm_to->edm_to_id < 1) {
            $info_action = new info_action($this->system);
            $info_action->send('收信箱类别标识不能是空值。', 'tree=edm.edmadmin.to&user_id=' . $edm_to->user_id);
        }
        
        // delete from edm_to_list
        $sql = "DELETE FROM edm_to_list WHERE edm_to_id={$edm_to->edm_to_id}";
        mysql_query($sql, $this->system->mysql->conn);
        
        // delete from edm_to
        $sql = "DELETE FROM edm_to WHERE edm_to_id='{$edm_to->edm_to_id}'";
        mysql_query($sql, $this->system->mysql->conn);
        
        $info_action = new info_action($this->system);
        $info_action->send('已完成收信箱类别的删除操作。', 'tree=edm.edmadmin.to&user_id=' . $edm_to->user_id);
        
    }
    
    function to_export() {
        
        $edm_to = new edm_to();
        $edm_to->edm_to_id = intval($_GET['edm_to_id']);
        $edm_to->user_id = intval($_GET['user_id']);
        
        if($edm_to->edm_to_id < 1) {
            $info_action = new info_action($this->system);
            $info_action->send('收信箱类别标识不能是空值。', 'tree=edm.edmadmin.to&user_id=' . $edm_to->user_id);
        }
        
        // get group name
        $sql = "SELECT edm_to_group, edm_to_count FROM edm_to WHERE edm_to_id='{$edm_to->edm_to_id}'";
        $result = mysql_query($sql, $this->system->mysql->conn);
        $row = mysql_fetch_array($result);
        
        $edm_to->edm_to_group = $row['edm_to_group'];
        $edm_to->edm_to_count = $row['edm_to_count'];
        
        // get email data
        $sql = "SELECT edm_to_value FROM edm_to_list WHERE edm_to_id={$edm_to->edm_to_id} AND edm_to_value_deleted=0";
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        $edm_to_value = array();
        while($row = mysql_fetch_array($result)) {
            $edm_to_value[] = $row['edm_to_value'];
        }
        
        // set download
        $edm_to_data = $this->edmmisc_action->export_email_to_text($edm_to_value);
        $edm_to_file_name = urlencode(str_replace(' ', '-', $edm_to->edm_to_group) . '-' . $edm_to->edm_to_count . '个.txt');
        
        $this->system->common->set_download($edm_to_file_name, $edm_to_data);
    
    }
    
    // audit
    
    function audit() {
    
        $sql = "
SELECT
  `job`.`edm_job_status`, `job`.`edm_job_count_plan`,
  `user`.`user_name`, `job`.`edm_job_id`
FROM
  `edm_job` `job` LEFT JOIN
  `user` ON `user`.`user_id` = `job`.`user_id`
WHERE
  `job`.`edm_job_status`='" . EDM_JOB_STATUS_WAIT_FOR_AUDIT . "'
ORDER BY
  `job`.`edm_job_id` ASC
";
        $result = mysql_query($sql, $this->system->mysql->conn);
        
        $edm_job = array();
        while($row = mysql_fetch_array($result)) {
            $edm_job[] = $row;
        }
        
        $this->system->smarty->assign('edm_job', $edm_job);
        $this->system->smarty->display('edm.edmadmin.audit.tpl');
        
    }
    function audit_this() {
        
        $edm_job = new edm_job();
        $edm_job->edm_job_id = intval($_GET['edm_job_id']);
        
        if($edm_job->edm_job_id < 1) {
            $info_action = new info_action($this->system);
            $info_action->send('任务序号不能是空值！', 'tree=edm.edmadmin.audit');
        }
        
        if($_SERVER['REQUEST_METHOD'] == 'POST') {
            
            $edm_job->edm_job_message = trim($_POST['edm_job_message']);
            $edm_job_audit = intval($_POST['edm_job_audit']);
            
            if($edm_job_audit == EDM_JOB_STATUS_WAIT_FOR_JOB_CREATE) {
                
                $edm_job->edm_job_status = EDM_JOB_STATUS_WAIT_FOR_JOB_CREATE;
                // update message
                $edm_job->edm_job_message = '';
                
            } else {
                $edm_job->edm_job_status = EDM_JOB_STATUS_AUDIT_FAILED;
            }
            
            $sql = "UPDATE edm_job SET edm_job_message='{$edm_job->edm_job_message}', edm_job_status='{$edm_job->edm_job_status}' WHERE edm_job_id='{$edm_job->edm_job_id}' ";
            mysql_query($sql, $this->system->mysql->conn);

            $info_action = new info_action($this->system);
            $info_action->send('已完成审核发送任务的操作。', 'tree=edm.edmadmin.audit');            
        
        } else {
            
            $sql = "
SELECT
  `content`.`edm_content_subject`, `content`.`edm_content_altbody`,
  `to`.`edm_to_group`, `to`.`edm_to_count`, `job`.`edm_job_name`,
  `job`.`edm_job_status`, `job`.`edm_job_count_plan`,
  `job`.`edm_to_id`
FROM
  `edm_job` `job` LEFT JOIN
  `edm_to` `to` ON `to`.`edm_to_id` = `job`.`edm_to_id` LEFT JOIN
  `edm_content` `content` ON `content`.`edm_content_id` = `job`.`edm_content_id`
WHERE
  `job`.`edm_job_id`='{$edm_job->edm_job_id}'
    ";
            $result = mysql_query($sql, $this->system->mysql->conn);
            $edm_job_array = mysql_fetch_array($result);
            
            $this->system->smarty->assign('edm_job', $edm_job_array);
            
            $sql = "SELECT edm_to_value FROM edm_to_list WHERE edm_to_id='{$edm_job_array['edm_to_id']}'";
            $result = mysql_query($sql, $this->system->mysql->conn);
            
            $edm_to_value = array();
            while($row = mysql_fetch_array($result)) {
                $edm_to_value[] = $row['edm_to_value'];
            }

            
            $edm_to_value = $this->edmmisc_action->get_email_domain_percent($edm_to_value, 15);
        
            $this->system->smarty->assign('edm_to_value', $edm_to_value);
            
            $this->system->smarty->assign('edm_job_id', $edm_job->edm_job_id);
            
            $this->system->smarty->display('edm.edmadmin.audit_this.tpl');
        }
    
    }
    
}
?>
