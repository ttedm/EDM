<?php
//标识
class edm_to_lisrt{

    var $edm_to_id;
    var $edm_to_value;
    
}  
?>
