<?php
// 标识
class user { 
    
    var $user_id;
    var $user_pid;
    var $user_type;
    var $user_name;
    var $user_password;
    var $user_telephone;
    var $user_mobile;
    var $user_contact;
    var $user_corporation;
    var $user_email;
    var $user_fax;
    var $user_zipcode;
    var $user_address;
    var $user_qq;
    var $user_msn;

    var $user_lock;
    var $user_register_time;
    var $user_domain;
    
    
    // system
    
    var $user_invite_code;
    
  
 
}

  
?>
