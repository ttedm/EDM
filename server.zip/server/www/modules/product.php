<?php
//标识
class product {
    
    var $product_id;
    var $prodcut_slug;
    var $product_name;
    var $product_unit;
    var $product_order;

}
?>
