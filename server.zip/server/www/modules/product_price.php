<?php
//标识
class product_price {
    
    var $product_price_id;
    var $user_id;
    var $product_id;
    var $product_direct_unit_price;
    var $product_direct_mini_price;
    var $product_agent_unit_price;
    var $product_agent_mini_price;
    var $product_available_count;
    var $product_used_count;
}
?>
