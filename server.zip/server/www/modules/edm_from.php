<?php
// 标识
class edm_from { 
    
      var $edm_from_id;
      var $edm_from_domain;
      var $edm_from_password;
       
}
  
?>
