<?php
class service_api_action {

    var $system;
    var $edmmisc_action;
    
    function service_api_action(&$system) {
        
        $this->system = $system;
        
        $this->edmmisc_action = new edmmisc_action($this->system);
        
        // brdms_jobs init
        $this->edmmisc_action->mysql_jobs_init();
       
        $action = $this->system->action;

// edm        
        if($action == 'edm_set_job') {
            $this->edm_set_job();
        }
        if($action == 'edm_get_job') {
            $this->edm_get_job();
        }
        if($action == 'edm_get_single_job') {
            $this->edm_get_single_job();
        }
// sms

        if($action == 'sms') {
            $this->sms();
        }
        if($action == 'efax') {
            $this->efax();
        }
        if($action == 'sem') {
            $this->sem();
        }
        
    }
    
       
    function edm_set_job() {
        
        if($_SERVER['REQUEST_METHOD'] == 'POST') {
            
            $r = array();
            
            $user_name = trim(strip_tags($_POST['user_name']));
            $user_password = trim(strip_tags($_POST['user_password'])); 
            $edm_job_name = trim(strip_tags($_POST['job_name'])); 
            $edm_to_group = trim(strip_tags($_POST['to_group'])); 
            $edm_to_value = trim(strip_tags($_POST['to_value'])); 
            $edm_content_subject = trim(strip_tags($_POST['content_subject'])); 
            $edm_content_altbody = trim(html_entity_decode($_POST['content_altbody']));
            
            $valid = new valid();
            
            if(!$valid->is_user_name($user_name, 5, 16) || !$valid->is_password($user_password, 6, 16)) {
                $r['info']['code'] = 2;
                $r['info']['message'] = '用户名或密码错误。';
                die(json_encode($r));
            }
            
            if(!$valid->is_valid_length($edm_job_name, 1, 50)) {
                $r['info']['code'] = 3;
                $r['info']['message'] = '任务名称必须少于 50 个字符。';
                die(json_encode($r));            
            }
            
            if(!$valid->is_valid_length($edm_to_group, 1, 50)) {
                $r['info']['code'] = 4;
                $r['info']['message'] = '邮箱列表名称必须少于 50 个字符。';
                die(json_encode($r));            
            }
            
            if(!$valid->is_valid_length($edm_content_subject, 1, 50)) {
                $r['info']['code'] = 5;
                $r['info']['message'] = '邮件标题必须少于 50 个字符。';
                die(json_encode($r));            
            }
            
            if(!$valid->is_valid_length($edm_content_altbody, 1, 100000)) {
                $r['info']['code'] = 6;
                $r['info']['message'] = '邮件正文必须少于 100000 个字符。';
                die(json_encode($r));            
            }
            
            $edm_to_value = $this->edmmisc_action->get_email_from_string($edm_to_value, ',', 50000);
            if(!is_array($edm_to_value)) {
                $r['info']['code'] = 7;
                $r['info']['message'] = '邮箱地址不合格。';
                die(json_encode($r));             
            }
            
            $edm_to_value_size = sizeof($edm_to_value);
            $edm_to_value_percent = $this->edmmisc_action->get_email_domain_percent($edm_to_value, 1);
            $edm_to_value_percent = intval(current($edm_to_value_percent));
            
            if($edm_to_value_size > 1000 && $edm_to_value_percent > 50) {
                $r['info']['code'] = 8;
                $r['info']['message'] = '单个域的邮箱比率过高。';
                die(json_encode($r));                 
            }
            
            $sql = "SELECT edm_content_filter_value FROM edm_content_filter";
            $result = mysql_query($sql, $this->system->mysql->conn);
            $content_filter = array();
            while($row = mysql_fetch_array($result)) {
                $content_filter[] = $row['edm_content_filter_value'];
            }
            
            if($this->edmmisc_action->get_content_filter($edm_content_subject, $content_filter)) {
                $r['info']['code'] = 9;
                $r['info']['message'] = '邮件标题包含非法关键字。';
                die(json_encode($r));            
            }
            
            if($this->edmmisc_action->get_content_filter($edm_content_altbody, $content_filter)) {
                $r['info']['code'] = 10;
                $r['info']['message'] = '邮件正文包含非法关键字。';
                die(json_encode($r));            
            }
            
            // get user_id
            $user_password = sha1($user_password);
            $sql = "SELECT user_id FROM user WHERE user_name='{$user_name}' AND user_password='{$user_password}' AND user_lock='" . USER_UNLOCK . "'";
            $result = mysql_query($sql, $this->system->mysql->conn);
            if(mysql_num_rows($result) < 1) {
                $r['info']['code'] = 2;
                $r['info']['message'] = '用户名或密码错误，或者用户被锁定。';
                die(json_encode($r));              
            }
            $row = mysql_fetch_array($result);
            $user_id = intval($row['user_id']);
            
            // admin not use this api
            if($user_id == 1) {
                $r['info']['code'] = 2;
                $r['info']['message'] = '用户名或密码错误。';
                die(json_encode($r));                
            }
            
            // check ava counter
            $sql = "SELECT pp.product_available_count AS product_available_count FROM product_price pp LEFT JOIN product p ON pp.product_id=p.product_id WHERE p.product_slug='EDM' AND pp.user_id='{$user_id}'";
            $result = mysql_query($sql, $this->system->mysql->conn);
            $row = mysql_fetch_array($result);
            
            if(mysql_num_rows($result) > 0) {
                $product_available_count = $row['product_available_count'];
            } else {
                $product_available_count = 0;
            }
            
            if($edm_to_value_size > $product_available_count) {
                $r['info']['code'] = 11;
                $r['info']['message'] = '库存不足，请与上级经销商联系。';
                die(json_encode($r));                 
            }
            
            // insert edm_to
            $sql = "INSERT INTO edm_to(user_id, edm_to_group, edm_to_count) VALUES('{$user_id}', '{$edm_to_group}', '{$edm_to_value_size}')";
            mysql_query($sql, $this->system->mysql->conn);
            
            $edm_to_id = mysql_insert_id($this->system->mysql->conn);
            
            $sql = "INSERT INTO edm_to_list(edm_to_id, edm_to_value, edm_to_value_hash) VALUES";
            foreach($edm_to_value as $v) {
                $sql .= "('{$edm_to_id}', '{$v}', CRC32('{$v}')),";
            }
            $sql = substr($sql, 0, -1);
            mysql_query($sql, $this->system->mysql->conn);
            
            // insert edm_content
            $edm_content_time = time();
            $edm_content_altbody = addslashes($this->system->common->tidy_clean(stripslashes($edm_content_altbody)));
            $sql = "INSERT INTO edm_content(user_id, edm_content_subject, edm_content_altbody, edm_content_time) VALUES('{$user_id}', '{$edm_content_subject}', '{$edm_content_altbody}', '{$edm_content_time}')";
            mysql_query($sql, $this->system->mysql->conn);
            
            $edm_content_id = mysql_insert_id($this->system->mysql->conn);
            
            // insert edm_job
            $edm_job_status = EDM_JOB_STATUS_WAIT_FOR_JOB_CREATE;
            $sql = "INSERT INTO edm_job(edm_job_name, edm_job_status, edm_job_count_plan, user_id, edm_to_id, edm_content_id) VALUES('{$edm_job_name}', '{$edm_job_status}', '{$edm_to_value_size}', '{$user_id}', '{$edm_to_id}', '{$edm_content_id}')";
            mysql_query($sql, $this->system->mysql->conn);
            
            // send ok
            $r['info']['code'] = 1;
            $r['info']['message'] = '已完成新增任务的操作。';
            die(json_encode($r)); 
                   
        }
        
    }
    
    function edm_get_job() {
        
        if($_SERVER['REQUEST_METHOD'] == 'POST') {
           
            $r = array();
            
            $user_name = trim(strip_tags($_POST['user_name']));
            $user_password = trim(strip_tags($_POST['user_password']));
            
            $valid = new valid();
            
            if(!$valid->is_user_name($user_name, 5, 16) || !$valid->is_password($user_password, 6, 16)) {
                $r['info']['code'] = 2;
                $r['info']['message'] = '用户名或密码错误。';
                die(json_encode($r));
            }
            
            // get user_id
            $user_password = sha1($user_password);
            $sql = "SELECT user_id FROM user WHERE user_name='{$user_name}' AND user_password='{$user_password}' AND user_lock='" . USER_UNLOCK . "'";
            $result = mysql_query($sql, $this->system->mysql->conn);
            if(mysql_num_rows($result) < 1) {
                $r['info']['code'] = 2;
                $r['info']['message'] = '用户名或密码错误，或者用户被锁定。';
                die(json_encode($r));              
            }
            $row = mysql_fetch_array($result);
            $user_id = intval($row['user_id']);
            
            // admin not use this api
            if($user_id == 1) {
                $r['info']['code'] = 2;
                $r['info']['message'] = '用户名或密码错误。';
                die(json_encode($r));                
            }
            
            // get job result
            $sql = "SELECT edm_job_id, edm_job_name, edm_job_status, edm_job_start_time, edm_job_end_time, edm_job_count_real, edm_job_count_success, edm_job_count_bounce_from, edm_job_count_bounce_to_soft, edm_job_count_bounce_to_hard, edm_job_count_bounce_data, edm_job_count_bounce_connect, edm_job_count_bounce_other, edm_job_count_open, edm_job_count_click FROM edm_job WHERE user_id={$user_id} AND (edm_job_status='" . EDM_JOB_STATUS_JOB_RUNNING . "' OR edm_job_status='" . EDM_JOB_STATUS_JOB_FINISHED . "') ORDER BY edm_job_id DESC";
            $result = mysql_query($sql, $this->system->mysql->conn);
            
            $edm_job_array = array();
            while($row = mysql_fetch_array($result)) {
                $edm_job_array[] = array('job_id'                        => intval($row['edm_job_id']),
                                         'job_name'                      => $row['edm_job_name'],
                                         'job_status'                    => intval($row['edm_job_status']),
                                         'job_start_time'                => intval($row['edm_job_start_time']),
                                         'job_end_time'                  => intval($row['edm_job_end_time']),
                                         'job_count_plan'                => intval($row['edm_job_count_real']),
                                         'job_count_real'                => intval($row['edm_job_count_success'] + $row['edm_job_count_bounce_from'] + $row['edm_job_count_bounce_to_soft'] + $row['edm_job_count_bounce_to_hard'] + $row['edm_job_count_bounce_data'] + $row['edm_job_count_bounce_connect'] + $row['edm_job_count_bounce_other']),
                                         'job_count_success'             => intval($row['edm_job_count_success']),
                                         'job_count_bounce_from'         => intval($row['edm_job_count_bounce_from']),
                                         'job_count_bounce_to_soft'      => intval($row['edm_job_count_bounce_to_soft']),
                                         'job_count_bounce_to_hard'      => intval($row['edm_job_count_bounce_to_hard']),
                                         'job_count_bounce_data'         => intval($row['edm_job_count_bounce_data']),
                                         'job_count_bounce_connect'      => intval($row['edm_job_count_bounce_connect']),
                                         'job_count_bounce_other'        => intval($row['edm_job_count_bounce_other']),
                                         'job_count_open'                => intval($row['edm_job_count_open']),
                                         'job_count_click'               => intval($row['edm_job_count_click']),
                                         );
            }
            
            mysql_free_result($result);
            
            $r['result'] = $edm_job_array;
            $r['info']['code'] = 1;
            $r['info']['message'] = '已完成获取任务列表的操作。';
            
            die(json_encode($r));             
        
        }
    
    }
    
    function edm_get_single_job() {
        
        if($_SERVER['REQUEST_METHOD'] == 'POST') {
           
            $r = array();
            
            $user_name = trim(strip_tags($_POST['user_name']));
            $user_password = trim(strip_tags($_POST['user_password']));
            $edm_job_id = intval($_POST['job_id']);
            
            $valid = new valid();
            
            if(!$valid->is_user_name($user_name, 5, 16) || !$valid->is_password($user_password, 6, 16)) {
                $r['info']['code'] = 2;
                $r['info']['message'] = '用户名或密码错误。';
                die(json_encode($r));
            }
            
            // get user_id
            $user_password = sha1($user_password);
            $sql = "SELECT user_id FROM user WHERE user_name='{$user_name}' AND user_password='{$user_password}' AND user_lock='" . USER_UNLOCK . "'";
            $result = mysql_query($sql, $this->system->mysql->conn);
            if(mysql_num_rows($result) < 1) {
                $r['info']['code'] = 2;
                $r['info']['message'] = '用户名或密码错误，或者用户被锁定。';
                die(json_encode($r));              
            }
            $row = mysql_fetch_array($result);
            $user_id = intval($row['user_id']);
            
            // admin not use this api
            if($user_id == 1) {
                $r['info']['code'] = 2;
                $r['info']['message'] = '用户名或密码错误。';
                die(json_encode($r));                
            }
            
            // check user_id and edm_job_id
            $sql = "SELECT edm_to_id FROM edm_job WHERE user_id='{$user_id}' AND edm_job_id='{$edm_job_id}'";
            $result = mysql_query($sql, $this->system->mysql->conn);
            
            if(mysql_num_rows($result) < 1) {
                $r['info']['code'] = 3;
                $r['info']['message'] = '任务序号错误。';
                die(json_encode($r));             
            }
            
            $row = mysql_fetch_array($result);
            $edm_to_id = $row['edm_to_id'];
            
            // check edm_to is system mail list
            $sql = "SELECT edm_to_id FROM edm_to WHERE user_id='0' AND edm_to_id='{$edm_to_id}'";
            $result = mysql_query($sql, $this->system->mysql->conn);
            
            if(mysql_num_rows($result) > 0) {
                $r['info']['code'] = 4;
                $r['info']['message'] = '无法显示使用系统邮箱列表发送的单个任务的信息。';
                die(json_encode($r));                 
            }
            
            // get single job
            $sql = "SELECT job_to, job_time, job_result, job_open, job_click FROM edm_job_{$edm_job_id} WHERE job_status='1'";
            $result = mysql_query($sql, $this->edmmisc_action->mysql_jobs->conn);
            
            $edm_single_job = array();
            while($row = mysql_fetch_array($result)) {
                if(intval($row['job_result']) == EDM_SINGLE_JOB_RESULT_SUCCESS) {
                    $job_result = 1;
                } else {
                    $job_result = 0;
                }
                $edm_single_job[] = array('job_to' => $row['job_to'],
                                          'job_time' => intval($row['job_time']),
                                          'job_result' => $job_result,
                                          'job_open' => intval($row['job_open']),
                                          'job_click' => intval($row['job_click']),
                                          );
            }
            
            mysql_free_result($result);
            
            $r['result'] = $edm_single_job;
            $r['info']['code'] = 1;
            $r['info']['message'] = '已完成获取单个任务列表的操作。';
            
            die(json_encode($r)); 
       
        }
    
    }
}
?>
