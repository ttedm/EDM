<?php
class edmmisc_action {
    
    var $system;
    var $mysql_imail;
    var $mysql_jobs;
    
    function edmmisc_action(&$system) {
        $this->system = $system;
    }
    
    function mysql_imail_init() {
        
        $this->mysql_imail = new mysql();
        $this->mysql_imail->set_vars(MYSQL_SMTP_HOST, MYSQL_SMTP_USERNAME, MYSQL_SMTP_PASSWORD);
        $this->mysql_imail->get_connection();
        
        if(!$this->mysql_imail->conn) {
            $info_action = new info_action($this->system);
            $info_action->send('数据库 SMTP 连接错误，请与管理员联系。', '');       
        }
        
        $this->mysql_imail->set_parameters();
        $this->mysql_imail->use_db(MYSQL_SMTP_DATABASE);    
    }
    
    function mysql_jobs_init() {
        
        $this->mysql_jobs = new mysql();
        $this->mysql_jobs->set_vars(MYSQL_JOBS_HOST, MYSQL_JOBS_USERNAME, MYSQL_JOBS_PASSWORD);
        $this->mysql_jobs->get_connection();
        
        if(!$this->mysql_jobs->conn) {
            $info_action = new info_action($this->system);
            $info_action->send('数据库 JOBS 连接错误，请与管理员联系。', '');       
        }
        
        $this->mysql_jobs->set_parameters();
        $this->mysql_jobs->use_db(MYSQL_JOBS_DATABASE);       
    }
    
    function get_email_from_file($file, $max) {
        
        // change file encoding to utf-8
        $content = file_get_contents($file);
        $enc = $this->system->common->detect_encoding($file);
        $content = @iconv($enc, 'UTF-8', $content);
        //file_put_contents($file, $content);
        
        $content = strtolower($content);
        $tlds = 'AERO|ARPA|ASIA|BIZ|CAT|COM|COOP|EDU|GOV|INFO|INT|JOBS|MOBI|MIL|MUSEUM|NAME|NET|ORG|PRO|TRAVEL|TEL|XXX|AC|AD|AE|AF|AG|AI|AL|AM|AN|AO|AQ|AR|AS|AT|AU|AW|AX|AZ|BA|BB|BD|BE|BF|BG|BH|BI|BJ|BM|BN|BO|BR|BS|BT|BV|BW|BY|BZ|CA|CC|CD|CF|CG|CH|CI|CK|CL|CM|CN|CO|CR|CU|CV|CX|CY|CZ|DE|DJ|DK|DM|DO|DZ|EC|EE|EG|ER|ES|ET|EU|FI|FJ|FK|FM|FO|FR|GA|GB|GD|GE|GF|GG|GH|GI|GL|GM|GN|GP|GQ|GR|GS|GT|GU|GW|GY|HK|HM|HN|HR|HT|HU|ID|IE|IL|IM|IN|IO|IQ|IR|IS|IT|JE|JM|JO|JP|KE|KG|KH|KI|KM|KN|KP|KR|KW|KY|KZ|LA|LB|LC|LI|LK|LR|LS|LT|LU|LV|LY|MA|MC|MD|ME|MG|MH|MK|ML|MM|MN|MO|MP|MQ|MR|MS|MT|MU|MV|MW|MX|MY|MZ|NA|NC|NE|NF|NG|NI|NL|NO|NP|NR|NU|NZ|OM|PA|PE|PF|PG|PH|PK|PL|PM|PN|PR|PS|PT|PW|PY|QA|RE|RO|RS|RU|RW|SA|SB|SC|SD|SE|SG|SH|SI|SJ|SK|SL|SM|SN|SO|SR|ST|SU|SV|SY|SZ|TC|TD|TF|TG|TH|TJ|TK|TL|TM|TN|TO|TP|TR|TT|TV|TW|TZ|UA|UG|UK|US|UY|UZ|VA|VC|VE|VG|VI|VN|VU|WF|WS|YE|YT|ZA|ZM|ZW';
        $pattern = '/([a-z0-9]{1}[a-z0-9-_\+\.]+[a-z0-9]{1}@[a-z0-9]{1}([a-z0-9_-]+\.){0,1}[a-z0-9_-]+\.([a-z0-9_-]+\.){0,1}(' . $tlds . '))/i';
        preg_match_all($pattern, $content, $matches);
        $mails = $matches[1];
        if(is_array($mails) && sizeof($mails)!=0) {
            $mails = array_unique($mails);
            shuffle($mails);
            $mails = array_merge($mails);
            $mails = array_slice($mails, 0, $max);
        } else {
            $mails = FALSE;
        }        
        return $mails;

    }
    
    function get_email_from_string($string, $separator, $max) {
        
        $content = strtolower($string);
        $tlds = 'AERO|ARPA|ASIA|BIZ|CAT|COM|COOP|EDU|GOV|INFO|INT|JOBS|MOBI|MIL|MUSEUM|NAME|NET|ORG|PRO|TRAVEL|TEL|XXX|AC|AD|AE|AF|AG|AI|AL|AM|AN|AO|AQ|AR|AS|AT|AU|AW|AX|AZ|BA|BB|BD|BE|BF|BG|BH|BI|BJ|BM|BN|BO|BR|BS|BT|BV|BW|BY|BZ|CA|CC|CD|CF|CG|CH|CI|CK|CL|CM|CN|CO|CR|CU|CV|CX|CY|CZ|DE|DJ|DK|DM|DO|DZ|EC|EE|EG|ER|ES|ET|EU|FI|FJ|FK|FM|FO|FR|GA|GB|GD|GE|GF|GG|GH|GI|GL|GM|GN|GP|GQ|GR|GS|GT|GU|GW|GY|HK|HM|HN|HR|HT|HU|ID|IE|IL|IM|IN|IO|IQ|IR|IS|IT|JE|JM|JO|JP|KE|KG|KH|KI|KM|KN|KP|KR|KW|KY|KZ|LA|LB|LC|LI|LK|LR|LS|LT|LU|LV|LY|MA|MC|MD|ME|MG|MH|MK|ML|MM|MN|MO|MP|MQ|MR|MS|MT|MU|MV|MW|MX|MY|MZ|NA|NC|NE|NF|NG|NI|NL|NO|NP|NR|NU|NZ|OM|PA|PE|PF|PG|PH|PK|PL|PM|PN|PR|PS|PT|PW|PY|QA|RE|RO|RS|RU|RW|SA|SB|SC|SD|SE|SG|SH|SI|SJ|SK|SL|SM|SN|SO|SR|ST|SU|SV|SY|SZ|TC|TD|TF|TG|TH|TJ|TK|TL|TM|TN|TO|TP|TR|TT|TV|TW|TZ|UA|UG|UK|US|UY|UZ|VA|VC|VE|VG|VI|VN|VU|WF|WS|YE|YT|ZA|ZM|ZW';
        $pattern = '/([a-z0-9]{1}[a-z0-9-_\+\.]+[a-z0-9]{1}@[a-z0-9]{1}([a-z0-9_-]+\.){0,1}[a-z0-9_-]+\.([a-z0-9_-]+\.){0,1}(' . $tlds . '))/i';
        preg_match_all($pattern, $content, $matches);
        $mails = $matches[1];
        if(is_array($mails) && sizeof($mails)!=0) {
            $mails = array_unique($mails);
            shuffle($mails);
            $mails = array_merge($mails);
            $mails = array_slice($mails, 0, $max);
        } else {
            $mails = FALSE;
        }        
        return $mails;
        
    }
    
    function export_email_to_text($emails = array()) {
        $text = '';
        foreach($emails as $mail) {
            $text .= $mail . "\r\n";
        }
        return $text;
    }
    
    function get_email_domain_percent($emails = array(), $max) {
        $domains = array();
        foreach($emails as $v) {
            list($user, $domain) = explode('@', $v);
            $domains[] = $domain;
        }
        $size = sizeof($domains);
        $domains = array_count_values($domains);
        arsort($domains, SORT_NUMERIC);
        $domains = array_slice($domains, 0, $max);
        $result = array();
        foreach($domains as $k => $v) {
            $result[$k] = round($v/$size, 3) * 100;
        }
        return $result;
    }
    
    function get_content_filter($content, $keywords = array()) {
        foreach($keywords as $keyword) {
            $pattern = "/{$keyword}/iu";
            if(preg_match($pattern, $content)) {
                return 1;
            }
        }
        return 0;
    }
    
    // from uhost uip
    function get_single_from($from_array = array()) {
        $from = $from_array[array_rand($from_array)];
        $middle = mt_rand($from['edm_from_list_middle_start'], $from['edm_from_list_middle_end']);
        $mail = $from['edm_from_list_start'] . $middle . $from['edm_from_list_end'] . '@' . $from['edm_from_domain'];
        return $mail;
    }
    
    function get_single_uhost($uhost_array = array()) {
        $uhost = $uhost_array[array_rand($uhost_array)];
        if($uhost['edm_uhost_type'] == EDM_UHOST_TYPE_YMD) {
            $main = mt_rand(2001, date('Y')) . '0' . mt_rand(1, 9) . mt_rand(10, 31) . mt_rand(1000, 9999);
        } else {
            $main = substr(md5(uniqid()), 0, 12);
        }
        $uhost = strtolower($uhost['edm_uhost_prefix']) . '-' . $main;
        return $uhost;
    }
    
    function get_single_uip($uip_array = array()) {
        //$uip = $uip_array[array_rand($uip_array)];
        //$one = explode('.', $uip['edm_uip_start']);
        //$two = explode('.', $uip['edm_uip_end']);
        //$uip = mt_rand(intval($one[0]), intval($two[0])) . '.' . mt_rand(intval($one[1]), intval($two[1])) . '.' . mt_rand(intval($one[2]), intval($two[2])) . '.' . mt_rand(intval($one[3]), intval($two[3]));
		$uip = '8.8.8.8';
        return $uip;
    }
    
    function get_email_domain($email) {
        $fields = explode('@', $email);
        return $fields[1];
    }
    
    function get_mail_subject($subject, $content_filter = array()) {
       
        // get subject filtered
        $subject = str_replace($content_filter, '', $subject);
                
        return $subject; 
        
    }
    
    function get_mail_data($edm_job_id, $job_id, $job_to, $data, $edm_job_get_click, $edm_content_urls = array(), $content_filter = array()) {
        
        // get content filtered
        $data = str_replace($content_filter, '', $data);
        
        // check language
        $gaza = new Gaza();
        $lang = $gaza->language_detect($data);
        
        // fix href space
        $search = '/href(\s)*=(\s)*/i';
        $replace = 'href=';
        $data = preg_replace($search, $replace, $data);        
        unset($search);
        unset($replace);        
        
        // 点击数统计
        if($edm_job_get_click == '1') {
            if(is_array($edm_content_urls)) {
                foreach($edm_content_urls as $edm_content_url) {
                    
                    $chk_hash = md5(md5($edm_job_id) . $job_id . strtoupper($edm_content_url['edm_content_url_hash']) . SECRET_KEY);
                    $link = 'http://' . SITE_HOST_FEEDBACK . ':' . SITE_SERVER_PORT . '/c/' . $edm_job_id . '/' . $job_id . '/' . strtoupper($chk_hash) . '/' . strtoupper($edm_content_url['edm_content_url_hash']) . '/';
                    
                    $search = array();
                    $replace = array();
                    
                    $search[0] = "href={$edm_content_url['edm_content_url']}";
                    $search[1] = "href='{$edm_content_url['edm_content_url']}'";
                    $search[2] = "href=\"{$edm_content_url['edm_content_url']}\"";
                    
                    $replace[0] = "href={$link}";
                    $replace[1] = "href='{$link}'";
                    $replace[2] = "href=\"{$link}\"";
                    
                    $data = str_ireplace($search, $replace, $data);
                    
                }
            }
            unset($link);
            unset($search);
            unset($replace);
            unset($chk_hash);
        }
        
        // analysis start
        // clear both
        //$data .= "<div style=\"clear: both; padding-top:20px;\"></div>\n";
        
        // start block
        //$data .= "<div align=\"center\">\n";
        //$data .= "<div style=\"font-size: 12px; line-height: 2; font-family: Verdana, Arial, Helvetica, sans-serif; width: 600px; border-top:1px solid #aaaaaa; text-align: center;\">\n";
        
        // 退订
        /*
        $chk_hash = md5(md5($edm_job_id) . $job_to . SECRET_KEY);
        $unsubscribe = 'http://' . SITE_HOST_FEEDBACK . ':' . SITE_SERVER_PORT . '/u/' . $edm_job_id . '/' . $job_to . '/' . strtoupper($chk_hash) . '/'; 
        
        if($lang == 'zh') {
            $data .= "<a href=\"{$unsubscribe}\" target=\"_blank\">取消订阅</a>\n";
        } elseif($lang == 'ja') {
            $data .= "<a href=\"{$unsubscribe}\" target=\"_blank\">購読中止</a>\n";
        } elseif($lang == 'ko') {
            $data .= "<a href=\"{$unsubscribe}\" target=\"_blank\">탈퇴</a>\n";
        } else {
            $data .= "<a href=\"{$unsubscribe}\" target=\"_blank\">Cancel Subscribe</a>\n";
        }
        
        unset($unsubscribe);
        unset($chk_hash);
        */
        
        // 打开数统计
        if($edm_job_get_click == '1') { 
            $chk_hash = md5(md5($edm_job_id) . $job_id . SECRET_KEY);
            $image = 'http://' . SITE_HOST_FEEDBACK . ':' . SITE_SERVER_PORT . '/o/' . $edm_job_id . '/' . $job_id . '/' . strtoupper($chk_hash) . '/';   
            $data .= "<br>\n<img src=\"{$image}\">\n"; 

            unset($image);
            unset($chk_hash);
        }
        
        // end block
        //$data .= "</div>\n</div>\n";
        
        return $data;
        
    }
    
    function get_content_url($v) {
        
        // get urls
        $urls = array();
        
        $html = new simple_html_dom();
        $html->load($v);
        $result = $html->find('a');
        
        if(is_array($result)) {
            foreach($result as $a) {
                $t = trim($a->href);
                //$t = htmlspecialchars_decode($t, ENT_QUOTES);
                //$t = htmlspecialchars($t, ENT_QUOTES);
                if(!empty($t)) {
                    $urls[] = $t; 
                }        
            }        
        }
        
        $html->clear();
        $html = null;
        unset($html);
        unset($v);
        unset($t);
        unset($result);
        
        $urls = array_unique($urls);
        
        // make url and hash
        $content_urls = array();
        
        $c = 0;
        foreach($urls as $url) {
            $content_urls[$c]['url']  = $url;
            $content_urls[$c]['hash'] = md5($url . SECRET_KEY);
            ++$c;
        }
        
        return $content_urls;
         
    }
    
    function remove_html_element($content, $element) {
        $html = new simple_html_dom();
        $html->load($content);
        $finds = $html->find($element);
        if(is_array($finds)) {
            for($i=0;$i<sizeof($finds);++$i) {
                $html->find($element, $i)->outertext = '';
            }
        }
        $result = $html->save();
        $html->clear();
        $html = null;
        unset($html);
        return $result;      
    }
  
    function uni_encode($str, $encoding = 'UTF-8', $prefix = '&#', $postfix = ';') {
        $str = iconv($encoding, 'UCS-2', $str);
        $arrstr = str_split($str, 2);
        $unistr = '';
        for($i = 0, $len = count($arrstr); $i < $len; $i++) {
            $dec = hexdec(bin2hex($arrstr[$i]));
            $unistr .= $prefix . $dec . $postfix;
        }
        return $unistr;
    }

    function uni_decode($unistr, $encoding = 'UTF-8', $prefix = '&#', $postfix = ';') {
        $arruni = explode($prefix, $unistr);
        $unistr = '';
        for($i = 1, $len = count($arruni); $i < $len; $i++) {
            if (strlen($postfix) > 0) {
                $arruni[$i] = substr($arruni[$i], 0, strlen($arruni[$i]) - strlen($postfix));
            }
            $temp = intval($arruni[$i]);
            $unistr .= ($temp < 256) ? chr(0) . chr($temp) : chr($temp / 256) . chr($temp % 256);
        }
        return iconv('UCS-2', $encoding, $unistr);
    } 
     
}
?>