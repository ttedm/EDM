<?php
//标识
class valid {
    
    function is_user_name($v, $s, $e) {
        return (preg_match('/^[a-zA-Z0-9_]+$/', $v) && $this->is_valid_length($v, $s, $e));    
    }
    
    function is_password($v, $s, $e) {
        return (preg_match('/^[a-zA-Z0-9_]+$/', $v) && $this->is_valid_length($v, $s, $e));     
    }    
    
    function is_email($v) {
        return (preg_match('/^[a-zA-Z0-9\.\-_]+@[a-zA-Z0-9\.-]+$/i', $v) && $this->is_valid_length($v, 5, 150));    
    }
    
    function is_mobile($v) {
        return (preg_match('/^[0-9]+$/', $v) && $this->is_valid_length($v, 11, 11));    
   }
    
    function is_phone($v) {
        return (preg_match('/^[0-9\.\-\+]+$/', $v) && $this->is_valid_length($v, 5, 25));     
    }
    
    function is_zipcode($v) {
        return (preg_match('/^[0-9]+$/', $v) && $this->is_valid_length($v, 6, 8));     
    }
    
    function is_qq($v) {
        return (preg_match('/^[0-9]+$/', $v) && $this->is_valid_length($v, 4, 15));        
    }
    
    function is_domain($v) {
        return (preg_match('/^[a-z0-9\-\.]+$/i', $v) && $this->is_valid_length($v, 4, 150));
    }
    
    function is_bank_number($v) {
        return (preg_match('/^[0-9]+$/', $v) && $this->is_valid_length($v, 15, 20));     
    }
    
    function is_valid_length($v, $start, $end) {
        if(mb_strlen($v, 'UTF-8') <= $end && mb_strlen($v, 'UTF-8') >= $start) {
            return TRUE;
        } else {
            return FALSE;
        }
    }
}

?>
