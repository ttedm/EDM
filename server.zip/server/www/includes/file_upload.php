<?php
class file_upload {
    
    var $name;
    var $type;
    var $error;
    var $tmp_name;
    var $size;
    
    var $message; 
    
    function file_upload($form_name) {
        
        $this->name = '';
        $this->type = '';
        $this->error = -1;
        $this->tmp_name = '';
        $this->size = '';
        
        $this->message = '';
        
        if(!isset($_FILES[$form_name])) {
            $this->error = -1;
            $this->message = "返回码：{$this->error}，没有指定上传文件。";
            return;
        }
        
        foreach($_FILES[$form_name] as $k => $v) {
            $this->$k = $v;
        }
        
        if($this->error == UPLOAD_ERR_OK) {
            $this->message = "返回码：{$this->error}，文件上传成功。";
            return;
        }          
        
        if($this->error == UPLOAD_ERR_INI_SIZE) {
            $this->message = "返回码：{$this->error}，上传的文件超过了“最大上传文件大小”选项限制的值。";
            return;            
        }

        if($this->error == UPLOAD_ERR_FORM_SIZE) {
            $this->message = "返回码：{$this->error}，上传文件的大小超过了 HTML 表单中 MAX_FILE_SIZE 选项指定的值。";
            return;            
        }
        
        if($this->error == UPLOAD_ERR_PARTIAL) {
            $this->message = "返回码：{$this->error}，文件只有部分被上传。";
            return;            
        }  
        
        if($this->error == UPLOAD_ERR_NO_FILE) {
            $this->message = "返回码：{$this->error}，没有文件被上传。";
            return;            
        }
        
        if($this->error == UPLOAD_ERR_NO_TMP_DIR) {
            $this->message = "返回码：{$this->error}，找不到临时文件夹。";
            return;            
        }  
        
        if($this->error == UPLOAD_ERR_CANT_WRITE) {
            $this->message = "返回码：{$this->error}，文件写入失败。";
            return;            
        }
             
    }
    
    function delete() {
        @unlink($this->tmp_name);
    }

}
?>
