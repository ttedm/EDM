<?php
//标识
class common {
    
    function gpc_escape() {
        if(!get_magic_quotes_gpc()) {
            _escape($_GET);
            _escape($_POST);
            _escape($_REQUEST);
            _escape($_COOKIE);            
        }  
    }

    function set_cache($t) {
        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header('Expires: ' . gmdate ("D, d M Y H:i:s", time() + $t). " GMT");
        header('Cache-Control: public, max-age=' . $t);
        header('Pragma: Pragma');
    }

    function set_no_cache() {
        header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
    }
    
    function set_download($file_name, $data) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/force-download');
        header('Content-Disposition: attachment; filename=' . $file_name);
        header('Content-Transfer-Encoding: binary');
        echo $data;
    }
    
    function set_php_ini() {
        ini_set('mysql.connect_timeout', -1);
    }    

    function sendmail($subject, $body, $to, $from = MAIL_FROM, $from_name = MAIL_FROMNAME, $host = MAIL_HOST, $password = MAIL_FROM_PASSWORD) {
    
        $mailer = new PHPMailer();
        
        $mailer->ClearAllRecipients();
        
        // local mail server information
        $mailer->CharSet     = 'utf-8';
        $mailer->Encoding    = 'base64';
        $mailer->Hostname    = 'localhost';
        $mailer->IsHTML(TRUE); 
        $mailer->IsSMTP(TRUE); 

        // mail body
        $mailer->From        = $from;
        $mailer->FromName    = $from_name;
        $mailer->Subject     = $subject;
        $mailer->Body        = $body;
        $mailer->AltBody     = strip_tags($body);

        $mailer->AddAddress($to);

        // remote mail server information
        $mailer->Host        = $host;
        $mailer->port        = 25;
        $mailer->Username    = $from;
        $mailer->Password    = $password;
        $mailer->SMTPAuth    = TRUE;
        $mailer->SMTPDebug   = FALSE;
        
//print_r($mailer);
        
        return $mailer->Send();
            
    }
    
    
    function set_location($url){
        header('Location: ' . $url);
        exit;
    }
    
    function make_url($query, $host = SITE_HOST, $port = SITE_SERVER_PORT){
        return "http://{$host}:{$port}/?{$query}";
    }
    
       
    function real_ip() {
        
        static $realip = NULL;

        if ($realip !== NULL)
        {
            return $realip;
        }

        if (isset($_SERVER))
        {
            if (isset($_SERVER['HTTP_X_FORWARDED_FOR']))
            {
                $arr = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);

                /* 取X-Forwarded-For中第一个非unknown的有效IP字符串 */
                foreach ($arr AS $ip)
                {
                    $ip = trim($ip);

                    if ($ip != 'unknown')
                    {
                        $realip = $ip;

                        break;
                    }
                }
            }
            elseif (isset($_SERVER['HTTP_CLIENT_IP']))
            {
                $realip = $_SERVER['HTTP_CLIENT_IP'];
            }
            else
            {
                if (isset($_SERVER['REMOTE_ADDR']))
                {
                    $realip = $_SERVER['REMOTE_ADDR'];
                }
                else
                {
                    $realip = '0.0.0.0';
                }
            }
        }
        else
        {
            if (getenv('HTTP_X_FORWARDED_FOR'))
            {
                $realip = getenv('HTTP_X_FORWARDED_FOR');
            }
            elseif (getenv('HTTP_CLIENT_IP'))
            {
                $realip = getenv('HTTP_CLIENT_IP');
            }
            else
            {
                $realip = getenv('REMOTE_ADDR');
            }
        }

        preg_match("/[\d\.]{7,15}/", $realip, $onlineip);
        $realip = !empty($onlineip[0]) ? $onlineip[0] : '0.0.0.0';

        return $realip;
    }

    function captcha() {

        $rndstring = '';

        for($i=0;$i<4;$i++) {
            $rndstring .= chr(mt_rand(65,90));
        }

        if(function_exists('imagecreate')) {
            $_SESSION['captcha'] = strtolower($rndstring);
                
            $rndcodelen = strlen($rndstring);
            $im = imagecreate(50,20);
            $bgcolor = ImageColorAllocate($im, 248,212,20);
            $black = ImageColorAllocate($im, 0,0,0);
            imagerectangle($im, 0, 0, 49, 19, $black);
                
            for($i=0;$i<$rndcodelen;$i++) {
                imagestring($im, mt_rand(2,5), $i*10+6, mt_rand(2,5), $rndstring[$i], $black);
            }
                
            if(function_exists('imagejpeg')) {
                header("Content-Type: image/jpeg\r\n");
                ImageJpeg($im);
            } else {
                header("Content-Type: image/png\r\n");
                ImagePng($im);
            }
            ImageDestroy($im);
            exit();
                
        } else {

            $_SESSION['captcha'] = 'abcd';
            header("Content-Type: image/jpeg\r\n");
            exit();
                
        }
    }
    
    function price_format($v, $max, $rnd = 2) {
        $v = floatval($v);
        if($v < 0) {
            $v = 0;
        }
        if($v > $max) {
            $v = $max;
        }
        return round($v, $rnd);
    }
    


    function detect_encoding($filename) {
        
        define ('UTF32_BIG_ENDIAN_BOM'   , chr(0x00) . chr(0x00) . chr(0xFE) . chr(0xFF));
        define ('UTF32_LITTLE_ENDIAN_BOM', chr(0xFF) . chr(0xFE) . chr(0x00) . chr(0x00));
        define ('UTF16_BIG_ENDIAN_BOM'   , chr(0xFE) . chr(0xFF));
        define ('UTF16_LITTLE_ENDIAN_BOM', chr(0xFF) . chr(0xFE));
        define ('UTF8_BOM'               , chr(0xEF) . chr(0xBB) . chr(0xBF));

        $text = file_get_contents($filename);
        $first2 = substr($text, 0, 2);
        $first3 = substr($text, 0, 3);
        $first4 = substr($text, 0, 3);
        
        if ($first3 == UTF8_BOM) return 'UTF-8';
        elseif ($first4 == UTF32_BIG_ENDIAN_BOM) return 'UTF-32BE';
        elseif ($first4 == UTF32_LITTLE_ENDIAN_BOM) return 'UTF-32LE';
        elseif ($first2 == UTF16_BIG_ENDIAN_BOM) return 'UTF-16BE';
        elseif ($first2 == UTF16_LITTLE_ENDIAN_BOM) return 'UTF-16LE';
        else return 'GBK';
    }
    
    function bf_encrypt($value, $key) {
        $td = mcrypt_module_open(MCRYPT_BLOWFISH, '', MCRYPT_MODE_ECB, '');
        $iv = mcrypt_create_iv(mcrypt_enc_get_iv_size($td), MCRYPT_RAND);
        $key = substr(md5($key), 0, mcrypt_enc_get_key_size($td));
        mcrypt_generic_init($td, $key, $iv);
        $ret = $this->base64_encode_url(mcrypt_generic($td, $value));
        mcrypt_generic_deinit($td);
        mcrypt_module_close($td);
        return $ret;
    }


    function bf_decrypt($value, $key) {
        $td = mcrypt_module_open(MCRYPT_BLOWFISH, '', MCRYPT_MODE_ECB, '');
        $iv = mcrypt_create_iv(mcrypt_enc_get_iv_size($td), MCRYPT_RAND);
        $key = substr(md5($key), 0, mcrypt_enc_get_key_size($td));
        mcrypt_generic_init($td, $key, $iv);
        $ret = trim(mdecrypt_generic($td, $this->base64_decode_url($value)));
        mcrypt_generic_deinit($td);
        mcrypt_module_close($td);
        return $ret;
    }

    function base64_encode_url($v) {
        $v = base64_encode($v);
        $v = str_replace('+', '-', $v);
        $v = str_replace('/', '_', $v);
        $v = str_replace('=', '.', $v);
        return $v;    
    }

    function base64_decode_url($v) {
        $v = str_replace('-', '+', $v);
        $v = str_replace('_', '/', $v);
        $v = str_replace('.', '=', $v);
        $v = base64_decode($v);
        return $v;    
    }
    
    function tidy_clean($v) {
        
        if(function_exists('tidy_parse_string')) {
            
            $tidy_config = array('output-xhtml' => TRUE,
                                 'show-body-only' => TRUE,
                                 'doctype' => 'transitional',
                                 'alt-text' => '-',
                                 );
                                 
            $tidy_obj = tidy_parse_string($v, $tidy_config, 'UTF8');
            tidy_clean_repair($tidy_obj);
            $v = tidy_get_output($tidy_obj);
        }
        
        return $v;

    }
    

    function get_user_browser() { 
        
        $user_agent = $_SERVER['HTTP_USER_AGENT']; 
        $user_browser = '';
         
        if(preg_match('/MSIE/i',$user_agent)) { 
            $user_browser = 'ie'; 
        } elseif(preg_match('/Firefox/i',$user_agent)) { 
            $user_browser = 'firefox'; 
        } elseif(preg_match('/Safari/i',$user_agent)) { 
            $user_browser = 'safari'; 
        } elseif(preg_match('/Chrome/i',$user_agent)) { 
            $user_browser = 'chrome'; 
        } elseif(preg_match('/Opera/i',$user_agent)) { 
            $user_browser = 'opera'; 
        } elseif(preg_match('/WebKit/i',$user_agent)) { 
            $user_browser = 'webkit'; 
        } elseif(preg_match('/Lotus/i',$user_agent)) { 
            $user_browser = 'lotus'; 
        } elseif(preg_match('/Gecko/i',$user_agent)) { 
            $user_browser = 'gecko'; 
        }   
        
        return $user_browser; 
    }
    
    function authcode($string, $operation = 'DECODE', $key = '', $expiry = 0) {

        $ckey_length = 4;    // 随机密钥长度 取值 0-32;
                    // 加入随机密钥，可以令密文无任何规律，即便是原文和密钥完全相同，加密结果也会每次不同，增大破解难度。
                    // 取值越大，密文变动规律越大，密文变化 = 16 的 $ckey_length 次方
                    // 当此值为 0 时，则不产生随机密钥

        $key = md5($key ? $key : SECRET_KEY);
        $keya = md5(substr($key, 0, 16));
        $keyb = md5(substr($key, 16, 16));
        $keyc = $ckey_length ? ($operation == 'DECODE' ? substr($string, 0, $ckey_length): substr(md5(microtime()), -$ckey_length)) : '';

        $cryptkey = $keya.md5($keya.$keyc);
        $key_length = strlen($cryptkey);

        $string = $operation == 'DECODE' ? base64_decode(substr($string, $ckey_length)) : sprintf('%010d', $expiry ? $expiry + time() : 0).substr(md5($string.$keyb), 0, 16).$string;
        $string_length = strlen($string);

        $result = '';
        $box = range(0, 255);

        $rndkey = array();
        for($i = 0; $i <= 255; $i++) {
            $rndkey[$i] = ord($cryptkey[$i % $key_length]);
        }

        for($j = $i = 0; $i < 256; $i++) {
            $j = ($j + $box[$i] + $rndkey[$i]) % 256;
            $tmp = $box[$i];
            $box[$i] = $box[$j];
            $box[$j] = $tmp;
        }

        for($a = $j = $i = 0; $i < $string_length; $i++) {
            $a = ($a + 1) % 256;
            $j = ($j + $box[$a]) % 256;
            $tmp = $box[$a];
            $box[$a] = $box[$j];
            $box[$j] = $tmp;
            $result .= chr(ord($string[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
        }

        if($operation == 'DECODE') {
            if((substr($result, 0, 10) == 0 || substr($result, 0, 10) - time() > 0) && substr($result, 10, 16) == substr(md5(substr($result, 26).$keyb), 0, 16)) {
                return substr($result, 26);
            } else {
                return '';
            }
        } else {
            return $keyc.str_replace('=', '', base64_encode($result));
        }

    }
    
    function base64_string_encode_url($v) {
        $v = str_replace('+', '-', $v);
        $v = str_replace('/', '_', $v);
        $v = str_replace('=', '.', $v);
        return $v;    
    }

    function base64_string_decode_url($v) {
        $v = str_replace('-', '+', $v);
        $v = str_replace('_', '/', $v);
        $v = str_replace('.', '=', $v);
        return $v;    
    }
    
    function array_diff_fast($a1 = array(), $a2 = array()) { 
        
        $a2 = array_flip($a2);
        $a3 = array();
        
        foreach ($a1 as $k => $v) { 
            if(!isset($a2[$v])) { 
                $a3[] = $v; 
            } 
         } 

        return $a3;
         
    } 
    
    function mb_str_split($string) { 
        # Split at all position not after the start: ^ 
        # and not before the end: $ 
        return preg_split('/(?<!^)(?!$)/u', $string); 
    }
    
    function make_random_string($string) {
        
        if($string == '') {
            return $string;
        }
        
        $a = array();
        $a = $this->mb_str_split($string);
        
        $c = 'abcdefghijklmnopqrstuvwxyz';
        $c = $this->mb_str_split($c);
        
        $s = '';
        
        for($i=0;$i<sizeof($a);++$i) {
            if($i && mt_rand(0, 1)) {
                $s .= $c[array_rand($c)] . $a[$i];
            } else {
                $s .= $a[$i];            
            }
        }
        
        return $s;
    
    } 

    
}
function _escape(&$arr_r) {
    foreach ($arr_r as &$val) is_array($val) ? _escape($val):$val=addslashes($val);
    unset($val);
}
?>
