<?php

/*******************************************************************************
Gaza Html Obfuscator, Class Version.  
Author: Shuguo Qin <qinshuguo@gmail.com>
        Tomma <tomma.name@gmail.com>
*******************************************************************************/

class Gaza {
    
    var $cjk_pattern        = '/[\x{2E80}-\x{9FFF}\x{F900}-\x{FFFF}]/u'; 
    var $cjk_cjk_pattern    = '/([\x{2E80}-\x{9FFF}\x{F900}-\x{FFFF}])([\x{2E80}-\x{9FFF}\x{F900}-\x{FFFF}])/u'; 
    var $an_cjk_pattern     = '/([a-zA-Z0-9])([\x{2E80}-\x{9FFF}\x{F900}-\x{FFFF}])/u'; 
    var $cjk_an_pattern     = '/([\x{2E80}-\x{9FFF}\x{F900}-\x{FFFF}])([a-zA-Z0-9])/u'; 
                                                            
    function language_detect($html) {
        
        $plain = trim(strip_tags($html));
        
        // ja zh ko other
           
        $pattern = array();
        $pattern['zh'] = '/[\x{4E00}-\x{9FA5}]/u';
        $pattern['ja'] = '/[\x{3040}-\x{309F}\x{30A0}-\x{30FF}]/u';
        $pattern['ko'] = '/[\x{AC00}-\x{D7AF}]/u';
        
        if(preg_match($pattern['ko'], $plain)) {
            $language = 'ko';
        } elseif(preg_match($pattern['ja'], $plain)) {
            $language = 'ja';
        } elseif(preg_match($pattern['zh'], $plain)) {
            $language = 'zh';
        } else {
            $language = 'other';
        }
        
        return $language;
         
    }
    
    function html_mix_unicode($html, $language) {
        
        $html = preg_replace_callback('/([^>]+)>([^<]+)</', array(&$this, '_html_space_replace'), $html);
        
        if($language == 'ja' || $language == 'ko' || $language == 'zh') {
            $html = $this->_cjk_replace($html);                    
        }
        
        return $html;
        
    }
    
    function plain_mix_unicode($plain, $language) {
        
        $plain = trim(strip_tags($plain));
        
        $plain = preg_replace('/\s+/', $this->_unicode_space(), $plain);
        
        if($language == 'ja' || $language == 'ko' || $language == 'zh') {
            $plain = $this->_cjk_replace($plain);                 
        }
        
        return $plain;        
    
    }
    
    function host_mix_entity($html, $language) {
        
        // link href mix entity
        $html = preg_replace_callback('|(href=[^>/]*//)([0-9a-zA-Z\.\-]+)|i', array(&$this, '_entity_replace'), $html);
        // image src mix entity
        $html = preg_replace_callback('|(src=[^>/]*//)([0-9a-zA-Z\.\-]+)|i', array(&$this, '_entity_replace'), $html);
        
        return $html;
        
    }
    
    function _html_space_replace($matches) {
        
        $content = trim($matches[2]);
        if(empty($content)) {
            return $matches[0];
        }
        
        if(stripos($matches[1], '!') === 0 || stripos($matches[1], 'script') === 0 || stripos($matches[1], 'style') === 0) {
            return $matches[0];
        }
        
        $content = preg_replace('/\s+/', $this->_unicode_space(), $content);
        
        return $matches[1] . '>' . $content . '<';
        
    }
    
    
    function _cjk_replace($v) {
        
        $v = preg_replace_callback($this->cjk_cjk_pattern, array(&$this, '_cjk_insert'), $v);
        $v = preg_replace_callback($this->cjk_cjk_pattern, array(&$this, '_cjk_insert'), $v);                   
        $v = preg_replace_callback($this->an_cjk_pattern, array(&$this, '_cjk_insert'), $v);                   
        $v = preg_replace_callback($this->cjk_an_pattern, array(&$this, '_cjk_insert'), $v); 
        
        return $v;
        
    }
    
    function _cjk_insert($matches) {
        
        $mix = $matches[1] . $this->_unicode_space() . $matches[2];
        
        return $mix;
        
    }
    
    function _unicode_space() {
        
        $unicode_ranges = array(array(0xea00, 0xefff));
        
        $unicode_array = array();
        
        foreach($unicode_ranges as $unicode_range) {
            $unicode_array[] = mt_rand($unicode_range[0], $unicode_range[1]);
        }
        
        $unicode_char = base_convert($unicode_array[array_rand($unicode_array)], 10, 16);
        $unicode_char = json_decode('"\u' . $unicode_char . '"');
        
        return $unicode_char;
        
    }
    
    function _entity_replace($matches) {
        
        $host = $matches[2];
        $length = strlen($host);
        $new  = '';
        
        for($i = 0;$i < $length;++$i) {
            
            switch(mt_rand(1, 3)) {
                case 1 :
                    $new .= '%' . base_convert(ord(substr($host, $i, 1)), 10, 16);
                    break;
                case 2 :
                    $new .= substr($host, $i, 1);
                    break;
                case 3 :
                    $new .= '&#' . ord(substr($host, $i, 1)) . ';';
                    break;
            }
            
        }
        
        return $matches[1] . $new;
        
    }
}
?>
<?php
//$gaza = new Gaza();
//$html = file_get_contents('taobao.utf8.html'); 
//$language = $gaza->language_detect($html);
//$html = $gaza->html_mix_unicode($html, $language);
//$html = $gaza->host_mix_entity($html, $language);
//$plain = file_get_contents('plain.txt');
//$language = $gaza->language_detect($plain);
//$plain = $gaza->plain_mix_unicode($plain, $language);
//echo $plain;
//echo $html;
?>
