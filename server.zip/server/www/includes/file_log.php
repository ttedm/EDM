<?php

class file_log {

    var $log_path;
    
    function set_path($path) {
        $this->log_path = $path;
    }
    
    function set_log($log_name, $log_message) {
        
        if($this->log_path == '') {
            return;
        }
        
        $message = date('Y.m.d H:i:s') . "\t" . $log_message . "\r\n";
        $file = $this->log_path . '/' . $log_name . '.log';
        @file_put_contents($file, $message, FILE_APPEND);
    }
    
}
 
?>
