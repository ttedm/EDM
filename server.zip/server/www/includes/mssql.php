<?php
//标识
class mssql {

    var $conn;
    var $host;
    var $username;
    var $password;

    
    function set_vars($host, $username, $password, $port = '1433') {
        $this->host = $host . ':' . $port;
        $this->username = $username;
        $this->password = $password;
    }
    
    function get_connection() {
        $this->conn = @mssql_pconnect($this->host, $this->username, $this->password);
    }

    function use_db($db) {
        mssql_select_db($db, $this->conn); 
    }

    function close_connection() {
        mssql_close($this->conn);
    }
    
}
?>