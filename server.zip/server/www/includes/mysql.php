<?php
//标识
class mysql {

    var $conn;
    var $host;
    var $username;
    var $password;
    
    var $query_cache = TRUE;
    
    function set_vars($host, $username, $password) {
        $this->host = $host;
        $this->username = $username;
        $this->password = $password;
    }
    
    function get_connection() {
    
        $this->conn = mysql_connect($this->host, $this->username, $this->password);

	}

	function set_parameters() {

		mysql_query("SET NAMES UTF8", $this->conn);

        if(!$this->query_cache) {
            mysql_query("SET SESSION query_cache_type = OFF", $this->conn);       
        }

	}
    
    function use_db($db) {
        mysql_query("USE {$db}", $this->conn); 
    }

    function close_connection() {
        mysql_close($this->conn);
    }
    
}
?>