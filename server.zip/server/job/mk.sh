ln -s /usr/bin/php dphp
g++ -o daemon daemon.cpp
rm -f daemon.cpp
chmod +x daemon
