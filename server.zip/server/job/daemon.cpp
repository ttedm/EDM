#include <iostream>
#include <string>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <sys/stat.h>

using namespace std;

int main(int argc, char *argv[]) {

    int err = 0;
    string job;

    if(argc != 2) {
      err = 1;       
    } else {
      job = argv[1];       
    }
        
    if(err == 1) {
        cout << "need at least 2 argv." << endl;
		return 0;     
    }

    string cmd = "./dphp job.php " + job;
    
    char * szCmdline = new char[cmd.size() + 1]; 
    std::copy(cmd.begin(), cmd.end(), szCmdline); 
    szCmdline[cmd.size()] = '\0';

	chdir(".");

	while(1){
		system(szCmdline);
	}

}
